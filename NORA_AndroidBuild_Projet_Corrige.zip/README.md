# NORA — projet Android Gradle corrigé pour AndroidBuild

## Objet
Ce ZIP est **un véritable projet Android Gradle** à importer dans AndroidBuild avec `Android natif`, Gradle 8.4, API cible 34, type `Debug`. Les fichiers `settings.gradle`, `build.gradle`, `app/build.gradle`, le manifeste et les classes Java sont présents **à la racine correcte**.

## IMPORTANT — portée honnête de la réparation
Le ZIP original fourni par Google AI Studio est un projet **React + TypeScript + Vite**, sans projet Android ni bundle `dist/` compilé. Il n'est pas possible de convertir magiquement tous ses écrans en application native simplement en ajoutant Gradle. Pour éviter un APK blanc, cette version Android compile une **version NORA autonome hors ligne** dans `app/src/main/assets/index.html`. Elle inclut : création de tâches, cours récurrents, calendrier semaine + mois, changement de routine, suivi des séances, priorités et export JSON/ICS (la compatibilité export dans WebView peut varier), réglages, horaires de prière **saisis manuellement** par date, protections des plages de prières et rappels natifs Android des 7 prochains jours après ouverture.

**L'interface n'est PAS exactement la même que l'application React/Vite aperçue dans Google AI Studio.** Le projet React original est conservé intact dans `source_original_vite/` pour permettre une migration complète ultérieure, par exemple via Capacitor avec une compilation web `npm install && npm run build && npx cap sync android` depuis un environnement capable d'installer les dépendances.

## Rappels Android
Les rappels sont planifiés par Android AlarmManager (mode non exact lorsque le système le décide), affichés sur écran verrouillé selon les autorisations Android, et sont restaurés après redémarrage. Ils sont programmés pour les prochains 7 jours lors de l'ouverture ou d'une modification des données. **Ce n'est pas une garantie de déclenchement à la seconde près** et l'application doit être rouverte de temps en temps pour renouveler l'horizon. Pour les prières, aucun horaire non vérifié n'est injecté : on saisit les 5 heures par date dans l'onglet Prières.

## Compilation
1. Télécharger ce fichier ZIP sur le téléphone.
2. AndroidBuild > Upload ZIP > Android natif > SDK cible 34 > Gradle 8.4 > Debug.
3. Analyser projet, puis compiler en APK si validation OK.
4. Si AndroidBuild demande de choisir une autre version de plugin Android/Gradle, transmettre le message exact au lieu d'inventer des versions.
5. Installer uniquement l'APK obtenu d'une source jugée fiable et conserver une sauvegarde JSON avant toute mise à jour.

## Limitations connues
- L'APK n'a pas pu être compilé ni testé sur un vrai Samsung depuis cet environnement : Android SDK et Gradle ne sont pas installés ici.
- La version native est une base fonctionnelle hors ligne, pas une migration de l'interface React/Vite originale. Les pages React restent fournies comme source.
- Pas de synchronisation fiable des horaires Habous intégrée ; entrée manuelle nécessaire pour la bonne date.
- Pas de SQLite natif : WebView conserve ses données dans le stockage web de l'application Android.
- Export de sauvegardes via sélecteur Android natif et import depuis le sélecteur de fichiers : à tester dans l'APK produit.
- L'application n'est pas encore un produit fini équivalent au cahier des charges complet.

**Ne supprimez pas la version installée sans avoir exporté vos données.**
