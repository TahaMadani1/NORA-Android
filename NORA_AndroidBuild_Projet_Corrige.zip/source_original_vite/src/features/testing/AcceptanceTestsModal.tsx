import React, { useState } from 'react';
import { X, Play, CheckCircle2, XCircle, ShieldCheck, Check, Clock, RefreshCw } from 'lucide-react';
import { runAllAcceptanceTests, TestResult } from '../../services/testing/acceptanceTests';

interface AcceptanceTestsModalProps {
  onClose: () => void;
}

export const AcceptanceTestsModal: React.FC<AcceptanceTestsModalProps> = ({ onClose }) => {
  const [results, setResults] = useState<TestResult[]>(() => runAllAcceptanceTests());
  const [isRunning, setIsRunning] = useState(false);

  const handleRerun = () => {
    setIsRunning(true);
    setTimeout(() => {
      setResults(runAllAcceptanceTests());
      setIsRunning(false);
    }, 300);
  };

  const passedCount = results.filter((r) => r.passed).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end">
      <div className="w-full max-h-[90vh] bg-white rounded-t-3xl flex flex-col overflow-hidden animate-slideUp shadow-2xl">
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-2.5 shrink-0" />

        <div className="px-5 pb-3 border-b border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-[#172B4D]">Banc de Tests d'Acceptation</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                {passedCount} / {results.length} validés
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Scénarios fonctionnels rigoureux (Régression, Prières, Persistance, Invariants)
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs">
          <span className="text-slate-600 font-medium">Exécution locale en mémoire & validation déterministe</span>
          <button
            onClick={handleRerun}
            disabled={isRunning}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#172B4D] hover:bg-slate-800 text-white rounded-xl font-semibold shadow-sm transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
            <span>Relancer les tests</span>
          </button>
        </div>

        {/* Results List */}
        <div className="p-5 overflow-y-auto space-y-2.5 flex-1 text-xs">
          {results.map((res) => (
            <div
              key={res.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                res.passed
                  ? 'bg-white border-slate-200/80 shadow-sm'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              <div className="flex items-start gap-2.5">
                {res.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="font-bold text-slate-900 text-xs">
                      #{res.id}. {res.title}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                      {res.durationMs}ms
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed mt-0.5">
                    {res.message}
                  </p>

                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-[9px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-600 uppercase tracking-wider">
                      {res.category}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-100 bg-white">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs"
          >
            Fermer le rapport de tests
          </button>
        </div>
      </div>
    </div>
  );
};
