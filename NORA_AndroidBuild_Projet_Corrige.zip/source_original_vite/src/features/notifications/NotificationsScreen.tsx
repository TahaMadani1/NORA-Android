import React, { useState } from 'react';
import { 
  Bell, 
  ArrowLeft, 
  ShieldCheck, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Sliders, 
  Smartphone,
  Trash2
} from 'lucide-react';
import { ANDROID_CHANNELS, notificationService } from '../../services/notifications/notificationManager';
import { db } from '../../services/storage/database';
import { toastService } from '../../services/feedback/toastService';

interface NotificationsScreenProps {
  onBack: () => void;
  onDataChanged: () => void;
}

export const NotificationsScreen: React.FC<NotificationsScreenProps> = ({
  onBack,
  onDataChanged
}) => {
  const [permissionStatus, setPermissionStatus] = useState(notificationService.getPermissionStatus());
  const notifs = db.getNotifications();

  const handleRequestPermission = async () => {
    const granted = await notificationService.requestPermission();
    setPermissionStatus(notificationService.getPermissionStatus());
    if (granted) {
      toastService.success('Autorisation de notification accordée avec succès !');
    }
  };

  const handleSendTest = () => {
    notificationService.sendTestNotification();
    onDataChanged();
    toastService.info('Notification envoyée (visible sur l\'écran verrouillé et le centre de notification) !');
  };

  const handleDismiss = (id: string) => {
    db.dismissNotification(id);
    onDataChanged();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Centre de Notifications Android</h1>
          <p className="text-[11px] text-slate-500">Canaux natifs, autorisations et alertes écran verrouillé</p>
        </div>
      </div>

      {/* Permission & Diagnostic Status Card */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <span className="font-bold text-[#172B4D] text-sm">Diagnostic système</span>
          <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
            permissionStatus === 'granted'
              ? 'bg-emerald-100 text-emerald-800'
              : 'bg-amber-100 text-amber-800'
          }`}>
            {permissionStatus === 'granted' ? 'Autorisé' : 'Demande requise'}
          </span>
        </div>

        <div className="space-y-2 text-slate-600">
          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <span>Permissions OS (POST_NOTIFICATIONS) :</span>
            <span className="font-semibold text-slate-900">{permissionStatus}</span>
          </div>
          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <span>Permission alarmes exactes (SCHEDULE_EXACT_ALARM) :</span>
            <span className="font-semibold text-emerald-700">Configuré (app.json)</span>
          </div>
          <div className="flex items-center justify-between py-1 border-b border-slate-100">
            <span>Optimisation de batterie Android :</span>
            <span className="font-semibold text-slate-700">Guide inclus</span>
          </div>
        </div>

        <div className="pt-2 flex gap-2">
          {permissionStatus !== 'granted' && (
            <button
              onClick={handleRequestPermission}
              className="flex-1 py-2.5 rounded-xl bg-teal-700 text-white font-semibold text-xs hover:bg-teal-800"
            >
              Demander l'autorisation OS
            </button>
          )}

          <button
            onClick={handleSendTest}
            className="flex-1 py-2.5 rounded-xl bg-[#172B4D] text-white font-semibold text-xs hover:bg-slate-800"
          >
            Déclencher notification de test
          </button>
        </div>
      </div>

      {/* Android 5 Native Notification Channels */}
      <div className="space-y-2.5">
        <span className="text-xs font-bold text-[#172B4D] px-1 uppercase tracking-wider block">
          5 Canaux de notifications dédiés (Android 8.0+)
        </span>

        {ANDROID_CHANNELS.map((ch) => (
          <div key={ch.id} className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-sm space-y-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-xs">{ch.name}</span>
              <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-mono uppercase">
                {ch.importance}
              </span>
            </div>
            <p className="text-[11px] text-slate-500">{ch.description}</p>
            <div className="pt-1 flex items-center gap-3 text-[10px] text-slate-400">
              <span>Son : {ch.sound ? 'Actif' : 'Désactivé'}</span>
              <span>Vibration : {ch.vibration ? 'Active' : 'Désactivée'}</span>
              <span>Écran verrouillé : {ch.lockscreenVisibility}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Notification History */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-[#172B4D]">Historique des alertes émises</span>
          <span className="text-[11px] text-slate-500">{notifs.length} alertes</span>
        </div>

        {notifs.map((n) => (
          <div key={n.id} className="bg-white rounded-2xl p-3 border border-slate-200 flex items-start justify-between gap-3 text-xs">
            <div>
              <span className="font-bold text-slate-900 block">{n.title}</span>
              <p className="text-slate-600 text-[11px] mt-0.5">{n.body}</p>
              <span className="text-[10px] text-slate-400 block mt-1">
                Canal : {n.channelId} · {new Date(n.scheduledTime).toLocaleTimeString('fr-FR')}
              </span>
            </div>

            {n.status !== 'DISMISSED' && (
              <button
                onClick={() => handleDismiss(n.id)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
                title="Ignorer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
