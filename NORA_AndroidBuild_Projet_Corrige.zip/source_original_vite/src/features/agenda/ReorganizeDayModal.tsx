import React, { useState } from 'react';
import { X, Check, SlidersHorizontal, ShieldCheck, AlertCircle, ArrowRight } from 'lucide-react';
import { AppSettings, ScheduledSession } from '../../types';
import { generateSchedulePlans } from '../../services/scheduling/schedulingEngine';
import { db } from '../../services/storage/database';
import { toastService } from '../../services/feedback/toastService';

interface ReorganizeDayModalProps {
  settings: AppSettings;
  onClose: () => void;
  onDataChanged: () => void;
}

export const ReorganizeDayModal: React.FC<ReorganizeDayModalProps> = ({
  settings,
  onClose,
  onDataChanged
}) => {
  const todayStr = '2026-10-13';
  const plans = generateSchedulePlans(todayStr, settings);

  const [selectedPlan, setSelectedPlan] = useState<'A' | 'B'>('A');

  const handleApplyPlan = () => {
    const chosen = selectedPlan === 'A' ? plans.planA : plans.planB;
    // Update sessions in DB
    chosen.sessions.forEach((sess) => {
      db.saveSession(sess);
    });
    onDataChanged();
    toastService.success(`Le ${selectedPlan === 'A' ? 'Plan A (Équilibré)' : 'Plan B (Allégé)'} a été appliqué avec succès !`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end">
      <div className="w-full max-h-[85vh] bg-white rounded-t-3xl flex flex-col overflow-hidden animate-slideUp shadow-2xl">
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-2.5 shrink-0" />

        <div className="px-5 pb-3 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-[#172B4D]">Réorganiser ma journée</h2>
            <p className="text-xs text-slate-500">
              Aperçu avant / après sans bouleversement incontrôlé
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          <div className="bg-teal-50 border border-teal-200 rounded-2xl p-3.5 flex items-start gap-2.5 text-teal-900">
            <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">Invariants protégés</span>
              <p className="text-[11px] text-teal-800 mt-0.5">
                Les 5 prières de Rabat et les cours magistraux fixes ne sont jamais déplacés automatiquement.
              </p>
            </div>
          </div>

          {/* Plan Options */}
          <div className="space-y-3">
            {/* Plan A */}
            <div
              onClick={() => setSelectedPlan('A')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                selectedPlan === 'A'
                  ? 'border-[#172B4D] ring-2 ring-[#172B4D]/20 bg-slate-50/50'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-sm text-[#172B4D]">Plan A — Équilibré</span>
                <span className="font-bold text-slate-700 tabular-nums">
                  {Math.round(plans.planA.totalMinutes / 60)}h total
                </span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                {plans.planA.description}
              </p>
              <div className="mt-2 text-[10px] text-slate-500">
                {plans.planA.sessions.length} sessions maintenues
              </div>
            </div>

            {/* Plan B */}
            <div
              onClick={() => setSelectedPlan('B')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                selectedPlan === 'B'
                  ? 'border-[#172B4D] ring-2 ring-[#172B4D]/20 bg-slate-50/50'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-sm text-teal-800">Plan B — Allégé & Récupération</span>
                <span className="font-bold text-teal-800 tabular-nums">
                  {Math.round(plans.planB.totalMinutes / 60)}h total
                </span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                {plans.planB.description}
              </p>
              <div className="mt-2 text-[10px] text-slate-500">
                {plans.planB.sessions.length} sessions prioritaires (report des tâches non critiques)
              </div>
            </div>
          </div>
        </div>

        {/* Footer CTAs */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700"
          >
            Annuler
          </button>
          <button
            onClick={handleApplyPlan}
            className="flex-1 py-3 rounded-xl bg-[#172B4D] text-white text-xs font-semibold hover:bg-slate-800 transition-colors shadow-md"
          >
            Appliquer le {selectedPlan === 'A' ? 'Plan A' : 'Plan B'}
          </button>
        </div>
      </div>
    </div>
  );
};
