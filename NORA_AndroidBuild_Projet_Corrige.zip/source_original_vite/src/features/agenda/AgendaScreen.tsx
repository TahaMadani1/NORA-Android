import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Filter, 
  Layers, 
  Clock, 
  AlertCircle,
  Plus
} from 'lucide-react';
import { TaskCategory, ScheduledSession, AppSettings } from '../../types';
import { CATEGORY_THEMES, PRIORITY_THEMES } from '../../theme/colors';
import { db } from '../../services/storage/database';
import { getDailyPrayerSchedule, parseHHMMToMinutes } from '../../services/prayerTimes/rabatPrayerService';

interface AgendaScreenProps {
  settings: AppSettings;
  onOpenTaskDetail: (taskId: string) => void;
  onOpenPeriods: () => void;
  onOpenRoutines: () => void;
  onOpenQuickCreate: () => void;
}

type AgendaViewMode = 'JOUR' | 'SEMAINE' | 'MOIS';

export const AgendaScreen: React.FC<AgendaScreenProps> = ({
  settings,
  onOpenTaskDetail,
  onOpenPeriods,
  onOpenRoutines,
  onOpenQuickCreate
}) => {
  const [viewMode, setViewMode] = useState<AgendaViewMode>('JOUR');
  const [selectedDate, setSelectedDate] = useState('2026-10-13');
  const [categoryFilter, setCategoryFilter] = useState<TaskCategory | 'ALL'>('ALL');

  const allSessions = db.getSessions();
  const periods = db.getSchedulePeriods();
  const prayerData = getDailyPrayerSchedule(selectedDate, settings);

  // Filter sessions
  const filteredSessions = allSessions.filter((s) => {
    if (categoryFilter !== 'ALL' && s.category !== categoryFilter) return false;
    return true;
  });

  const daySessions = filteredSessions
    .filter((s) => s.date === selectedDate)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const changeDateBy = (days: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + days);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const activePeriod = periods.find((p) => p.isActive);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Header & View Mode Switcher */}
      <div className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => changeDateBy(-1)}
              className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="text-center px-2">
              <span className="text-xs font-bold text-[#172B4D] block capitalize">
                {new Date(selectedDate).toLocaleDateString('fr-FR', {
                  weekday: 'short',
                  day: 'numeric',
                  month: 'short'
                })}
              </span>
              <span className="text-[10px] text-slate-400">Rabat (UTC+1)</span>
            </div>
            <button
              onClick={() => changeDateBy(1)}
              className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Segmented View Mode */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl">
            {(['JOUR', 'SEMAINE', 'MOIS'] as AgendaViewMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  viewMode === mode
                    ? 'bg-white text-[#172B4D] shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {mode.charAt(0) + mode.slice(1).toLowerCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Nav to Périodes & Routines */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 text-slate-600">
            <span className="text-[11px] font-medium text-slate-500">Période :</span>
            <button
              onClick={onOpenPeriods}
              className="font-semibold text-teal-700 hover:underline"
            >
              {activePeriod ? activePeriod.name : 'Aucune période active'}
            </button>
          </div>
          <button
            onClick={onOpenRoutines}
            className="text-[11px] font-semibold text-blue-600 hover:underline flex items-center gap-1"
          >
            <Layers className="w-3 h-3" />
            <span>Routines de cours</span>
          </button>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs scrollbar-none">
        <button
          onClick={() => setCategoryFilter('ALL')}
          className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-colors ${
            categoryFilter === 'ALL'
              ? 'bg-[#172B4D] text-white'
              : 'bg-white text-slate-600 border border-slate-200'
          }`}
        >
          Tout
        </button>
        {Object.entries(CATEGORY_THEMES).map(([catKey, theme]) => (
          <button
            key={catKey}
            onClick={() => setCategoryFilter(catKey as TaskCategory)}
            className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-colors ${
              categoryFilter === catKey
                ? 'bg-slate-800 text-white'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            {theme.label}
          </button>
        ))}
      </div>

      {/* VIEW: JOUR (Timeline chronologique avec créneaux et prières protégées) */}
      {viewMode === 'JOUR' && (
        <div className="space-y-3">
          <div className="text-xs font-semibold text-slate-500 px-1">
            Créneaux horaires du jour ({daySessions.length} activités)
          </div>

          <div className="space-y-2">
            {daySessions.map((sess) => {
              const cat = CATEGORY_THEMES[sess.category] || CATEGORY_THEMES.STUDIES;
              const prio = PRIORITY_THEMES[sess.priority] || PRIORITY_THEMES.P3;

              return (
                <div
                  key={sess.id}
                  className="bg-white rounded-2xl p-3 border border-slate-200 shadow-sm flex items-center justify-between gap-3"
                >
                  <div className="w-16 shrink-0 text-center border-r border-slate-100 pr-2">
                    <span className="text-xs font-bold text-[#172B4D] block tabular-nums">
                      {sess.startTime}
                    </span>
                    <span className="text-[10px] text-slate-400 tabular-nums">{sess.endTime}</span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span
                        className="text-[9px] font-bold px-1.5 py-0.2 rounded"
                        style={{ backgroundColor: prio.badgeBg, color: prio.text }}
                      >
                        {prio.label.split(' ')[0]}
                      </span>
                      <span className="text-[10px] text-slate-500 truncate">
                        {cat.label}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 truncate">
                      {sess.title}
                    </h4>
                    {sess.location && (
                      <span className="text-[10px] text-slate-400 block truncate">
                        📍 {sess.location}
                      </span>
                    )}
                  </div>

                  {sess.taskId && (
                    <button
                      onClick={() => onOpenTaskDetail(sess.taskId!)}
                      className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-[11px] font-medium shrink-0"
                    >
                      Détails
                    </button>
                  )}
                </div>
              );
            })}

            {/* Injected Prayer Blocks */}
            <div className="bg-teal-50/70 border border-teal-200/60 rounded-2xl p-3 text-xs text-teal-900 space-y-2">
              <span className="font-bold text-teal-950 block">Prières protégées de la journée (Rabat)</span>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                {prayerData.prayers.map((p) => (
                  <div key={p.name} className="flex justify-between bg-white/70 p-2 rounded-lg">
                    <span className="font-medium">{p.frenchName} ({p.arabicName})</span>
                    <span className="font-bold tabular-nums text-teal-800">{p.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW: SEMAINE (Vue d'ensemble de la semaine) */}
      {viewMode === 'SEMAINE' && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-4">
          <h3 className="font-bold text-[#172B4D] text-sm">Vue hebdomadaire</h3>
          <p className="text-xs text-slate-500">
            Aperçu de la charge de travail et des cours fixes sur la semaine du 12 au 18 octobre 2026.
          </p>

          <div className="space-y-3">
            {[
              { day: 'Lundi 12 oct', count: 3, hours: '4.5h', note: 'Normal' },
              { day: 'Mardi 13 oct (Aujourd’hui)', count: daySessions.length, hours: '4.0h', note: 'Normal' },
              { day: 'Mercredi 14 oct', count: 2, hours: '3.0h', note: 'Allégé' },
              { day: 'Jeudi 15 oct', count: 4, hours: '5.0h', note: 'TD Algorithmique' },
              { day: 'Vendredi 16 oct', count: 2, hours: '2.5h', note: 'Jumuah protégée' },
              { day: 'Samedi 17 oct', count: 1, hours: '1.5h', note: 'Sport & Révisions' },
              { day: 'Dimanche 18 oct', count: 0, hours: '0.0h', note: 'Repos & Famille' }
            ].map((d, i) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-900 block">{d.day}</span>
                  <span className="text-[11px] text-slate-500">{d.note}</span>
                </div>
                <div className="text-right">
                  <span className="font-bold text-[#172B4D] block tabular-nums">{d.hours}</span>
                  <span className="text-[10px] text-slate-400">{d.count} sessions</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW: MOIS (Jalons, examens et échéances) */}
      {viewMode === 'MOIS' && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-[#172B4D] text-sm">Octobre 2026</h3>
            <span className="text-xs text-teal-700 font-semibold">Semestre d'Automne</span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
              <span className="font-bold text-blue-900 block">15 Octobre — Rendu d'étape</span>
              <p className="text-[11px] text-blue-800 mt-0.5">
                Spécifications fonctionnelles et diagramme de classes (Projet Open Data Rabat).
              </p>
            </div>
            <div className="p-3 rounded-xl bg-purple-50 border border-purple-200">
              <span className="font-bold text-purple-900 block">30 Octobre — Jalons d'ingestion</span>
              <p className="text-[11px] text-purple-800 mt-0.5">
                Module d'ingestion de données temps réel.
              </p>
            </div>
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
              <span className="font-bold text-amber-900 block">19 Décembre — Début session d'examens</span>
              <p className="text-[11px] text-amber-800 mt-0.5">
                Transition automatique vers la période "Session d'Examens Finaux".
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
