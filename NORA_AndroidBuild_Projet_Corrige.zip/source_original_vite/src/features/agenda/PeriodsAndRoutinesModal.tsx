import React, { useState } from 'react';
import { X, Calendar, Layers, Plus, Trash2, Check, Clock } from 'lucide-react';
import { db } from '../../services/storage/database';
import { SchedulePeriod, RecurringRule } from '../../types';

interface PeriodsAndRoutinesModalProps {
  initialTab?: 'PERIODS' | 'ROUTINES';
  onClose: () => void;
  onDataChanged: () => void;
}

export const PeriodsAndRoutinesModal: React.FC<PeriodsAndRoutinesModalProps> = ({
  initialTab = 'PERIODS',
  onClose,
  onDataChanged
}) => {
  const [tab, setTab] = useState<'PERIODS' | 'ROUTINES'>(initialTab);
  const periods = db.getSchedulePeriods();
  const rules = db.getRecurringRules();

  const [newPeriodName, setNewPeriodName] = useState('');
  const [newPeriodStart, setNewPeriodStart] = useState('2026-10-01');
  const [newPeriodEnd, setNewPeriodEnd] = useState('2027-01-31');

  const handleAddPeriod = () => {
    if (!newPeriodName.trim()) return;
    db.saveSchedulePeriod({
      id: 'per-' + Date.now(),
      name: newPeriodName.trim(),
      startDate: newPeriodStart,
      endDate: newPeriodEnd,
      isActive: false
    });
    setNewPeriodName('');
    onDataChanged();
  };

  const handleToggleActivePeriod = (p: SchedulePeriod) => {
    periods.forEach((item) => {
      item.isActive = item.id === p.id ? !item.isActive : false;
      db.saveSchedulePeriod(item);
    });
    onDataChanged();
  };

  const handleDeleteRule = (id: string) => {
    db.deleteRecurringRule(id);
    onDataChanged();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end">
      <div className="w-full max-h-[85vh] bg-white rounded-t-3xl flex flex-col overflow-hidden animate-slideUp shadow-2xl">
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-2.5 shrink-0" />

        <div className="px-5 pb-3 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-[#172B4D]">Périodes & Routines de cours</h2>
            <p className="text-xs text-slate-500">Gestion des semestres académiques et cours fixes</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-100 px-5 text-xs font-semibold">
          <button
            onClick={() => setTab('PERIODS')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              tab === 'PERIODS' ? 'border-[#172B4D] text-[#172B4D]' : 'border-transparent text-slate-400'
            }`}
          >
            Périodes d'emploi du temps
          </button>
          <button
            onClick={() => setTab('ROUTINES')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              tab === 'ROUTINES' ? 'border-[#172B4D] text-[#172B4D]' : 'border-transparent text-slate-400'
            }`}
          >
            Routines récurrentes
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {tab === 'PERIODS' ? (
            <div className="space-y-4">
              <p className="text-slate-600 text-[11px]">
                Chaque période définit les cours actifs. À la fin de la période (ex : fin du semestre 1), les cours s'arrêtent automatiquement sans supprimer vos routines personnelles.
              </p>

              {/* Add period box */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">Créer une période</span>
                <input
                  type="text"
                  value={newPeriodName}
                  onChange={(e) => setNewPeriodName(e.target.value)}
                  placeholder="Ex : Semestre Printemps 2027"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    value={newPeriodStart}
                    onChange={(e) => setNewPeriodStart(e.target.value)}
                    className="border border-slate-300 rounded-xl px-3 py-1.5 text-xs"
                  />
                  <input
                    type="date"
                    value={newPeriodEnd}
                    onChange={(e) => setNewPeriodEnd(e.target.value)}
                    className="border border-slate-300 rounded-xl px-3 py-1.5 text-xs"
                  />
                </div>
                <button
                  onClick={handleAddPeriod}
                  className="w-full py-2 bg-[#172B4D] text-white rounded-xl font-semibold text-xs"
                >
                  Ajouter la période
                </button>
              </div>

              {/* Periods List */}
              <div className="space-y-2">
                {periods.map((p) => (
                  <div
                    key={p.id}
                    className="p-3.5 rounded-2xl border border-slate-200 bg-white flex items-center justify-between shadow-sm"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{p.name}</span>
                        {p.isActive && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                            Active
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500">
                        Du {p.startDate} au {p.endDate}
                      </span>
                    </div>

                    <button
                      onClick={() => handleToggleActivePeriod(p)}
                      className={`px-3 py-1.5 rounded-xl font-semibold text-xs transition-colors ${
                        p.isActive
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {p.isActive ? 'Active' : 'Activer'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <span className="font-bold text-slate-800 block">
                Routines hebdomadaires configurées ({rules.length})
              </span>
              <p className="text-[11px] text-slate-500">
                Génération paresseuse (lazy generation) des occurrences dans l'agenda sans surcharger la base de données.
              </p>

              {rules.map((r) => (
                <div key={r.id} className="p-3.5 rounded-2xl border border-slate-200 bg-white flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{r.title}</h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{r.startTime} – {r.endTime}</span>
                      {r.location && <span>· 📍 {r.location}</span>}
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteRule(r.id)}
                    className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
