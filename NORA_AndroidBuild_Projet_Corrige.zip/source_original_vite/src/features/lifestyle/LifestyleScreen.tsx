import React, { useState } from 'react';
import { 
  Moon, 
  Sun, 
  ArrowLeft, 
  Battery, 
  Heart, 
  ShieldCheck, 
  Check, 
  Coffee,
  AlertCircle
} from 'lucide-react';
import { AppSettings, OperatingMode, EnergyCheckIn } from '../../types';
import { db } from '../../services/storage/database';

interface LifestyleScreenProps {
  settings: AppSettings;
  onBack: () => void;
  onDataChanged: () => void;
}

export const LifestyleScreen: React.FC<LifestyleScreenProps> = ({
  settings,
  onBack,
  onDataChanged
}) => {
  const [bedtime, setBedtime] = useState(settings.sleepPreference.targetBedtime);
  const [wakeTime, setWakeTime] = useState(settings.sleepPreference.targetWakeTime);
  const [allowNap, setAllowNap] = useState(settings.sleepPreference.allowNap);
  const [energyLevel, setEnergyLevel] = useState<'FAIBLE' | 'NORMALE' | 'ELEVEE'>('NORMALE');
  const [sleepQuality, setSleepQuality] = useState<'MAUVAIS' | 'MOYEN' | 'BON' | 'EXCELLENT'>('BON');

  const handleSaveSleep = () => {
    settings.sleepPreference.targetBedtime = bedtime;
    settings.sleepPreference.targetWakeTime = wakeTime;
    settings.sleepPreference.allowNap = allowNap;
    db.updateSettings(settings);
    onDataChanged();
    alert('Préférences de sommeil et de récupération mises à jour !');
  };

  const handleSaveEnergyCheckIn = () => {
    db.saveEnergyCheckIn({
      id: 'eng-' + Date.now(),
      date: '2026-10-13',
      level: energyLevel,
      sleepQuality: sleepQuality
    });

    if (energyLevel === 'FAIBLE' || sleepQuality === 'MAUVAIS') {
      settings.operatingMode = 'RECOVERY';
      db.updateSettings(settings);
      alert('Niveau d\'énergie faible détecté : Le "Mode Récupération" a été activé automatiquement pour alléger ta journée.');
    } else {
      alert('Point d\'énergie du jour enregistré !');
    }
    onDataChanged();
  };

  const setMode = (m: OperatingMode) => {
    settings.operatingMode = m;
    db.updateSettings(settings);
    onDataChanged();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Vie Quotidienne & Sommeil</h1>
          <p className="text-[11px] text-slate-500">Protection du repos, sommeil autour du Fajr et énergie</p>
        </div>
      </div>

      {/* Operating Mode Selector (Section 27) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
        <span className="font-bold text-[#172B4D] text-sm block">Modes de fonctionnement NORA</span>
        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'NORMAL', label: 'Normal', desc: 'Routine équilibrée' },
            { id: 'HEAVY_WEEK', label: 'Semaine chargée', desc: 'Focus échéances strictes' },
            { id: 'RECOVERY', label: 'Récupération', desc: 'Charge réduite, repos' },
            { id: 'VACATION', label: 'Vacances', desc: 'Routines suspendues' }
          ].map((m) => {
            const isSel = settings.operatingMode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setMode(m.id as OperatingMode)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isSel
                    ? 'border-[#172B4D] bg-[#172B4D] text-white shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <span className="font-bold block text-xs">{m.label}</span>
                <span className={`text-[10px] ${isSel ? 'text-slate-300' : 'text-slate-500'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sleep Protection */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
        <div className="flex items-center gap-2">
          <Moon className="w-4 h-4 text-purple-600" />
          <h2 className="font-bold text-sm text-[#172B4D]">Fenetres de sommeil protégé (Niveau 1)</h2>
        </div>
        <p className="text-slate-600 text-[11px] leading-relaxed">
          Le sommeil est une contrainte dure non négociable. NORA ne réduira jamais automatiquement tes heures de sommeil pour caser du travail.
        </p>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Coucher souhaité</label>
            <input
              type="time"
              value={bedtime}
              onChange={(e) => setBedtime(e.target.value)}
              className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
            />
          </div>
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Réveil souhaité</label>
            <input
              type="time"
              value={wakeTime}
              onChange={(e) => setWakeTime(e.target.value)}
              className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 pt-1">
          <input
            type="checkbox"
            id="napToggle"
            checked={allowNap}
            onChange={(e) => setAllowNap(e.target.checked)}
            className="w-4 h-4 text-purple-600 rounded"
          />
          <label htmlFor="napToggle" className="text-slate-700 font-medium">
            Sieste réparatrice permise (25 min en début d'après-midi)
          </label>
        </div>

        <button
          onClick={handleSaveSleep}
          className="w-full py-2.5 rounded-xl bg-[#172B4D] text-white font-semibold text-xs"
        >
          Enregistrer le sommeil
        </button>
      </div>

      {/* Daily Energy & Sleep Check-In */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
        <div className="flex items-center gap-2">
          <Battery className="w-4 h-4 text-emerald-600" />
          <h3 className="font-bold text-sm text-[#172B4D]">Bilan d'énergie du jour</h3>
        </div>

        <div>
          <label className="block text-slate-700 font-semibold mb-1.5">Comment te sens-tu ?</label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'FAIBLE', label: 'Faible', color: 'bg-rose-50 border-rose-200 text-rose-800' },
              { id: 'NORMALE', label: 'Normale', color: 'bg-teal-50 border-teal-200 text-teal-800' },
              { id: 'ELEVEE', label: 'Élevée', color: 'bg-emerald-50 border-emerald-200 text-emerald-800' }
            ].map((e) => (
              <button
                key={e.id}
                onClick={() => setEnergyLevel(e.id as any)}
                className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                  energyLevel === e.id ? 'ring-2 ring-slate-800 ' + e.color : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                {e.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-slate-700 font-semibold mb-1.5">Qualité de ta nuit :</label>
          <div className="grid grid-cols-4 gap-1.5">
            {['MAUVAIS', 'MOYEN', 'BON', 'EXCELLENT'].map((q) => (
              <button
                key={q}
                onClick={() => setSleepQuality(q as any)}
                className={`py-1.5 rounded-xl border text-[11px] font-semibold ${
                  sleepQuality === q ? 'bg-purple-600 text-white border-purple-600' : 'bg-slate-50 border-slate-200 text-slate-600'
                }`}
              >
                {q.charAt(0) + q.slice(1).toLowerCase()}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleSaveEnergyCheckIn}
          className="w-full py-2.5 rounded-xl bg-teal-700 text-white font-semibold text-xs hover:bg-teal-800"
        >
          Valider le check-in
        </button>
      </div>
    </div>
  );
};
