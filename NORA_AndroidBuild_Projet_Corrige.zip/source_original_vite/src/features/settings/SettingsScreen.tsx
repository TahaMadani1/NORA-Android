import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  ArrowLeft, 
  Download, 
  Upload, 
  RefreshCw, 
  ShieldCheck, 
  Smartphone, 
  Database,
  FileCode,
  Clock,
  MapPin
} from 'lucide-react';
import { AppSettings } from '../../types';
import { db } from '../../services/storage/database';
import { toastService } from '../../services/feedback/toastService';

interface SettingsScreenProps {
  settings: AppSettings;
  onBack: () => void;
  onDataChanged: () => void;
  onOpenTests?: () => void;
  onOpenOnboarding?: () => void;
  onOpenInstallModal?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onBack,
  onDataChanged,
  onOpenTests,
  onOpenOnboarding,
  onOpenInstallModal
}) => {
  const [workloadLimit, setWorkloadLimit] = useState(settings.discretionaryWorkloadLimitHours);
  const [bufferRatio, setBufferRatio] = useState(settings.bufferPercentage);
  const [focusBlock, setFocusBlock] = useState(settings.focusBlockMinutes);

  const handleSavePreferences = () => {
    settings.discretionaryWorkloadLimitHours = workloadLimit;
    settings.bufferPercentage = bufferRatio;
    settings.focusBlockMinutes = focusBlock;
    db.updateSettings(settings);
    onDataChanged();
    toastService.success('Préférences générales enregistrées !');
  };

  const handleExportJSON = () => {
    const jsonStr = db.exportDatabaseJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NORA_Sauvegarde_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toastService.info('Exportation JSON téléchargée !');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = db.importDatabaseJSON(content);
      if (res.success) {
        onDataChanged();
        toastService.success('Sauvegarde restaurée avec succès !');
      } else {
        toastService.error('Erreur de restauration : ' + res.error);
      }
    };
    reader.readAsText(file);
  };

  const handleExportICS = () => {
    const sessions = db.getSessions();
    let icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//NORA//Ma Secretaire Personnelle//FR',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH'
    ];

    sessions.forEach((s) => {
      const dateNoDash = s.date.replace(/-/g, '');
      const startT = s.startTime.replace(/:/g, '') + '00';
      const endT = s.endTime.replace(/:/g, '') + '00';

      icsContent.push('BEGIN:VEVENT');
      icsContent.push(`UID:nora-${s.id}@personalsecretary.local`);
      icsContent.push(`DTSTART;TZID=Africa/Casablanca:${dateNoDash}T${startT}`);
      icsContent.push(`DTEND;TZID=Africa/Casablanca:${dateNoDash}T${endT}`);
      icsContent.push(`SUMMARY:${s.title}`);
      if (s.location) icsContent.push(`LOCATION:${s.location}`);
      icsContent.push('END:VEVENT');
    });

    icsContent.push('END:VCALENDAR');

    const blob = new Blob([icsContent.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NORA_Calendrier_${new Date().toISOString().split('T')[0]}.ics`;
    a.click();
    URL.revokeObjectURL(url);
    toastService.info('Fichier iCalendar (.ics) généré et téléchargé !');
  };

  const handleResetData = () => {
    db.resetToDefault();
    onDataChanged();
    toastService.warning('Données réinitialisées aux valeurs saines de Rabat.');
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20 text-xs">
      {/* Top Bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Paramètres & Sauvegardes</h1>
          <p className="text-[11px] text-slate-500">Configuration locale · Aucune dépendance cloud obligatoire</p>
        </div>
      </div>

      {/* Regional & Timezone settings */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        <span className="font-bold text-[#172B4D] text-sm block">Localisation & Fuseau</span>
        <div className="grid grid-cols-2 gap-3 text-slate-700">
          <div className="p-3 bg-slate-50 rounded-xl">
            <span className="text-[10px] text-slate-400 block">Ville par défaut</span>
            <span className="font-bold text-slate-900">Rabat / Salé</span>
          </div>
          <div className="p-3 bg-slate-50 rounded-xl">
            <span className="text-[10px] text-slate-400 block">Fuseau horaire</span>
            <span className="font-bold text-slate-900">Africa/Casablanca (24h)</span>
          </div>
        </div>
      </div>

      {/* Workload and focus capacity */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        <span className="font-bold text-[#172B4D] text-sm block">Capacité & Travail profond</span>
        
        <div>
          <label className="block text-slate-700 font-semibold mb-1">
            Charge discrétionnaire max par jour (heures) : {workloadLimit}h
          </label>
          <input
            type="range"
            min="2"
            max="8"
            value={workloadLimit}
            onChange={(e) => setWorkloadLimit(parseInt(e.target.value, 10))}
            className="w-full accent-[#172B4D]"
          />
        </div>

        <div>
          <label className="block text-slate-700 font-semibold mb-1">
            Marge de respiration / buffer ({bufferRatio}%)
          </label>
          <input
            type="range"
            min="10"
            max="40"
            step="5"
            value={bufferRatio}
            onChange={(e) => setBufferRatio(parseInt(e.target.value, 10))}
            className="w-full accent-[#172B4D]"
          />
        </div>

        <div>
          <label className="block text-slate-700 font-semibold mb-1">
            Bloc de concentration focus (minutes) : {focusBlock}m
          </label>
          <input
            type="number"
            step="5"
            value={focusBlock}
            onChange={(e) => setFocusBlock(parseInt(e.target.value, 10) || 50)}
            className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
          />
        </div>

        <button
          onClick={handleSavePreferences}
          className="w-full py-2.5 rounded-xl bg-[#172B4D] text-white font-semibold hover:bg-slate-800"
        >
          Enregistrer les règles
        </button>
      </div>

      {/* Backup, Export & Calendar Sync */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-teal-700" />
          <span className="font-bold text-[#172B4D] text-sm">Sauvegarde & Exportation locale</span>
        </div>
        <p className="text-slate-600 text-[11px] leading-relaxed">
          Toutes tes données sont stockées en local sur ton appareil. Tu peux exporter une copie intégrale ou un fichier de calendrier ICS.
        </p>

        <div className="space-y-2 pt-1">
          <button
            onClick={handleExportJSON}
            className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Exporter la base complète (.json)</span>
          </button>

          <label className="w-full py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold flex items-center justify-center gap-2 cursor-pointer">
            <Upload className="w-4 h-4 text-slate-600" />
            <span>Restaurer une sauvegarde (.json)</span>
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>

          <button
            onClick={handleExportICS}
            className="w-full py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 font-semibold flex items-center justify-center gap-2"
          >
            <FileCode className="w-4 h-4 text-teal-700" />
            <span>Exporter le planning en Calendrier (.ics)</span>
          </button>
        </div>
      </div>

      {/* Standalone Android APK Instructions (Section 35) */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 space-y-2.5 shadow-md">
        <div className="flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-teal-300" />
          <span className="font-bold text-sm text-teal-200">Génération APK Android autonome</span>
        </div>
        <p className="text-slate-300 text-[11px] leading-relaxed">
          NORA est configurée pour Expo Application Services (EAS Build) avec le profil APK preview pour installation directe sur votre téléphone Android.
        </p>
        <div className="p-2.5 bg-slate-950 rounded-xl font-mono text-[11px] text-teal-300 border border-slate-800">
          eas build -p android --profile preview
        </div>
        <div className="text-[10px] text-slate-400">
          Package ID : com.nora.personalsecretary · Permissions alarmes exactes et notifications configurées dans app.json et eas.json.
        </div>
        {onOpenInstallModal && (
          <button
            onClick={onOpenInstallModal}
            className="w-full mt-2 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold flex items-center justify-center gap-2 shadow-sm transition-colors text-xs"
          >
            <Smartphone className="w-4 h-4 text-slate-950" />
            <span>Assistant d'installation APK & Mobile (QR Code & Guide)</span>
          </button>
        )}
      </div>

      {/* Acceptance Test Suite & Onboarding (Section 33 & 34) */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-2.5">
        <span className="font-bold text-[#172B4D] text-sm block">Vérification & Tests d'Acceptation</span>
        <p className="text-slate-600 text-[11px] leading-relaxed">
          Exécutez le banc d'essais validant les 28 scénarios fonctionnels (persistance, prières Habous, réconciliation, et invariants).
        </p>

        {onOpenTests && (
          <button
            onClick={onOpenTests}
            className="w-full py-2.5 rounded-xl bg-teal-800 hover:bg-teal-900 text-white font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <ShieldCheck className="w-4 h-4 text-teal-300" />
            <span>Lancer les 28 Tests d'Acceptation</span>
          </button>
        )}

        {onOpenOnboarding && (
          <button
            onClick={onOpenOnboarding}
            className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
          >
            Revoir l'assistant de bienvenue (Onboarding)
          </button>
        )}
      </div>

      {/* Danger Zone */}
      <div className="pt-2">
        <button
          onClick={handleResetData}
          className="w-full py-2.5 rounded-xl border border-rose-200 text-rose-700 font-semibold text-xs hover:bg-rose-50"
        >
          Réinitialiser toutes les données (Rétablir l'état par défaut)
        </button>
      </div>
    </div>
  );
};
