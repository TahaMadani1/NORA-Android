import React, { useState } from 'react';
import { 
  Play, 
  CheckCircle, 
  Clock, 
  Sparkles, 
  AlertTriangle, 
  ShieldCheck, 
  Calendar, 
  SlidersHorizontal,
  ChevronRight,
  MapPin,
  Lock,
  RotateCcw,
  LifeBuoy
} from 'lucide-react';
import { Task, ScheduledSession, AppSettings } from '../../types';
import { CATEGORY_THEMES, PRIORITY_THEMES } from '../../theme/colors';
import { getDailyPrayerSchedule, parseHHMMToMinutes } from '../../services/prayerTimes/rabatPrayerService';
import { calculateDaySchedule } from '../../services/scheduling/schedulingEngine';
import { db } from '../../services/storage/database';
import { soundService } from '../../services/audio/soundService';

interface TodayScreenProps {
  settings: AppSettings;
  onOpenTaskDetail: (taskId: string) => void;
  onStartFocus: (session: ScheduledSession) => void;
  onOpenReorganize: () => void;
  onOpenPrayers: () => void;
  onDataChanged: () => void;
  onOpenEmergency?: () => void;
}

export const TodayScreen: React.FC<TodayScreenProps> = ({
  settings,
  onOpenTaskDetail,
  onStartFocus,
  onOpenReorganize,
  onOpenPrayers,
  onDataChanged,
  onOpenEmergency
}) => {
  const todayStr = '2026-10-13'; // Local current date
  const currentTimeHHMM = '11:45';

  const scheduleSummary = calculateDaySchedule(todayStr, settings);
  const prayerData = getDailyPrayerSchedule(todayStr, settings, currentTimeHHMM);

  const handleCompleteSession = (session: ScheduledSession) => {
    session.status = 'CONFIRMED';
    session.confirmedMinutes = parseHHMMToMinutes(session.endTime) - parseHHMMToMinutes(session.startTime);
    db.saveSession(session);

    if (session.taskId) {
      const task = db.getTaskById(session.taskId);
      if (task) {
        task.remainingMinutes = Math.max(0, task.remainingMinutes - (session.confirmedMinutes || 60));
        if (task.remainingMinutes === 0) {
          task.status = 'COMPLETED';
          task.completedAt = new Date().toISOString();
        } else {
          task.status = 'PARTIALLY_COMPLETED';
        }
        db.saveTask(task);
      }
    }
    soundService.playTaskCompleted();
    onDataChanged();
  };

  const handlePostponeSession = (session: ScheduledSession) => {
    soundService.playSnooze();
    session.status = 'SCHEDULED';
    // Move 1 hour later
    const sM = parseHHMMToMinutes(session.startTime) + 60;
    const eM = parseHHMMToMinutes(session.endTime) + 60;
    const formatM = (m: number) => {
      const h = Math.floor(m / 60) % 24;
      const min = m % 60;
      return `${h.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;
    };
    session.startTime = formatM(sM);
    session.endTime = formatM(eM);
    db.saveSession(session);

    if (session.taskId) {
      const task = db.getTaskById(session.taskId);
      if (task) {
        task.postponementCount += 1;
        task.status = 'POSTPONED';
        db.saveTask(task);
      }
    }
    onDataChanged();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Welcome Card */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-[11px] font-semibold tracking-wider text-slate-500 uppercase">
              Mardi 13 octobre · Rabat
            </span>
            <h1 className="text-xl font-bold text-[#172B4D] tracking-tight mt-0.5">
              Bonjour ! Voici ton programme.
            </h1>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {onOpenEmergency && (
              <button
                onClick={onOpenEmergency}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 text-[11px] font-semibold border border-amber-200/60 transition-colors"
                title="Je n'ai pas suivi mon planning : rattrapage immédiat"
              >
                <LifeBuoy className="w-3.5 h-3.5 text-amber-600" />
                <span>Rattrapage</span>
              </button>
            )}
            <button
              onClick={onOpenReorganize}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#172B4D] text-[11px] font-semibold transition-colors"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Réorganiser</span>
            </button>
          </div>
        </div>

        {/* Workload Summary Bar */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-center">
          <div className="p-2 rounded-xl bg-slate-50">
            <span className="text-[10px] text-slate-500 block">Temps planifié</span>
            <span className="text-sm font-bold text-[#172B4D] tabular-nums">
              {Math.floor(scheduleSummary.totalPlannedMinutes / 60)}h
              {(scheduleSummary.totalPlannedMinutes % 60).toString().padStart(2, '0')}
            </span>
          </div>
          <div className="p-2 rounded-xl bg-teal-50/60">
            <span className="text-[10px] text-teal-700 block">Temps libre</span>
            <span className="text-sm font-bold text-teal-900 tabular-nums">
              ~{Math.round(scheduleSummary.remainingAvailableMinutes / 60)}h
              {(Math.round(scheduleSummary.remainingAvailableMinutes) % 60).toString().padStart(2, '0')}
            </span>
          </div>
          <div className="p-2 rounded-xl bg-slate-50">
            <span className="text-[10px] text-slate-500 block">Prières protégées</span>
            <span className="text-sm font-bold text-teal-800 tabular-nums">5 / 5</span>
          </div>
        </div>
      </div>

      {/* Official Prayer Widget (Habous Rabat) */}
      <div className="bg-gradient-to-r from-teal-900 to-[#172B4D] rounded-2xl p-4 text-white shadow-md relative overflow-hidden">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-teal-300" />
            <span className="text-xs font-bold text-teal-200">Horaires Officiels Habous · Rabat</span>
          </div>
          <button
            onClick={onOpenPrayers}
            className="text-[11px] text-teal-300 hover:text-white flex items-center gap-0.5"
          >
            Détails & Mosquée <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {prayerData.nextPrayer && (
          <div className="mb-3 bg-white/10 rounded-xl p-2.5 flex items-center justify-between border border-white/15">
            <div>
              <span className="text-[10px] text-teal-200 uppercase font-semibold">Prochaine prière</span>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>{prayerData.nextPrayer.frenchName}</span>
                <span className="text-xs text-teal-300 font-normal">{prayerData.nextPrayer.arabicName}</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-base font-extrabold text-amber-300 tabular-nums">
                {prayerData.nextPrayer.time}
              </span>
              <span className="text-[10px] text-teal-200 block">
                Créneau protégé : {prayerData.nextPrayer.protectedStart} – {prayerData.nextPrayer.protectedEnd}
              </span>
            </div>
          </div>
        )}

        {/* 5 Daily prayer pills */}
        <div className="grid grid-cols-5 gap-1.5 text-center text-xs">
          {prayerData.prayers.map((p) => (
            <div
              key={p.name}
              className={`p-1.5 rounded-lg border transition-all ${
                p.isNext
                  ? 'bg-amber-400 text-slate-900 font-bold border-amber-300 shadow'
                  : 'bg-white/10 border-white/10 text-teal-100'
              }`}
            >
              <div className="text-[10px] opacity-80">{p.frenchName.split(' ')[0]}</div>
              <div className="text-xs font-semibold tabular-nums mt-0.5">{p.time}</div>
            </div>
          ))}
        </div>
      </div>

      {/* NORA te conseille (strictly real rules) */}
      {scheduleSummary.adviceList.length > 0 && (
        <div className="bg-amber-50/80 border border-amber-200/80 rounded-2xl p-3.5 space-y-1.5 text-xs text-amber-900">
          <div className="flex items-center gap-1.5 font-bold text-amber-950">
            <Sparkles className="w-4 h-4 text-amber-600" />
            <span>NORA te conseille</span>
          </div>
          {scheduleSummary.adviceList.map((adv, idx) => (
            <p key={idx} className="text-[11px] leading-relaxed text-amber-900">
              · {adv}
            </p>
          ))}
        </div>
      )}

      {/* Schedule Conflicts Alert if any */}
      {scheduleSummary.conflicts.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-3.5 space-y-1 text-xs text-red-900">
          <div className="flex items-center gap-1.5 font-bold text-red-950">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <span>Conflit de contraintes détecté</span>
          </div>
          {scheduleSummary.conflicts.map((c, i) => (
            <p key={i} className="text-[11px] text-red-800 leading-tight">
              {c}
            </p>
          ))}
        </div>
      )}

      {/* Chronological Schedule Section */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-bold text-[#172B4D]">Programme chronologique</h2>
          <span className="text-[11px] text-slate-500 font-medium">
            {scheduleSummary.sessions.length} sessions prévues
          </span>
        </div>

        {scheduleSummary.sessions.length === 0 ? (
          <div className="p-6 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500">
            Aucune session planifiée pour aujourd'hui. Appuie sur le + pour ajouter une tâche ou un cours.
          </div>
        ) : (
          scheduleSummary.sessions.map((sess) => {
            const cat = CATEGORY_THEMES[sess.category] || CATEGORY_THEMES.STUDIES;
            const prio = PRIORITY_THEMES[sess.priority] || PRIORITY_THEMES.P3;
            const isCompleted = sess.status === 'CONFIRMED';

            return (
              <div
                key={sess.id}
                className={`bg-white rounded-2xl p-3.5 border transition-all shadow-sm ${
                  isCompleted ? 'border-emerald-200 opacity-75' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    {/* Time & Badges */}
                    <div className="flex items-center gap-2 text-xs mb-1">
                      <span className="font-bold text-[#172B4D] tabular-nums">
                        {sess.startTime} – {sess.endTime}
                      </span>
                      <span
                        className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                        style={{ backgroundColor: cat.bgLight, color: cat.color }}
                      >
                        {cat.label}
                      </span>
                      <span
                        className="text-[10px] font-bold px-1.5 py-0.2 rounded"
                        style={{ backgroundColor: prio.badgeBg, color: prio.text }}
                      >
                        {prio.label.split(' ')[0]}
                      </span>
                      {sess.isLocked && (
                        <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                          <Lock className="w-2.5 h-2.5" /> Fixe
                        </span>
                      )}
                    </div>

                    {/* Title */}
                    <h3
                      className={`font-semibold text-sm leading-snug ${
                        isCompleted ? 'line-through text-slate-500' : 'text-[#0F172A]'
                      }`}
                    >
                      {sess.title}
                    </h3>

                    {sess.location && (
                      <div className="flex items-center gap-1 text-[11px] text-slate-500 mt-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{sess.location}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Quick Actions */}
                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-1 text-xs">
                  {!isCompleted ? (
                    <>
                      <button
                        onClick={() => onStartFocus(sess)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-medium text-xs transition-colors"
                      >
                        <Play className="w-3 h-3 fill-white" />
                        <span>Commencer</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleCompleteSession(sess)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-medium transition-colors"
                        >
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Terminer</span>
                        </button>
                        <button
                          onClick={() => handlePostponeSession(sess)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                          <span>+1h</span>
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="w-full flex items-center justify-between text-emerald-700 text-xs font-semibold">
                      <span>✓ Session confirmée</span>
                      {sess.taskId && (
                        <button
                          onClick={() => onOpenTaskDetail(sess.taskId!)}
                          className="text-slate-500 text-[11px] hover:text-[#172B4D]"
                        >
                          Voir la tâche master
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
