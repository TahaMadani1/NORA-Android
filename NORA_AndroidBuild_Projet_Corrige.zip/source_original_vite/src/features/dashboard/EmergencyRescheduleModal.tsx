import React, { useState } from 'react';
import { 
  X, 
  LifeBuoy, 
  ShieldCheck, 
  ArrowRight, 
  Clock, 
  Sun, 
  Moon, 
  CheckCircle,
  RotateCcw
} from 'lucide-react';
import { db } from '../../services/storage/database';
import { parseHHMMToMinutes } from '../../services/prayerTimes/rabatPrayerService';
import { soundService } from '../../services/audio/soundService';
import { toastService } from '../../services/feedback/toastService';

interface EmergencyRescheduleModalProps {
  onClose: () => void;
  onDataChanged: () => void;
}

export const EmergencyRescheduleModal: React.FC<EmergencyRescheduleModalProps> = ({
  onClose,
  onDataChanged
}) => {
  const [selectedOption, setSelectedOption] = useState<'ESSENTIALS_ONLY' | 'SHIFT_FORWARD' | 'RESET_TOMORROW'>('ESSENTIALS_ONLY');

  const handleApply = () => {
    soundService.playSnooze();
    const todaySessions = db.getSessionsForDate('2026-10-13');

    if (selectedOption === 'ESSENTIALS_ONLY') {
      // Keep only Level 1 hard constraints and P1 critical tasks, cancel or postpone P3/P4 flexible items
      todaySessions.forEach((s) => {
        if (s.constraintLevel !== 'LEVEL_1' && !s.isLocked && s.priority !== 'P1') {
          s.status = 'CANCELLED';
          db.saveSession(s);
          if (s.taskId) {
            const t = db.getTaskById(s.taskId);
            if (t && t.status !== 'COMPLETED') {
              t.postponementCount += 1;
              t.status = 'POSTPONED';
              db.saveTask(t);
            }
          }
        }
      });
      toastService.warning('Mode "Sauver l\'essentiel" activé : Seules les prières, contraintes dures et la priorité P1 sont maintenues.');
    } else if (selectedOption === 'SHIFT_FORWARD') {
      // Shift all remaining unconfirmed sessions by 1 hour (60m)
      todaySessions.forEach((s) => {
        if (s.status === 'SCHEDULED' && !s.isLocked && s.constraintLevel !== 'LEVEL_1') {
          const startM = parseHHMMToMinutes(s.startTime) + 60;
          const endM = parseHHMMToMinutes(s.endTime) + 60;
          const formatM = (m: number) => {
            const h = Math.floor(m / 60) % 24;
            const min = m % 60;
            return `${h.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;
          };
          s.startTime = formatM(startM);
          s.endTime = formatM(endM);
          db.saveSession(s);
        }
      });
      toastService.info('Planning décalé d\'une heure avec maintien des prières et du repos.');
    } else if (selectedOption === 'RESET_TOMORROW') {
      // Postpone all remaining flexible sessions to tomorrow (2026-10-14)
      todaySessions.forEach((s) => {
        if (s.status === 'SCHEDULED' && !s.isLocked && s.constraintLevel !== 'LEVEL_1') {
          s.date = '2026-10-14';
          db.saveSession(s);
          if (s.taskId) {
            const t = db.getTaskById(s.taskId);
            if (t) {
              t.postponementCount += 1;
              t.targetDate = '2026-10-14';
              db.saveTask(t);
            }
          }
        }
      });
      toastService.success('Fin de journée libérée. Toutes les tâches restantes ont été reportées à demain.');
    }

    onDataChanged();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end p-2 sm:p-4">
      <div className="w-full max-w-md mx-auto bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col animate-slideUp">
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-3 shrink-0" />

        <div className="px-5 pb-3 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <LifeBuoy className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#172B4D]">Je n'ai pas suivi mon planning</h2>
              <p className="text-[10px] text-slate-500">Un imprévu arrive. Zéro culpabilité, réadaptation immédiate.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-3.5 text-xs">
          <div className="p-3 bg-teal-50 border border-teal-200 rounded-2xl flex items-start gap-2.5 text-teal-900">
            <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              « NORA adapte mon planning à ma vraie vie, au lieu de forcer ma vie à suivre un horaire irréaliste. »
            </p>
          </div>

          <div className="space-y-2">
            {/* Option 1 */}
            <div
              onClick={() => setSelectedOption('ESSENTIALS_ONLY')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                selectedOption === 'ESSENTIALS_ONLY'
                  ? 'border-[#172B4D] ring-2 ring-[#172B4D]/20 bg-slate-50'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-slate-900 text-xs">1. Sauver l'essentiel uniquement</span>
                <span className="text-[10px] bg-red-100 text-red-800 font-bold px-1.5 py-0.2 rounded">P1 & Prières</span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Conserver uniquement les cours obligatoires, les 5 prières et la tâche critique P1. Supprimer la pression superflue pour le reste.
              </p>
            </div>

            {/* Option 2 */}
            <div
              onClick={() => setSelectedOption('SHIFT_FORWARD')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                selectedOption === 'SHIFT_FORWARD'
                  ? 'border-[#172B4D] ring-2 ring-[#172B4D]/20 bg-slate-50'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-slate-900 text-xs">2. Décaler tout de 1 heure</span>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.2 rounded">+60 min</span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Repousser les séances de l'après-midi d'une heure sans empiéter sur l'heure du coucher.
              </p>
            </div>

            {/* Option 3 */}
            <div
              onClick={() => setSelectedOption('RESET_TOMORROW')}
              className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                selectedOption === 'RESET_TOMORROW'
                  ? 'border-[#172B4D] ring-2 ring-[#172B4D]/20 bg-slate-50'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-slate-900 text-xs">3. Clore aujourd'hui et repartir demain</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">Sérénité</span>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Basculer toutes les sessions restantes à demain. Protéger la soirée pour la récupération et un sommeil réparateur.
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 bg-white flex items-center gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700"
          >
            Annuler
          </button>
          <button
            onClick={handleApply}
            className="flex-1 py-3 rounded-xl bg-[#172B4D] hover:bg-slate-800 text-white font-semibold text-xs shadow-md transition-colors"
          >
            Appliquer le rattrapage
          </button>
        </div>
      </div>
    </div>
  );
};
