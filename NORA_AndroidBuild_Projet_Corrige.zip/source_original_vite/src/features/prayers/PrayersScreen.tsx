import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Clock, 
  MapPin, 
  Calendar, 
  Check, 
  Sliders, 
  Bell, 
  ArrowLeft,
  Info,
  Volume2,
  Moon
} from 'lucide-react';
import { AppSettings, PrayerName } from '../../types';
import { getDailyPrayerSchedule, getPrayerTimesForDate } from '../../services/prayerTimes/rabatPrayerService';
import { db } from '../../services/storage/database';
import { soundService } from '../../services/audio/soundService';
import { toastService } from '../../services/feedback/toastService';

interface PrayersScreenProps {
  settings: AppSettings;
  onBack: () => void;
  onDataChanged: () => void;
}

export const PrayersScreen: React.FC<PrayersScreenProps> = ({
  settings,
  onBack,
  onDataChanged
}) => {
  const [selectedDate, setSelectedDate] = useState('2026-10-13');
  const [prepMinutes, setPrepMinutes] = useState(settings.dhuhrProtection.preparationMinutes);
  const [prayerMinutes, setPrayerMinutes] = useState(settings.dhuhrProtection.prayerMinutes);
  const [jumuahPrep, setJumuahPrep] = useState(settings.jumuahSettings.preparationMinutes);
  const [jumuahMosque, setJumuahMosque] = useState(settings.jumuahSettings.mosqueName || '');
  const [isRamadan, setIsRamadan] = useState(!!settings.isRamadanMode);

  const schedule = getDailyPrayerSchedule(selectedDate, settings, '11:45');
  const rawTimes = getPrayerTimesForDate(selectedDate, isRamadan);

  const handleToggleRamadan = () => {
    const newVal = !isRamadan;
    setIsRamadan(newVal);
    settings.isRamadanMode = newVal;
    db.updateSettings(settings);
    onDataChanged();
  };

  const handleTestChime = () => {
    soundService.playPrayerChime();
    toastService.info('Signal acoustique de prière NORA joué !');
  };

  const handleSaveProtection = () => {
    settings.dhuhrProtection.preparationMinutes = prepMinutes;
    settings.dhuhrProtection.prayerMinutes = prayerMinutes;
    settings.jumuahSettings.preparationMinutes = jumuahPrep;
    settings.jumuahSettings.mosqueName = jumuahMosque;
    settings.isRamadanMode = isRamadan;
    db.updateSettings(settings);
    onDataChanged();
    toastService.success('Paramètres de protection des prières sauvegardés !');
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-base font-bold text-[#172B4D]">Horaires Officiels des Prières</h1>
            <p className="text-[11px] text-slate-500">Rabat / Salé · Ministère des Habous</p>
          </div>
        </div>

        <button
          onClick={handleTestChime}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 text-[11px] font-semibold border border-teal-200 transition-colors"
          title="Tester le signal sonore de rappel"
        >
          <Volume2 className="w-3.5 h-3.5 text-teal-600" />
          <span>Écouter Adhan</span>
        </button>
      </div>

      {/* Ramadan Toggle Card */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-sm flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
            <Moon className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-slate-900 block">Heure de Ramadan (UTC+0)</span>
            <span className="text-[10px] text-slate-500">Décalage marocain saisonnier (-1 heure)</span>
          </div>
        </div>
        <button
          onClick={handleToggleRamadan}
          className={`px-3 py-1.5 rounded-xl font-semibold text-xs transition-colors ${
            isRamadan
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          {isRamadan ? 'Actif (UTC+0)' : 'Désactivé (UTC+1)'}
        </button>
      </div>

      {/* Official Habous Attribution Banner */}
      <div className="bg-gradient-to-r from-teal-900 to-[#172B4D] rounded-2xl p-4 text-white space-y-2 shadow-sm">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-teal-300" />
          <span className="font-bold text-sm text-teal-100">
            Source Officielle Vérifiée (habous.gov.ma)
          </span>
        </div>
        <p className="text-xs text-teal-200 leading-relaxed">
          Les 5 prières quotidiennes constituent le Niveau 0 de priorité absolue. Aucune tâche flexible n'est programmée durant leurs intervalles protégés.
        </p>
        <div className="text-[10px] text-teal-300 pt-1 flex items-center justify-between">
          <span>Fuseau horaire : Africa/Casablanca (24h)</span>
          <span>Statut : {rawTimes.source}</span>
        </div>
      </div>

      {/* Prayer Table Cards */}
      <div className="space-y-2.5">
        <h2 className="text-xs font-bold text-slate-600 px-1 uppercase tracking-wider">
          Programme du {selectedDate}
        </h2>

        {schedule.prayers.map((p) => (
          <div
            key={p.name}
            className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-sm flex items-center justify-between"
          >
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-[#172B4D]">{p.frenchName}</span>
                <span className="text-xs text-teal-800 font-semibold">{p.arabicName}</span>
              </div>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Créneau protégé : {p.protectedStart} – {p.protectedEnd}
              </span>
            </div>

            <div className="text-right">
              <span className="text-lg font-extrabold text-[#172B4D] tabular-nums block">
                {p.time}
              </span>
              {p.isNext && (
                <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  Suivante
                </span>
              )}
            </div>
          </div>
        ))}

        {/* Chourouk info */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-1.5">
            <Info className="w-4 h-4 text-slate-400" />
            <span>Chourouk (Lever du soleil - informatif)</span>
          </div>
          <span className="font-bold tabular-nums text-slate-800">{rawTimes.sunrise}</span>
        </div>
      </div>

      {/* Friday Jumuah Configuration */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-[#172B4D]">Prière du Vendredi (Jumuah)</h3>
          <span className="text-[10px] bg-teal-100 text-teal-800 px-2 py-0.5 rounded font-semibold">
            Bloc étendu
          </span>
        </div>
        <p className="text-slate-600 text-[11px]">
          Le vendredi, le bloc ordinaire de Dhuhr est automatiquement remplacé par le rassemblement à la mosquée.
        </p>

        <div className="space-y-2">
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Mosquée habituelle</label>
            <input
              type="text"
              value={jumuahMosque}
              onChange={(e) => setJumuahMosque(e.target.value)}
              placeholder="Ex : Mosquée As-Sounnah, Rabat"
              className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Préparation & bain</label>
              <input
                type="number"
                value={jumuahPrep}
                onChange={(e) => setJumuahPrep(parseInt(e.target.value, 10) || 30)}
                className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Khutbah + Prière</label>
              <span className="block px-3 py-2 bg-slate-100 rounded-xl text-slate-700 font-medium">
                45 minutes
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={handleSaveProtection}
          className="w-full py-2.5 rounded-xl bg-[#172B4D] text-white font-semibold text-xs transition-colors hover:bg-slate-800"
        >
          Enregistrer les paramètres
        </button>
      </div>
    </div>
  );
};
