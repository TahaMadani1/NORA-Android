import React, { useState, useEffect } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  CheckCircle, 
  Clock, 
  CheckSquare, 
  RotateCcw,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { Task, ScheduledSession } from '../../types';
import { db } from '../../services/storage/database';
import { soundService } from '../../services/audio/soundService';

interface FocusModeModalProps {
  session: ScheduledSession | null;
  task?: Task | null;
  onClose: () => void;
  onDataChanged: () => void;
}

export const FocusModeModal: React.FC<FocusModeModalProps> = ({
  session,
  task,
  onClose,
  onDataChanged
}) => {
  if (!session && !task) return null;

  const targetTitle = session?.title || task?.title || 'Session de travail';
  const initialMinutes = task?.remainingMinutes || 50;

  const [secondsRemaining, setSecondsRemaining] = useState(initialMinutes * 60);
  const [isRunning, setIsRunning] = useState(true);
  const [showCompletionPrompt, setShowCompletionPrompt] = useState(false);
  const [completionState, setCompletionState] = useState<'DONE' | 'PARTIAL' | 'NOT_STARTED'>('DONE');
  const [partialMinutesDone, setPartialMinutesDone] = useState(30);

  useEffect(() => {
    let timer: any = null;
    if (isRunning && secondsRemaining > 0) {
      timer = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            soundService.playFocusEndChime();
            setShowCompletionPrompt(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRunning, secondsRemaining]);

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleFinishEarly = () => {
    setIsRunning(false);
    soundService.playFocusEndChime();
    setShowCompletionPrompt(true);
  };

  const handleConfirmCompletion = () => {
    const elapsedMinutes = Math.round((initialMinutes * 60 - secondsRemaining) / 60);

    if (session) {
      session.status = 'CONFIRMED';
      session.confirmedMinutes = elapsedMinutes;
      db.saveSession(session);
    }

    const t = task || (session?.taskId ? db.getTaskById(session.taskId) : null);
    if (t) {
      if (completionState === 'DONE') {
        t.status = 'COMPLETED';
        t.remainingMinutes = 0;
        t.completedAt = new Date().toISOString();
        soundService.playTaskCompleted();
      } else if (completionState === 'PARTIAL') {
        t.status = 'PARTIALLY_COMPLETED';
        t.remainingMinutes = Math.max(0, t.remainingMinutes - partialMinutesDone);
        soundService.playSnooze();
      } else {
        // Not started
        t.postponementCount += 1;
      }
      db.saveTask(t);
    }

    onDataChanged();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col justify-between p-6 text-white animate-fadeIn">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse" />
          <span className="text-xs font-semibold text-teal-300 uppercase tracking-wider">
            Mode Focus NORA
          </span>
        </div>
        <button
          onClick={onClose}
          className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Focus Clock Body */}
      {!showCompletionPrompt ? (
        <div className="flex flex-col items-center justify-center text-center my-auto space-y-6">
          <div className="max-w-xs">
            <span className="text-xs text-slate-400 font-medium">Session en cours</span>
            <h2 className="text-lg font-bold text-white mt-1 leading-snug">
              {targetTitle}
            </h2>
          </div>

          {/* Big Digital Countdown */}
          <div className="w-56 h-56 rounded-full border-4 border-teal-500/30 flex flex-col items-center justify-center bg-teal-950/20 shadow-2xl">
            <div className="text-5xl font-mono font-bold tracking-tight text-white tabular-nums">
              {formatTimer(secondsRemaining)}
            </div>
            <span className="text-xs text-teal-300 mt-2 font-medium">
              {isRunning ? 'Concentration active' : 'En pause'}
            </span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className="px-6 py-3 rounded-2xl bg-white text-slate-900 font-bold text-sm flex items-center gap-2 shadow-lg hover:bg-slate-100 transition-all"
            >
              {isRunning ? <Pause className="w-4 h-4 fill-slate-900" /> : <Play className="w-4 h-4 fill-slate-900" />}
              <span>{isRunning ? 'Pause' : 'Reprendre'}</span>
            </button>

            <button
              onClick={handleFinishEarly}
              className="px-5 py-3 rounded-2xl bg-teal-600/40 hover:bg-teal-600/60 text-teal-200 font-semibold text-sm border border-teal-500/30 transition-all"
            >
              Terminer la session
            </button>
          </div>
        </div>
      ) : (
        /* End-of-Session Questionnaire (Section 25) */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 max-w-sm mx-auto my-auto w-full">
          <div>
            <span className="text-teal-400 text-xs font-semibold uppercase tracking-wider">
              Fin de session
            </span>
            <h3 className="text-base font-bold text-white mt-1">
              Quel est l'état réel de cette tâche ?
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              NORA ne présume jamais du travail effectué sans ta confirmation explicite.
            </p>
          </div>

          <div className="space-y-2 text-xs">
            <button
              onClick={() => setCompletionState('DONE')}
              className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                completionState === 'DONE'
                  ? 'border-emerald-500 bg-emerald-500/20 text-emerald-200 font-bold'
                  : 'border-slate-800 bg-slate-800/60 text-slate-300'
              }`}
            >
              <span>Terminée complètement</span>
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            </button>

            <button
              onClick={() => setCompletionState('PARTIAL')}
              className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                completionState === 'PARTIAL'
                  ? 'border-amber-500 bg-amber-500/20 text-amber-200 font-bold'
                  : 'border-slate-800 bg-slate-800/60 text-slate-300'
              }`}
            >
              <span>Partiellement réalisée</span>
              <Clock className="w-4 h-4 text-amber-400" />
            </button>

            {completionState === 'PARTIAL' && (
              <div className="p-3 bg-slate-800 rounded-xl space-y-2">
                <label className="block text-[11px] text-slate-300">
                  Minutes effectives accomplies :
                </label>
                <input
                  type="number"
                  step="5"
                  value={partialMinutesDone}
                  onChange={(e) => setPartialMinutesDone(parseInt(e.target.value, 10) || 15)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>
            )}

            <button
              onClick={() => setCompletionState('NOT_STARTED')}
              className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                completionState === 'NOT_STARTED'
                  ? 'border-rose-500 bg-rose-500/20 text-rose-200 font-bold'
                  : 'border-slate-800 bg-slate-800/60 text-slate-300'
              }`}
            >
              <span>Pas commencée / Interrompue</span>
              <RotateCcw className="w-4 h-4 text-rose-400" />
            </button>
          </div>

          <button
            onClick={handleConfirmCompletion}
            className="w-full py-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs transition-colors shadow-lg"
          >
            Valider et mettre à jour le planning
          </button>
        </div>
      )}

      {/* Footer tips */}
      <div className="text-center text-[11px] text-slate-500">
        Pas de notifications distrayantes · Priorité au travail profond
      </div>
    </div>
  );
};
