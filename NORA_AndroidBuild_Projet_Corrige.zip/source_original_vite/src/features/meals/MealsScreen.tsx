import React, { useState } from 'react';
import { 
  Utensils, 
  ArrowLeft, 
  Plus, 
  ShoppingCart, 
  Check, 
  Clock, 
  Flame, 
  Calendar,
  CheckSquare,
  Trash2
} from 'lucide-react';
import { db } from '../../services/storage/database';
import { Recipe, ShoppingItem } from '../../types';
import { toastService } from '../../services/feedback/toastService';

interface MealsScreenProps {
  onBack: () => void;
  onDataChanged: () => void;
}

export const MealsScreen: React.FC<MealsScreenProps> = ({
  onBack,
  onDataChanged
}) => {
  const [tab, setTab] = useState<'RECIPES' | 'SHOPPING'>('RECIPES');
  const recipes = db.getRecipes();
  const shoppingItems = db.getShoppingItems();

  const [newShopItem, setNewShopItem] = useState('');

  const handleToggleShoppingItem = (item: ShoppingItem) => {
    item.completed = !item.completed;
    db.saveShoppingItem(item);
    onDataChanged();
  };

  const handleAddShoppingItem = () => {
    if (!newShopItem.trim()) return;
    db.saveShoppingItem({
      id: 'shop-' + Date.now(),
      name: newShopItem.trim(),
      quantity: '1',
      category: 'Divers',
      completed: false
    });
    setNewShopItem('');
    onDataChanged();
  };

  const handleGenerateGroceryFromRecipe = (recipe: Recipe) => {
    const missing = recipe.ingredients.filter((i) => !i.isInPantry);
    if (missing.length === 0) {
      toastService.info('Tous les ingrédients de cette recette sont déjà présents dans vos réserves !');
      return;
    }
    missing.forEach((m) => {
      db.saveShoppingItem({
        id: 'shop-' + Date.now() + Math.random(),
        name: m.name,
        quantity: m.quantity,
        category: m.category,
        completed: false,
        addedFromRecipeId: recipe.id
      });
    });
    onDataChanged();
    toastService.success(`${missing.length} ingrédient(s) manquant(s) ont été ajoutés à la liste de courses !`);
    setTab('SHOPPING');
  };

  const handleDeleteShopItem = (id: string) => {
    db.deleteShoppingItem(id);
    onDataChanged();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Repas & Liste de courses</h1>
          <p className="text-[11px] text-slate-500">Cuisine équilibrée, prise de masse et approvisionnement</p>
        </div>
      </div>

      {/* Segmented Tab */}
      <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
        <button
          onClick={() => setTab('RECIPES')}
          className={`py-2 rounded-lg transition-colors ${
            tab === 'RECIPES' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
          }`}
        >
          Recettes & Portions ({recipes.length})
        </button>
        <button
          onClick={() => setTab('SHOPPING')}
          className={`py-2 rounded-lg transition-colors ${
            tab === 'SHOPPING' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
          }`}
        >
          Liste de courses ({shoppingItems.filter(i => !i.completed).length})
        </button>
      </div>

      {/* TAB: RECIPES */}
      {tab === 'RECIPES' && (
        <div className="space-y-3">
          {recipes.map((r) => (
            <div key={r.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-sm text-[#172B4D]">{r.name}</h3>
                  <div className="flex items-center gap-2 text-slate-500 text-[11px] mt-0.5">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      Prép: {r.prepMinutes}m · Cuisson: {r.activeCookMinutes + r.passiveCookMinutes}m
                    </span>
                    <span>· {r.servings} portions</span>
                  </div>
                </div>

                {r.isBulkingFriendly && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                    Prise de masse
                  </span>
                )}
              </div>

              {/* Nutrition summary */}
              {r.caloriesPerServing && (
                <div className="grid grid-cols-4 gap-2 p-2 bg-slate-50 rounded-xl text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Calories</span>
                    <span className="font-bold text-slate-800">{r.caloriesPerServing} kcal</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Protéines</span>
                    <span className="font-bold text-emerald-700">{r.proteinGrams}g</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Glucides</span>
                    <span className="font-bold text-blue-700">{r.carbsGrams}g</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Lipides</span>
                    <span className="font-bold text-amber-700">{r.fatsGrams}g</span>
                  </div>
                </div>
              )}

              {/* Ingredients and pantry status */}
              <div className="space-y-1">
                <span className="font-semibold text-slate-700 block text-[11px]">Ingrédients :</span>
                {r.ingredients.map((ing) => (
                  <div key={ing.id} className="flex items-center justify-between py-1 border-b border-slate-50">
                    <span className="text-slate-800">{ing.name} ({ing.quantity})</span>
                    <span className={`text-[10px] font-medium px-2 py-0.5 rounded ${
                      ing.isInPantry ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700 font-bold'
                    }`}>
                      {ing.isInPantry ? 'En réserve' : 'À acheter'}
                    </span>
                  </div>
                ))}
              </div>

              {/* Action */}
              <button
                onClick={() => handleGenerateGroceryFromRecipe(r)}
                className="w-full py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <ShoppingCart className="w-3.5 h-3.5" />
                <span>Générer les courses pour cette recette</span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* TAB: SHOPPING */}
      {tab === 'SHOPPING' && (
        <div className="space-y-3">
          <div className="flex gap-2">
            <input
              type="text"
              value={newShopItem}
              onChange={(e) => setNewShopItem(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddShoppingItem()}
              placeholder="Ajouter un article de course..."
              className="flex-1 border border-slate-300 rounded-xl px-3 py-2 text-xs"
            />
            <button
              onClick={handleAddShoppingItem}
              className="px-4 py-2 bg-[#172B4D] text-white rounded-xl font-medium text-xs"
            >
              Ajouter
            </button>
          </div>

          <div className="space-y-2">
            {shoppingItems.map((item) => (
              <div
                key={item.id}
                onClick={() => handleToggleShoppingItem(item)}
                className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  item.completed ? 'bg-slate-50 border-slate-200 opacity-60' : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CheckSquare className={`w-4 h-4 ${item.completed ? 'text-emerald-600 fill-emerald-100' : 'text-slate-400'}`} />
                  <div>
                    <span className={`text-xs font-semibold ${item.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                      {item.name}
                    </span>
                    <span className="text-[10px] text-slate-400 block">{item.quantity} · {item.category}</span>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteShopItem(item.id);
                  }}
                  className="p-1.5 text-slate-400 hover:text-rose-500"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
