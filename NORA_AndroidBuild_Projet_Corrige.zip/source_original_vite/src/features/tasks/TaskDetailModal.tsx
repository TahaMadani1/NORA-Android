import React, { useState } from 'react';
import { 
  X, 
  Clock, 
  Calendar, 
  MapPin, 
  CheckSquare, 
  Plus, 
  FileText, 
  Trash2, 
  Play, 
  CheckCircle, 
  RotateCcw,
  Zap,
  Briefcase,
  AlertCircle
} from 'lucide-react';
import { Task, SubTask } from '../../types';
import { CATEGORY_THEMES, PRIORITY_THEMES, STATUS_LABELS } from '../../theme/colors';
import { db } from '../../services/storage/database';
import { toastService } from '../../services/feedback/toastService';

interface TaskDetailModalProps {
  taskId: string | null;
  onClose: () => void;
  onDataChanged: () => void;
  onStartFocus?: (task: Task) => void;
}

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({
  taskId,
  onClose,
  onDataChanged,
  onStartFocus
}) => {
  if (!taskId) return null;
  const task = db.getTaskById(taskId);
  if (!task) return null;

  const [activeTab, setActiveTab] = useState<'INFO' | 'PLAN' | 'SUBTASKS' | 'MATS' | 'DOCS' | 'NOTES'>('INFO');
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [newMaterialName, setNewMaterialName] = useState('');
  const [editableNotes, setEditableNotes] = useState(task.notes || '');

  const cat = CATEGORY_THEMES[task.category] || CATEGORY_THEMES.STUDIES;
  const prio = PRIORITY_THEMES[task.priority] || PRIORITY_THEMES.P3;

  const handleToggleSubtask = (subId: string) => {
    task.subtasks = task.subtasks.map((s) => (s.id === subId ? { ...s, completed: !s.completed } : s));
    db.saveTask(task);
    onDataChanged();
  };

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim()) return;
    task.subtasks.push({
      id: 'sub-' + Date.now(),
      title: newSubtaskTitle.trim(),
      completed: false
    });
    setNewSubtaskTitle('');
    db.saveTask(task);
    onDataChanged();
  };

  const handleAddMaterial = () => {
    if (!newMaterialName.trim()) return;
    const mats = task.materialsNeeded || [];
    mats.push(newMaterialName.trim());
    task.materialsNeeded = mats;
    setNewMaterialName('');
    db.saveTask(task);
    onDataChanged();
  };

  const handleSaveNotes = () => {
    task.notes = editableNotes;
    db.saveTask(task);
    onDataChanged();
    toastService.success('Notes enregistrées avec succès !');
  };

  const handleCompleteTask = () => {
    task.status = 'COMPLETED';
    task.remainingMinutes = 0;
    task.completedAt = new Date().toISOString();
    db.saveTask(task);
    onDataChanged();
    toastService.success(`Tâche "${task.title}" terminée !`);
    onClose();
  };

  const handlePostponeTask = () => {
    task.postponementCount += 1;
    task.status = 'POSTPONED';
    db.saveTask(task);
    onDataChanged();
    toastService.info('Tâche reportée avec succès.');
  };

  const handleDeleteTask = () => {
    db.deleteTask(task.id);
    onDataChanged();
    toastService.warning(`Tâche "${task.title}" supprimée.`);
    onClose();
  };

  const associatedSessions = db.getSessions().filter((s) => s.taskId === task.id);

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end">
      <div className="w-full max-h-[90vh] bg-white rounded-t-3xl flex flex-col overflow-hidden animate-slideUp shadow-2xl">
        {/* Grab Handle */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-2.5 shrink-0" />

        {/* Header */}
        <div className="px-5 pb-3 border-b border-slate-100 flex items-start justify-between">
          <div className="flex-1 pr-3">
            <div className="flex items-center gap-1.5 mb-1">
              <span
                className="text-[10px] font-bold px-1.5 py-0.2 rounded"
                style={{ backgroundColor: prio.badgeBg, color: prio.text }}
              >
                {prio.label}
              </span>
              <span
                className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                style={{ backgroundColor: cat.bgLight, color: cat.color }}
              >
                {cat.label}
              </span>
            </div>
            <h2 className="text-base font-bold text-[#172B4D] leading-snug">{task.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-5 py-2 bg-slate-50 border-b border-slate-100 overflow-x-auto scrollbar-none text-xs">
          {[
            { id: 'INFO', label: 'Informations' },
            { id: 'PLAN', label: 'Sessions & Plan' },
            { id: 'SUBTASKS', label: `Sous-tâches (${task.subtasks.length})` },
            { id: 'MATS', label: 'Matériel' },
            { id: 'DOCS', label: 'Documents' },
            { id: 'NOTES', label: 'Notes' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg font-semibold shrink-0 transition-colors ${
                activeTab === tab.id
                  ? 'bg-[#172B4D] text-white'
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Body Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {activeTab === 'INFO' && (
            <div className="space-y-4">
              {task.description && (
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="font-semibold text-slate-700 block mb-1">Description</span>
                  <p className="text-slate-600 leading-relaxed">{task.description}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 block mb-0.5">Effort restant</span>
                  <span className="text-sm font-bold text-[#172B4D]">
                    {task.remainingMinutes} min
                  </span>
                  <span className="text-[10px] text-slate-400 block">
                    (sur {task.totalEstimatedMinutes} min au total)
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-500 block mb-0.5">Énergie requise</span>
                  <span className="text-sm font-bold text-amber-600 flex items-center gap-1">
                    <Zap className="w-4 h-4 fill-amber-500 text-amber-500" />
                    {task.energyLevel} / 5
                  </span>
                  <span className="text-[10px] text-slate-400 block">Intensité mentale</span>
                </div>
              </div>

              {task.deadline && (
                <div className="flex items-center gap-2 p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-blue-900">
                  <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                  <div>
                    <span className="font-bold block">Échéance : {task.deadline.replace('T', ' à ')}</span>
                    <span className="text-[11px] text-blue-700">Priorité de planification automatique</span>
                  </div>
                </div>
              )}

              {task.location && (
                <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-xl text-slate-700">
                  <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                  <span>Lieu : {task.location}</span>
                </div>
              )}

              {task.postponementCount > 0 && (
                <div className="p-3 bg-orange-50 border border-orange-200 rounded-xl text-orange-900 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">
                      Tâche reportée {task.postponementCount} fois
                    </span>
                    <p className="text-[11px] text-orange-800 mt-0.5">
                      Conseil anti-procrastination NORA : Réduis l'objectif de la prochaine séance à 30 minutes ou commence par la première sous-tâche.
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'PLAN' && (
            <div className="space-y-3">
              <span className="font-bold text-slate-800 block">
                Sessions de travail associées ({associatedSessions.length})
              </span>
              <p className="text-[11px] text-slate-500">
                La tâche maîtresse conserve l'effort total. Chaque session représente un bloc effectif d'exécution.
              </p>

              {associatedSessions.length === 0 ? (
                <div className="p-4 bg-slate-50 rounded-xl text-center text-slate-500">
                  Aucune session planifiée actuellement pour cette tâche.
                </div>
              ) : (
                associatedSessions.map((s) => (
                  <div key={s.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-[#172B4D] block">{s.date} · {s.startTime} - {s.endTime}</span>
                      <span className="text-[10px] text-slate-500">Statut : {s.status}</span>
                    </div>
                    {s.confirmedMinutes && (
                      <span className="text-xs font-bold text-emerald-700">✓ {s.confirmedMinutes}m validées</span>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'SUBTASKS' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newSubtaskTitle}
                  onChange={(e) => setNewSubtaskTitle(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddSubtask()}
                  placeholder="Ajouter une sous-tâche concrète..."
                  className="flex-1 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
                <button
                  onClick={handleAddSubtask}
                  className="px-3 py-2 rounded-xl bg-[#172B4D] text-white font-medium"
                >
                  Ajouter
                </button>
              </div>

              <div className="space-y-2">
                {task.subtasks.map((st) => (
                  <div
                    key={st.id}
                    onClick={() => handleToggleSubtask(st.id)}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 flex items-center gap-3 cursor-pointer hover:bg-slate-100"
                  >
                    <CheckSquare
                      className={`w-4 h-4 ${st.completed ? 'text-emerald-600 fill-emerald-100' : 'text-slate-400'}`}
                    />
                    <span className={`text-xs ${st.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                      {st.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'MATS' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMaterialName}
                  onChange={(e) => setNewMaterialName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddMaterial()}
                  placeholder="Ex : Cahier TD, PC portable, calculatrice..."
                  className="flex-1 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
                <button
                  onClick={handleAddMaterial}
                  className="px-3 py-2 rounded-xl bg-[#172B4D] text-white font-medium"
                >
                  Ajouter
                </button>
              </div>

              <div className="space-y-1.5">
                {(task.materialsNeeded || []).map((m, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2">
                    <span className="text-teal-600 font-bold">✓</span>
                    <span className="text-slate-800">{m}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'DOCS' && (
            <div className="space-y-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-600">
                <span className="font-semibold block mb-1">Pièces jointes & Supports de cours</span>
                <p className="text-[11px]">
                  Supports PDF locaux, énoncés de TP et références d'archivage local.
                </p>
              </div>
              <div className="p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <div>
                    <span className="font-bold text-slate-800 block">Syllabus & TD Algorithmique 2026.pdf</span>
                    <span className="text-[10px] text-slate-400">Stockage local sécurisé</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'NOTES' && (
            <div className="space-y-3">
              <textarea
                value={editableNotes}
                onChange={(e) => setEditableNotes(e.target.value)}
                placeholder="Remarques et instructions importantes..."
                rows={4}
                className="w-full border border-slate-300 rounded-xl p-3 text-xs focus:ring-2 focus:ring-[#172B4D] focus:outline-none"
              />
              <button
                onClick={handleSaveNotes}
                className="px-4 py-2 rounded-xl bg-[#172B4D] text-white text-xs font-semibold"
              >
                Enregistrer la note
              </button>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center justify-between gap-2">
          {task.status !== 'COMPLETED' ? (
            <>
              {onStartFocus && (
                <button
                  onClick={() => {
                    onStartFocus(task);
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition-colors"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>Focus</span>
                </button>
              )}

              <button
                onClick={handleCompleteTask}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors"
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Terminer</span>
              </button>

              <button
                onClick={handlePostponeTask}
                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reporter</span>
              </button>
            </>
          ) : (
            <span className="text-emerald-700 font-bold text-xs">✓ Tâche terminée</span>
          )}

          <button
            onClick={handleDeleteTask}
            className="p-2.5 rounded-xl text-rose-600 hover:bg-rose-50 transition-colors ml-auto"
            title="Supprimer la tâche"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
