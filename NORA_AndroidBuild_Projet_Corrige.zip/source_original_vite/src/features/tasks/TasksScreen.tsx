import React, { useState } from 'react';
import { 
  CheckCircle, 
  Circle, 
  Clock, 
  Flag, 
  AlertCircle, 
  Filter, 
  Plus, 
  Layers, 
  Zap,
  CheckSquare,
  Search
} from 'lucide-react';
import { Task, PriorityLevel, TaskCategory, TaskStatus } from '../../types';
import { CATEGORY_THEMES, PRIORITY_THEMES, STATUS_LABELS } from '../../theme/colors';
import { db } from '../../services/storage/database';
import { soundService } from '../../services/audio/soundService';

interface TasksScreenProps {
  onOpenTaskDetail: (taskId: string) => void;
  onOpenQuickCreate: () => void;
  onDataChanged: () => void;
}

export const TasksScreen: React.FC<TasksScreenProps> = ({
  onOpenTaskDetail,
  onOpenQuickCreate,
  onDataChanged
}) => {
  const [filterPriority, setFilterPriority] = useState<PriorityLevel | 'ALL'>('ALL');
  const [filterStatus, setFilterStatus] = useState<'ACTIVE' | 'COMPLETED' | 'ALL'>('ACTIVE');
  const [filterCategory, setFilterCategory] = useState<TaskCategory | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const tasks = db.getTasks();

  const handleToggleTask = (task: Task, e: React.MouseEvent) => {
    e.stopPropagation();
    if (task.status === 'COMPLETED') {
      task.status = 'UNCOMPLETED';
      task.remainingMinutes = task.totalEstimatedMinutes;
      task.completedAt = undefined;
      soundService.playSnooze();
    } else {
      task.status = 'COMPLETED';
      task.remainingMinutes = 0;
      task.completedAt = new Date().toISOString();
      soundService.playTaskCompleted();
    }
    db.saveTask(task);
    onDataChanged();
  };

  const filteredTasks = tasks.filter((t) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = t.title.toLowerCase().includes(q);
      const matchDesc = t.description && t.description.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc) return false;
    }
    if (filterPriority !== 'ALL' && t.priority !== filterPriority) return false;
    if (filterCategory !== 'ALL' && t.category !== filterCategory) return false;
    if (filterStatus === 'ACTIVE' && t.status === 'COMPLETED') return false;
    if (filterStatus === 'COMPLETED' && t.status !== 'COMPLETED') return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Header & Quick stats */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-bold text-[#172B4D]">Gestionnaire de Tâches</h1>
            <p className="text-xs text-slate-500">
              {tasks.filter((t) => t.status !== 'COMPLETED').length} tâches actives · Priorisation stricte
            </p>
          </div>
          <button
            onClick={onOpenQuickCreate}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#172B4D] hover:bg-slate-800 text-white text-xs font-semibold shadow-sm transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Créer</span>
          </button>
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une tâche, un cours, un mot-clé..."
            className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#172B4D]"
          />
        </div>

        {/* Priority Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs scrollbar-none pt-1">
          <button
            onClick={() => setFilterPriority('ALL')}
            className={`px-2.5 py-1 rounded-lg font-semibold transition-colors shrink-0 ${
              filterPriority === 'ALL'
                ? 'bg-slate-800 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Toutes priorités
          </button>
          {(['P1', 'P2', 'P3', 'P4'] as PriorityLevel[]).map((p) => {
            const prioInfo = PRIORITY_THEMES[p];
            const isSel = filterPriority === p;
            return (
              <button
                key={p}
                onClick={() => setFilterPriority(p)}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors shrink-0 ${
                  isSel ? 'ring-2 ring-slate-800' : ''
                }`}
                style={{ backgroundColor: prioInfo.badgeBg, color: prioInfo.text }}
              >
                {prioInfo.label}
              </button>
            );
          })}
        </div>

        {/* Status segmented tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-xl text-xs">
          <button
            onClick={() => setFilterStatus('ACTIVE')}
            className={`py-1 rounded-lg font-semibold transition-colors ${
              filterStatus === 'ACTIVE' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            En cours
          </button>
          <button
            onClick={() => setFilterStatus('COMPLETED')}
            className={`py-1 rounded-lg font-semibold transition-colors ${
              filterStatus === 'COMPLETED' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            Terminées
          </button>
          <button
            onClick={() => setFilterStatus('ALL')}
            className={`py-1 rounded-lg font-semibold transition-colors ${
              filterStatus === 'ALL' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            Toutes
          </button>
        </div>
      </div>

      {/* Task List */}
      <div className="space-y-2.5">
        {filteredTasks.length === 0 ? (
          <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500">
            Aucune tâche trouvée avec ces filtres.
          </div>
        ) : (
          filteredTasks.map((task) => {
            const cat = CATEGORY_THEMES[task.category] || CATEGORY_THEMES.STUDIES;
            const prio = PRIORITY_THEMES[task.priority] || PRIORITY_THEMES.P3;
            const isDone = task.status === 'COMPLETED';
            const completedSubtasks = task.subtasks.filter((s) => s.completed).length;

            return (
              <div
                key={task.id}
                onClick={() => onOpenTaskDetail(task.id)}
                className={`bg-white rounded-2xl p-3.5 border transition-all cursor-pointer shadow-sm hover:shadow-md ${
                  isDone ? 'border-slate-200 opacity-65 bg-slate-50/50' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Real Checkbox */}
                  <button
                    onClick={(e) => handleToggleTask(task, e)}
                    className="min-h-[44px] min-w-[44px] -ml-2 -mt-2 flex items-center justify-center shrink-0"
                    title={isDone ? 'Marquer non terminée' : 'Marquer terminée'}
                    aria-label="Cocher tâche"
                  >
                    {isDone ? (
                      <CheckCircle className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-400 hover:text-[#172B4D]" />
                    )}
                  </button>

                  <div className="flex-1 min-w-0">
                    {/* Category & Priority chips */}
                    <div className="flex items-center gap-1.5 mb-1">
                      <span
                        className="text-[9px] font-bold px-1.5 py-0.2 rounded"
                        style={{ backgroundColor: prio.badgeBg, color: prio.text }}
                      >
                        {prio.label.split(' ')[0]}
                      </span>
                      <span
                        className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                        style={{ backgroundColor: cat.bgLight, color: cat.color }}
                      >
                        {cat.label}
                      </span>
                      {task.energyLevel && (
                        <span className="text-[10px] text-amber-600 font-medium flex items-center ml-auto">
                          <Zap className="w-2.5 h-2.5" /> Énergie {task.energyLevel}/5
                        </span>
                      )}
                    </div>

                    {/* Title */}
                    <h3
                      className={`text-sm font-bold leading-snug ${
                        isDone ? 'line-through text-slate-500' : 'text-[#0F172A]'
                      }`}
                    >
                      {task.title}
                    </h3>

                    {task.description && (
                      <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                        {task.description}
                      </p>
                    )}

                    {/* Effort & Subtasks info */}
                    <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span className="tabular-nums">
                          {task.remainingMinutes}m restantes / {task.totalEstimatedMinutes}m
                        </span>
                      </div>

                      {task.subtasks.length > 0 && (
                        <div className="flex items-center gap-1 text-slate-600">
                          <CheckSquare className="w-3 h-3 text-slate-400" />
                          <span>
                            {completedSubtasks}/{task.subtasks.length}
                          </span>
                        </div>
                      )}

                      {task.postponementCount > 0 && (
                        <span className="text-orange-600 font-medium">
                          {task.postponementCount} report(s)
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
