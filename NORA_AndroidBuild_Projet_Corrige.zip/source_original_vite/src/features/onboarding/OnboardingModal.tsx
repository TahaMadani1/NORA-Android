import React, { useState } from 'react';
import { 
  Sparkles, 
  Moon, 
  Sun, 
  ShieldCheck, 
  Clock, 
  MapPin, 
  ArrowRight, 
  Check, 
  X,
  Sliders
} from 'lucide-react';
import { AppSettings } from '../../types';
import { db } from '../../services/storage/database';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataChanged: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  onDataChanged
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const settings = db.getSettings();

  const [wakeTime, setWakeTime] = useState(settings.sleepPreference.targetWakeTime);
  const [bedtime, setBedtime] = useState(settings.sleepPreference.targetBedtime);
  const [maxWorkload, setMaxWorkload] = useState(settings.discretionaryWorkloadLimitHours);
  const [focusBlock, setFocusBlock] = useState(settings.focusBlockMinutes);

  const handleFinish = (loadDemoData: boolean = false) => {
    settings.sleepPreference.targetWakeTime = wakeTime;
    settings.sleepPreference.targetBedtime = bedtime;
    settings.discretionaryWorkloadLimitHours = maxWorkload;
    settings.focusBlockMinutes = focusBlock;
    db.updateSettings(settings);

    if (loadDemoData) {
      db.resetToDefault();
    }

    localStorage.setItem('NORA_ONBOARDED', 'true');
    onDataChanged();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex flex-col justify-end p-2 sm:p-4">
      <div className="w-full max-w-md mx-auto bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col animate-slideUp">
        {/* Grab bar */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-3 shrink-0" />

        {/* Header */}
        <div className="px-6 pb-3 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-[#172B4D] text-white flex items-center justify-center font-bold text-xs">
              N
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#172B4D]">Bienvenue sur NORA</h2>
              <span className="text-[10px] text-teal-700 font-semibold">Étape {step} sur 3</span>
            </div>
          </div>
          <button
            onClick={() => handleFinish(false)}
            className="text-xs text-slate-400 hover:text-slate-700 font-medium"
          >
            Passer
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-xs">
          {step === 1 && (
            <div className="space-y-4">
              <div className="bg-teal-50 border border-teal-200 rounded-2xl p-3.5 text-teal-900 space-y-1">
                <span className="font-bold text-xs block">Rabat / Salé · Ministère des Habous</span>
                <p className="text-[11px] text-teal-800 leading-relaxed">
                  NORA est pré-calibrée pour Rabat (fuseau Africa/Casablanca, format 24h). Les 5 prières quotidiennes et le rassemblement de Jumuah le vendredi sont protégés au Niveau 0.
                </p>
              </div>

              <div>
                <span className="font-semibold text-slate-800 block mb-2">Horaires de sommeil :</span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-500 block mb-1">Heure de réveil</label>
                    <input
                      type="time"
                      value={wakeTime}
                      onChange={(e) => setWakeTime(e.target.value)}
                      className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 block mb-1">Heure de coucher</label>
                    <input
                      type="time"
                      value={bedtime}
                      onChange={(e) => setBedtime(e.target.value)}
                      className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <span className="font-bold text-slate-900 text-xs block mb-1">
                  Charge de travail discrétionnaire max : {maxWorkload}h par jour
                </span>
                <p className="text-slate-500 text-[11px] mb-2">
                  La philosophie de NORA n'est pas de saturer chaque minute, mais d'éviter le surmenage.
                </p>
                <input
                  type="range"
                  min="2"
                  max="7"
                  value={maxWorkload}
                  onChange={(e) => setMaxWorkload(parseInt(e.target.value, 10))}
                  className="w-full accent-[#172B4D]"
                />
              </div>

              <div>
                <span className="font-bold text-slate-900 text-xs block mb-1">
                  Durée de session Focus : {focusBlock} minutes
                </span>
                <p className="text-slate-500 text-[11px] mb-2">
                  Bloc de concentration optimale avant une pause méritée.
                </p>
                <input
                  type="number"
                  step="5"
                  value={focusBlock}
                  onChange={(e) => setFocusBlock(parseInt(e.target.value, 10) || 50)}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 border border-teal-200 text-teal-700 flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-[#172B4D]">Configuration terminée !</h3>
                <p className="text-slate-500 text-[11px] mt-1 max-w-xs mx-auto">
                  Tu peux commencer avec une feuille blanche ou charger des données d'exemple réalistes pour Rabat (cours, projet, prières et sport).
                </p>
              </div>

              <div className="pt-2 space-y-2">
                <button
                  onClick={() => handleFinish(true)}
                  className="w-full py-3 rounded-xl bg-[#172B4D] hover:bg-slate-800 text-white font-semibold text-xs shadow-md transition-colors"
                >
                  Charger les données de démonstration
                </button>
                <button
                  onClick={() => handleFinish(false)}
                  className="w-full py-2.5 rounded-xl border border-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-50"
                >
                  Commencer avec une base vide
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer controls for steps 1 and 2 */}
        {step < 3 && (
          <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50">
            {step > 1 ? (
              <button
                onClick={() => setStep((step - 1) as any)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
              >
                Précédent
              </button>
            ) : (
              <div />
            )}

            <button
              onClick={() => setStep((step + 1) as any)}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#172B4D] text-white font-semibold text-xs shadow-sm hover:bg-slate-800 transition-colors"
            >
              <span>Continuer</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
