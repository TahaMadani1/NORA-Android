import React, { useState } from 'react';
import { 
  Dumbbell, 
  ArrowLeft, 
  Clock, 
  Plus, 
  CheckCircle, 
  MapPin, 
  Activity,
  Calendar
} from 'lucide-react';
import { db } from '../../services/storage/database';
import { Workout } from '../../types';
import { toastService } from '../../services/feedback/toastService';
import { getTodayMoroccoDateString } from '../../services/prayerTimes/rabatPrayerService';

interface WorkoutsScreenProps {
  onBack: () => void;
  onDataChanged: () => void;
}

export const WorkoutsScreen: React.FC<WorkoutsScreenProps> = ({
  onBack,
  onDataChanged
}) => {
  const workouts = db.getWorkouts();
  const [selectedWorkout, setSelectedWorkout] = useState<Workout | null>(workouts[0] || null);

  const handleScheduleWorkout = (w: Workout) => {
    const totalMinutes = w.prepMinutes + w.durationMinutes + w.travelMinutes + w.showerMinutes;
    const todayStr = getTodayMoroccoDateString();
    // Schedule for today 17:15
    db.saveSession({
      id: 'sess-' + Date.now(),
      title: `Séance : ${w.title}`,
      category: 'PERSONAL',
      priority: 'P3',
      constraintLevel: 'LEVEL_2',
      date: todayStr,
      startTime: '17:15',
      endTime: '18:50',
      status: 'SCHEDULED',
      isLocked: false,
      location: 'Salle de sport Agdal / Rabat'
    });
    onDataChanged();
    toastService.success(`Séance "${w.title}" planifiée dans l'Agenda avec ${totalMinutes} min protégées !`);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Sport & Entraînement</h1>
          <p className="text-[11px] text-slate-500">Planification des séances, trajet et temps de récupération</p>
        </div>
      </div>

      <div className="space-y-3">
        {workouts.map((w) => {
          const totalBuffer = w.prepMinutes + w.durationMinutes + w.travelMinutes + w.showerMinutes;

          return (
            <div key={w.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-sm text-[#172B4D]">{w.title}</h3>
                  <span className="text-[11px] text-slate-500">
                    Type : {w.type} · Effort pur : {w.durationMinutes} min
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-800 text-[10px] font-bold">
                  {totalBuffer}m réservées
                </span>
              </div>

              {/* Real buffers visualization */}
              <div className="grid grid-cols-4 gap-1 p-2 bg-slate-50 rounded-xl text-center text-[10px]">
                <div>
                  <span className="text-slate-400 block">Préparation</span>
                  <span className="font-bold text-slate-700">{w.prepMinutes}m</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Trajet A/R</span>
                  <span className="font-bold text-slate-700">{w.travelMinutes}m</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Séance</span>
                  <span className="font-bold text-blue-700">{w.durationMinutes}m</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Douche</span>
                  <span className="font-bold text-slate-700">{w.showerMinutes}m</span>
                </div>
              </div>

              {/* Exercises list */}
              <div className="space-y-1.5 pt-1">
                <span className="font-semibold text-slate-700 block text-[11px]">Exercices :</span>
                {w.exercises.map((ex) => (
                  <div key={ex.id} className="p-2 rounded-lg bg-slate-50/70 border border-slate-100 flex items-center justify-between">
                    <span className="font-medium text-slate-800">{ex.name}</span>
                    <span className="text-slate-500 font-mono text-[11px]">
                      {ex.sets} séries × {ex.reps} {ex.weight ? `(${ex.weight})` : ''}
                    </span>
                  </div>
                ))}
              </div>

              {w.notes && (
                <p className="text-[11px] text-slate-500 italic">"{w.notes}"</p>
              )}

              {/* Action */}
              <button
                onClick={() => handleScheduleWorkout(w)}
                className="w-full py-2.5 rounded-xl bg-[#172B4D] hover:bg-slate-800 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Bloquer cette séance dans l'agenda aujourd'hui</span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
