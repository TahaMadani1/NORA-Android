import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Briefcase, 
  FileText, 
  Users, 
  BellRing, 
  Utensils, 
  Dumbbell, 
  Moon, 
  BarChart3,
  ChevronRight,
  Plus,
  CheckCircle,
  Copy,
  Check
} from 'lucide-react';
import { db } from '../../services/storage/database';
import { AppSettings, Project, Meeting, FollowUp, NoteItem } from '../../types';
import { calculateDaySchedule } from '../../services/scheduling/schedulingEngine';
import { soundService } from '../../services/audio/soundService';
import { toastService } from '../../services/feedback/toastService';

interface BureauScreenProps {
  settings: AppSettings;
  onOpenLifestyle: () => void;
  onOpenMeals: () => void;
  onOpenWorkouts: () => void;
  onOpenReports: () => void;
  onDataChanged: () => void;
}

type BureauSubView = 'ASSISTANT' | 'PROJECTS' | 'NOTES' | 'MEETINGS' | 'FOLLOWUPS';

export const BureauScreen: React.FC<BureauScreenProps> = ({
  settings,
  onOpenLifestyle,
  onOpenMeals,
  onOpenWorkouts,
  onOpenReports,
  onDataChanged
}) => {
  const [subView, setSubView] = useState<BureauSubView>('ASSISTANT');
  const [userQuery, setUserQuery] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'nora'; text: string }>>([
    {
      sender: 'nora',
      text: 'Bonjour ! Je suis NORA, ta secrétaire personnelle locale. Comment puis-je t\'assister aujourd\'hui ? Tu peux me demander ton programme, tes urgences, ou chercher un créneau libre.'
    }
  ]);

  const projects = db.getProjects();
  const meetings = db.getMeetings();
  const followUps = db.getFollowUps();
  const notes = db.getNotes();

  const handleAssistantCommand = (queryText?: string) => {
    const q = (queryText || userQuery).trim();
    if (!q) return;

    const newMsgs = [...chatMessages, { sender: 'user' as const, text: q }];
    const lower = q.toLowerCase();
    let reply = '';

    if (lower.includes('faire aujourd\'hui') || lower.includes('programme') || lower.includes('journée')) {
      const daySummary = calculateDaySchedule('2026-10-13', settings);
      reply = `Aujourd'hui, tu as ${daySummary.sessions.length} sessions prévues pour un total de ${Math.round(daySummary.totalPlannedMinutes / 60)}h. Tes 5 prières quotidiennes sont protégées, et tu disposes d'environ ${Math.round(daySummary.remainingAvailableMinutes)} min de respiration.`;
    } else if (lower.includes('urgent') || lower.includes('p1') || lower.includes('prioritaire')) {
      const urgentTasks = db.getTasks().filter(t => (t.priority === 'P1' || t.priority === 'P2') && t.status !== 'COMPLETED');
      if (urgentTasks.length > 0) {
        reply = `Voici tes priorités absolues :\n` + urgentTasks.map(t => `• [${t.priority}] ${t.title} (${t.remainingMinutes}m)`).join('\n');
      } else {
        reply = 'Aucune tâche critique P1 ou P2 en attente ! Ton emploi du temps est bien sécurisé.';
      }
    } else if (lower.includes('créneau') || lower.includes('libre')) {
      reply = 'En analysant ton agenda entre les cours et les prières de Rabat, un créneau libre de 1h30 est disponible cet après-midi entre 15h00 et 16h30.';
    } else if (lower.includes('non terminé') || lower.includes('en retard') || lower.includes('report')) {
      const postponed = db.getTasks().filter(t => t.postponementCount > 0 && t.status !== 'COMPLETED');
      if (postponed.length > 0) {
        reply = `Tu as ${postponed.length} tâche(s) reportée(s) : "${postponed[0].title}". Veux-tu que je la planifie demain matin ?`;
      } else {
        reply = 'Toutes tes tâches planifiées sont à jour !';
      }
    } else {
      reply = `Bien noté. J'analyse tes données locales à Rabat pour "${q}". Tu peux consulter l'onglet Agenda pour voir les créneaux synchronisés.`;
    }

    newMsgs.push({ sender: 'nora' as const, text: reply });
    soundService.playFocusEndChime();
    setChatMessages(newMsgs);
    setUserQuery('');
  };

  const handleConvertMeetingDecision = (m: Meeting, decisionText: string) => {
    db.saveTask({
      id: 'task-' + Date.now(),
      title: decisionText,
      description: `Action issue de la réunion : ${m.title}`,
      category: 'WORK',
      priority: 'P2',
      constraintLevel: 'LEVEL_3',
      status: 'UNCOMPLETED',
      totalEstimatedMinutes: 60,
      remainingMinutes: 60,
      energyLevel: 3,
      isFixed: false,
      schedulingPreference: 'BEFORE_DEADLINE',
      postponementCount: 0,
      subtasks: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
    soundService.playTaskCompleted();
    toastService.success('Décision transformée avec succès en tâche maîtresse !');
    onDataChanged();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Secretary Office Hub Header */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Bureau & Secrétariat</h1>
          <p className="text-xs text-slate-500">
            Centre de coordination personnel · Tout reste en local sur ton appareil
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-5 gap-1 p-1 bg-slate-100 rounded-xl text-[11px] font-semibold text-center">
          <button
            onClick={() => setSubView('ASSISTANT')}
            className={`py-1.5 rounded-lg transition-colors ${
              subView === 'ASSISTANT' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            NORA
          </button>
          <button
            onClick={() => setSubView('PROJECTS')}
            className={`py-1.5 rounded-lg transition-colors ${
              subView === 'PROJECTS' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            Projets
          </button>
          <button
            onClick={() => setSubView('MEETINGS')}
            className={`py-1.5 rounded-lg transition-colors ${
              subView === 'MEETINGS' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            Réunions
          </button>
          <button
            onClick={() => setSubView('FOLLOWUPS')}
            className={`py-1.5 rounded-lg transition-colors ${
              subView === 'FOLLOWUPS' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            Relances
          </button>
          <button
            onClick={() => setSubView('NOTES')}
            className={`py-1.5 rounded-lg transition-colors ${
              subView === 'NOTES' ? 'bg-white text-[#172B4D] shadow-sm' : 'text-slate-500'
            }`}
          >
            Notes
          </button>
        </div>
      </div>

      {/* Shortcuts to Life & Lifestyle Modules */}
      <div className="grid grid-cols-4 gap-2 text-center text-xs">
        <button
          onClick={onOpenMeals}
          className="p-2.5 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 shadow-sm flex flex-col items-center justify-center gap-1 transition-all"
        >
          <Utensils className="w-4 h-4 text-emerald-600" />
          <span className="font-semibold text-slate-800 text-[10px]">Repas</span>
        </button>

        <button
          onClick={onOpenWorkouts}
          className="p-2.5 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 shadow-sm flex flex-col items-center justify-center gap-1 transition-all"
        >
          <Dumbbell className="w-4 h-4 text-blue-600" />
          <span className="font-semibold text-slate-800 text-[10px]">Sport</span>
        </button>

        <button
          onClick={onOpenLifestyle}
          className="p-2.5 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 shadow-sm flex flex-col items-center justify-center gap-1 transition-all"
        >
          <Moon className="w-4 h-4 text-purple-600" />
          <span className="font-semibold text-slate-800 text-[10px]">Sommeil</span>
        </button>

        <button
          onClick={onOpenReports}
          className="p-2.5 rounded-2xl bg-white border border-slate-200 hover:border-slate-300 shadow-sm flex flex-col items-center justify-center gap-1 transition-all"
        >
          <BarChart3 className="w-4 h-4 text-teal-600" />
          <span className="font-semibold text-slate-800 text-[10px]">Bilans</span>
        </button>
      </div>

      {/* SUBVIEW: ASSISTANT NORA */}
      {subView === 'ASSISTANT' && (
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs">
              N
            </div>
            <div>
              <span className="font-bold text-xs text-[#172B4D]">Commandes assistante</span>
              <span className="text-[10px] text-teal-700 block">Exécution déterministe hors-ligne</span>
            </div>
          </div>

          {/* Quick command buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] pb-1 scrollbar-none">
            {[
              'Que dois-je faire aujourd\'hui ?',
              'Quelles tâches sont urgentes ?',
              'Trouve un créneau de 2 heures',
              'Quels sont mes engagements non terminés ?'
            ].map((cmd, i) => (
              <button
                key={i}
                onClick={() => handleAssistantCommand(cmd)}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg shrink-0 font-medium"
              >
                {cmd}
              </button>
            ))}
          </div>

          {/* Chat feed */}
          <div className="space-y-2.5 max-h-60 overflow-y-auto p-1">
            {chatMessages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`p-3 rounded-2xl max-w-[85%] text-xs leading-relaxed whitespace-pre-line ${
                    msg.sender === 'user'
                      ? 'bg-[#172B4D] text-white rounded-br-sm'
                      : 'bg-slate-100 text-slate-800 rounded-bl-sm border border-slate-200/60'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          {/* Input Box */}
          <div className="pt-2 flex items-center gap-2">
            <input
              type="text"
              value={userQuery}
              onChange={(e) => setUserQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAssistantCommand()}
              placeholder="Pose une question ou donne un ordre..."
              className="flex-1 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-[#172B4D] focus:outline-none"
            />
            <button
              onClick={() => handleAssistantCommand()}
              className="w-9 h-9 rounded-xl bg-[#172B4D] text-white flex items-center justify-center shrink-0 hover:bg-slate-800 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SUBVIEW: PROJECTS */}
      {subView === 'PROJECTS' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-[#172B4D]">Projets et jalons</span>
            <span className="text-[11px] text-slate-500">{projects.length} projet(s) actif(s)</span>
          </div>

          {projects.map((proj) => (
            <div key={proj.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-sm text-[#172B4D]">{proj.title}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{proj.objective}</p>
                </div>
                <span className="text-xs font-bold text-teal-700 tabular-nums">
                  {proj.progressPercentage}%
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-teal-600 rounded-full transition-all"
                  style={{ width: `${proj.progressPercentage}%` }}
                />
              </div>

              {/* Milestones */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold text-slate-700 block">Jalons :</span>
                {proj.milestones.map((m) => (
                  <div key={m.id} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-50">
                    <span className={m.completed ? 'line-through text-slate-400' : 'text-slate-800'}>
                      {m.title}
                    </span>
                    <span className="text-[10px] text-slate-400">{m.dueDate}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBVIEW: MEETINGS */}
      {subView === 'MEETINGS' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-[#172B4D]">Réunions & Décisions</span>
          </div>

          {meetings.map((m) => (
            <div key={m.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-3 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">{m.title}</h3>
                  <span className="text-slate-500 text-[11px]">
                    {m.date} · {m.startTime} – {m.endTime} · {m.location}
                  </span>
                </div>
              </div>

              <div className="p-2.5 bg-slate-50 rounded-xl space-y-1">
                <span className="font-semibold text-slate-700 block text-[11px]">Décisions prises :</span>
                {m.decisions.map((dec, i) => (
                  <div key={i} className="flex items-center justify-between gap-2">
                    <span className="text-slate-800 leading-tight">✓ {dec}</span>
                    <button
                      onClick={() => handleConvertMeetingDecision(m, dec)}
                      className="px-2 py-0.5 rounded bg-teal-50 text-teal-800 hover:bg-teal-100 text-[10px] font-semibold shrink-0"
                    >
                      Créer tâche
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUBVIEW: FOLLOWUPS (Relances) */}
      {subView === 'FOLLOWUPS' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-[#172B4D]">Suivi des Relances</span>
          </div>

          {followUps.map((fol) => (
            <div key={fol.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-2.5 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-sm text-[#172B4D]">{fol.contactOrOrg}</h3>
                  <span className="text-slate-600 font-medium">{fol.subject}</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 text-[10px] font-bold">
                  {fol.status}
                </span>
              </div>

              <div className="flex items-center justify-between text-slate-500 text-[11px]">
                <span>Dernier contact : {fol.lastContactDate}</span>
                <span className="font-semibold text-rose-600">Échéance relance : {fol.followUpDeadline}</span>
              </div>

              {fol.templateMessage && (
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/70 space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-semibold text-slate-500">
                    <span>Modèle de message préparé</span>
                    <button
                      onClick={() => {
                        navigator.clipboard?.writeText(fol.templateMessage || '');
                        toastService.info('Message copié dans le presse-papier !');
                      }}
                      className="text-teal-700 hover:underline flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" /> Copier
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-700 italic">"{fol.templateMessage}"</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* SUBVIEW: NOTES */}
      {subView === 'NOTES' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-[#172B4D]">Notes et documents</span>
          </div>

          {notes.map((n) => (
            <div key={n.id} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm space-y-2 text-xs">
              <h3 className="font-bold text-sm text-slate-900">{n.title}</h3>
              <p className="text-slate-600 whitespace-pre-line leading-relaxed">{n.content}</p>
              <div className="flex items-center gap-1 pt-1">
                {n.tags.map((t, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px]">
                    #{t}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
