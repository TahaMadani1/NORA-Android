import React from 'react';
import { 
  BarChart3, 
  ArrowLeft, 
  Clock, 
  CheckCircle, 
  RotateCcw, 
  TrendingUp, 
  Calendar,
  Layers
} from 'lucide-react';
import { db } from '../../services/storage/database';
import { CATEGORY_THEMES } from '../../theme/colors';

interface ReportsScreenProps {
  onBack: () => void;
}

export const ReportsScreen: React.FC<ReportsScreenProps> = ({ onBack }) => {
  const tasks = db.getTasks();
  const sessions = db.getSessions();

  const completedTasks = tasks.filter((t) => t.status === 'COMPLETED');
  const activeTasks = tasks.filter((t) => t.status !== 'COMPLETED');
  const postponedTasks = tasks.filter((t) => t.postponementCount > 0);

  const totalEstimatedM = tasks.reduce((sum, t) => sum + t.totalEstimatedMinutes, 0);
  const totalRemainingM = tasks.reduce((sum, t) => sum + t.remainingMinutes, 0);
  const totalCompletedM = Math.max(0, totalEstimatedM - totalRemainingM);

  // Breakdown by category (excluding PRAYER from productivity scores)
  const categoryBreakdown: Record<string, number> = {};
  tasks.forEach((t) => {
    categoryBreakdown[t.category] = (categoryBreakdown[t.category] || 0) + t.totalEstimatedMinutes;
  });

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
      {/* Top Bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-base font-bold text-[#172B4D]">Bilans & Statistiques Réelles</h1>
          <p className="text-[11px] text-slate-500">Mesure des avancées concrètes sans score de culpabilisation</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm text-xs space-y-1">
          <span className="text-slate-500 font-medium">Temps productif validé</span>
          <div className="text-xl font-bold text-[#172B4D] tabular-nums">
            {Math.floor(totalCompletedM / 60)}h{(totalCompletedM % 60).toString().padStart(2, '0')}
          </div>
          <span className="text-[10px] text-emerald-600 block">Sur {Math.round(totalEstimatedM / 60)}h estimées</span>
        </div>

        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm text-xs space-y-1">
          <span className="text-slate-500 font-medium">Tâches finalisées</span>
          <div className="text-xl font-bold text-emerald-700 tabular-nums">
            {completedTasks.length} / {tasks.length}
          </div>
          <span className="text-[10px] text-slate-400 block">{activeTasks.length} tâches en cours</span>
        </div>
      </div>

      {/* Postponement & Anti-procrastination diagnostics */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-2.5 text-xs">
        <div className="flex items-center justify-between">
          <span className="font-bold text-[#172B4D] text-sm">Analyse des reports</span>
          <span className="text-orange-600 font-bold tabular-nums">
            {postponedTasks.length} tâche(s) avec décalages
          </span>
        </div>
        <p className="text-slate-600 text-[11px] leading-relaxed">
          NORA surveille les tâches reportées à répétition afin d'éviter les chaînes de report infinies et proposer un découpage réaliste.
        </p>

        {postponedTasks.length > 0 && (
          <div className="space-y-1.5 pt-1">
            {postponedTasks.map((pt) => (
              <div key={pt.id} className="p-2.5 rounded-xl bg-orange-50/70 border border-orange-200/60 flex items-center justify-between">
                <span className="font-medium text-slate-800">{pt.title}</span>
                <span className="text-orange-700 font-bold">{pt.postponementCount} report(s)</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Category Distribution */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3 text-xs">
        <span className="font-bold text-[#172B4D] text-sm block">Répartition par catégorie</span>
        <div className="space-y-2">
          {Object.entries(categoryBreakdown).map(([catKey, totalMin]) => {
            const cat = CATEGORY_THEMES[catKey as keyof typeof CATEGORY_THEMES] || CATEGORY_THEMES.STUDIES;
            const percentage = totalEstimatedM > 0 ? Math.round((totalMin / totalEstimatedM) * 100) : 0;

            return (
              <div key={catKey} className="space-y-1">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="font-semibold text-slate-700">{cat.label}</span>
                  <span className="text-slate-500 tabular-nums">
                    {Math.round(totalMin / 60)}h ({percentage}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${percentage}%`, backgroundColor: cat.color }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
