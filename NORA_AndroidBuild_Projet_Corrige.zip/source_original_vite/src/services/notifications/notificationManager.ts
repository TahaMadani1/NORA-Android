import { NotificationRecord } from '../../types';
import { db } from '../storage/database';
import { soundService } from '../audio/soundService';

export interface AndroidChannelConfig {
  id: 'prayers' | 'appointments' | 'tasks' | 'deadlines' | 'reports';
  name: string;
  description: string;
  importance: 'HIGH' | 'DEFAULT' | 'LOW';
  vibration: boolean;
  sound: boolean;
  lockscreenVisibility: 'PUBLIC' | 'PRIVATE' | 'SECRET';
}

export const ANDROID_CHANNELS: AndroidChannelConfig[] = [
  {
    id: 'prayers',
    name: 'Horaires des Prières (Rabat)',
    description: 'Adhan officiel et rappels de préparation/ablutions 15 min en amont.',
    importance: 'HIGH',
    vibration: true,
    sound: true,
    lockscreenVisibility: 'PUBLIC'
  },
  {
    id: 'appointments',
    name: 'Engagements & Cours fixes',
    description: 'Contraintes dures, cours universitaires et examens non déplaçables.',
    importance: 'HIGH',
    vibration: true,
    sound: true,
    lockscreenVisibility: 'PUBLIC'
  },
  {
    id: 'tasks',
    name: 'Séances de travail & Focus',
    description: 'Débuts de sessions, rappels de reprise et pauses planifiées.',
    importance: 'DEFAULT',
    vibration: true,
    sound: false,
    lockscreenVisibility: 'PRIVATE'
  },
  {
    id: 'deadlines',
    name: 'Échéances & Jalons critiques',
    description: 'Alertes J-1 et H-3 sur les livrables importants P1 et P2.',
    importance: 'HIGH',
    vibration: true,
    sound: true,
    lockscreenVisibility: 'PUBLIC'
  },
  {
    id: 'reports',
    name: 'Bilans & Rappels discrets',
    description: 'Briefing matinal et bilan de journée sans intrusion sonore.',
    importance: 'LOW',
    vibration: false,
    sound: false,
    lockscreenVisibility: 'SECRET'
  }
];

class NotificationManager {
  private permissionStatus: 'granted' | 'denied' | 'default' = 'default';

  constructor() {
    this.checkBrowserPermission();
  }

  private checkBrowserPermission(): void {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      this.permissionStatus = Notification.permission;
    }
  }

  getPermissionStatus(): 'granted' | 'denied' | 'default' {
    this.checkBrowserPermission();
    return this.permissionStatus;
  }

  async requestPermission(): Promise<boolean> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const result = await Notification.requestPermission();
        this.permissionStatus = result;
        return result === 'granted';
      } catch {
        return false;
      }
    }
    return false;
  }

  sendRealNotification(channelId: AndroidChannelConfig['id'], title: string, body: string, entityId?: string): void {
    const channel = ANDROID_CHANNELS.find(c => c.id === channelId);
    
    // Store in local DB history
    const notifRecord: NotificationRecord = {
      id: 'notif-' + Date.now(),
      channelId,
      title,
      body,
      scheduledTime: new Date().toISOString(),
      status: 'SENT',
      entityId
    };
    db.addNotification(notifRecord);

    // Play acoustic procedural audio feedback
    if (channel && channel.sound) {
      if (channelId === 'prayers') {
        soundService.playPrayerChime();
      } else {
        soundService.playFocusEndChime();
      }
    }

    // If browser supports real system notifications, dispatch
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
          tag: channelId,
          silent: channel ? !channel.sound : false
        });
      } catch (e) {
        console.warn('System notification error:', e);
      }
    }
  }

  sendTestNotification(): void {
    this.sendRealNotification(
      'prayers',
      'NORA — Test Prière Dhuhr (Rabat)',
      'Adhan dans 15 minutes. Vos créneaux de travail sont protégés.'
    );
  }
}

export const notificationService = new NotificationManager();
