import {
  Task,
  ScheduledSession,
  RecurringRule,
  SchedulePeriod,
  Project,
  Meeting,
  FollowUp,
  NoteItem,
  Recipe,
  ShoppingItem,
  Workout,
  EnergyCheckIn,
  NotificationRecord,
  AppSettings,
  DailyPrayerTimes
} from '../../types';

const DB_STORAGE_KEY = 'NORA_DB_V1';
const CURRENT_SCHEMA_VERSION = 1;

export interface DatabaseDump {
  version: number;
  exportedAt: string;
  appSettings: AppSettings;
  tasks: Task[];
  sessions: ScheduledSession[];
  recurringRules: RecurringRule[];
  schedulePeriods: SchedulePeriod[];
  projects: Project[];
  meetings: Meeting[];
  followUps: FollowUp[];
  notes: NoteItem[];
  recipes: Recipe[];
  shoppingItems: ShoppingItem[];
  workouts: Workout[];
  energyCheckIns: EnergyCheckIn[];
  notifications: NotificationRecord[];
}

export const DEFAULT_SETTINGS: AppSettings = {
  operatingMode: 'NORMAL',
  city: 'Rabat',
  timezone: 'Africa/Casablanca',
  discretionaryWorkloadLimitHours: 4,
  bufferPercentage: 20,
  focusBlockMinutes: 50,
  breakMinutes: 10,
  fajrProtection: {
    preparationMinutes: 15,
    travelMinutes: 5,
    waitingMinutes: 10,
    prayerMinutes: 18,
    returnMinutes: 5,
    reminderMinutesBefore: 15
  },
  dhuhrProtection: {
    preparationMinutes: 10,
    travelMinutes: 5,
    waitingMinutes: 10,
    prayerMinutes: 15,
    returnMinutes: 5,
    reminderMinutesBefore: 15
  },
  asrProtection: {
    preparationMinutes: 10,
    travelMinutes: 5,
    waitingMinutes: 10,
    prayerMinutes: 15,
    returnMinutes: 5,
    reminderMinutesBefore: 15
  },
  maghribProtection: {
    preparationMinutes: 10,
    travelMinutes: 5,
    waitingMinutes: 5,
    prayerMinutes: 15,
    returnMinutes: 5,
    reminderMinutesBefore: 15
  },
  ishaProtection: {
    preparationMinutes: 10,
    travelMinutes: 5,
    waitingMinutes: 10,
    prayerMinutes: 18,
    returnMinutes: 5,
    reminderMinutesBefore: 15
  },
  jumuahSettings: {
    enabled: true,
    preparationMinutes: 30,
    travelMinutes: 20,
    khutbahAndPrayerMinutes: 45,
    returnMinutes: 20,
    mosqueName: 'Mosquée As-Sounnah (Avenue Mohammed V, Rabat)',
    preferredMosqueTime: '12:30'
  },
  sleepPreference: {
    targetBedtime: '23:00',
    targetWakeTime: '06:30',
    targetHours: 7.5,
    minHours: 6.0,
    maxHours: 9.0,
    fajrAwareBedtimeAdjustment: true,
    allowNap: true,
    napDurationMinutes: 25,
    napPreferredTime: '14:00'
  },
  notificationsEnabled: true,
  lockScreenPrivacy: 'SHOW_ALL',
  isDarkMode: false,
  isRamadanMode: false
};

class LocalDatabase {
  private data: DatabaseDump;

  constructor() {
    this.data = this.loadFromStorage() || this.createInitialData();
  }

  private loadFromStorage(): DatabaseDump | null {
    try {
      if (typeof window === 'undefined' || typeof window.localStorage === 'undefined') {
        return null;
      }
      const stored = window.localStorage.getItem(DB_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.version === CURRENT_SCHEMA_VERSION && parsed.appSettings) {
          // Merge defensively with DEFAULT_SETTINGS to ensure newly added properties (like minHours/maxHours) are present
          parsed.appSettings = {
            ...DEFAULT_SETTINGS,
            ...parsed.appSettings,
            sleepPreference: {
              ...DEFAULT_SETTINGS.sleepPreference,
              ...(parsed.appSettings.sleepPreference || {})
            }
          };
          return parsed;
        }
      }
    } catch {
      // ignore
    }
    return null;
  }

  private saveToStorage(): void {
    try {
      if (typeof window !== 'undefined' && typeof window.localStorage !== 'undefined') {
        window.localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(this.data));
      }
    } catch (e) {
      console.error('Failed to save to localStorage', e);
    }
  }

  private createInitialData(): DatabaseDump {
    const today = '2026-10-13';
    const initData: DatabaseDump = {
      version: CURRENT_SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      appSettings: DEFAULT_SETTINGS,
      tasks: [
        {
          id: 'task-1',
          title: 'Réviser la programmation dynamique (Algorithmique)',
          description: 'Sous-structures optimales, mémoïsation, problème du sac à dos et alignement de séquences.',
          category: 'STUDIES',
          priority: 'P1',
          constraintLevel: 'LEVEL_3',
          status: 'UNCOMPLETED',
          totalEstimatedMinutes: 180,
          remainingMinutes: 120,
          energyLevel: 4,
          isFixed: false,
          schedulingPreference: 'BEFORE_DEADLINE',
          deadline: '2026-10-16T18:00',
          postponementCount: 0,
          subtasks: [
            { id: 'sub-1', title: 'Relire le cours sur les relations de récurrence', completed: true },
            { id: 'sub-2', title: 'Résoudre les 4 exercices de TD', completed: false },
            { id: 'sub-3', title: 'Rédiger la fiche de synthèse', completed: false }
          ],
          materialsNeeded: ['Cahier de TD', 'Calculatrice', 'Support PDF Professeur'],
          createdAt: '2026-10-12T10:00:00Z',
          updatedAt: '2026-10-13T07:00:00Z'
        },
        {
          id: 'task-2',
          title: 'Préparer la présentation d’avancement de projet',
          description: 'Slides de synthèse pour le comité de suivi mensuel.',
          category: 'WORK',
          priority: 'P2',
          constraintLevel: 'LEVEL_3',
          status: 'IN_PROGRESS',
          totalEstimatedMinutes: 90,
          remainingMinutes: 45,
          energyLevel: 3,
          isFixed: false,
          schedulingPreference: 'ON_DATE',
          targetDate: '2026-10-13',
          postponementCount: 1,
          subtasks: [
            { id: 'sub-4', title: 'Chiffrer les indicateurs clés', completed: true },
            { id: 'sub-5', title: 'Valider le plan avec Youssef', completed: false }
          ],
          createdAt: '2026-10-11T14:00:00Z',
          updatedAt: '2026-10-13T08:00:00Z'
        },
        {
          id: 'task-3',
          title: 'Dépôt du dossier de bourse / stage à l’administration',
          description: 'Fournir l’attestation d’inscription et le relevé de notes certifié.',
          category: 'ADMIN',
          priority: 'P2',
          constraintLevel: 'LEVEL_1',
          status: 'UNCOMPLETED',
          totalEstimatedMinutes: 45,
          remainingMinutes: 45,
          energyLevel: 2,
          isFixed: true,
          schedulingPreference: 'EXACT_TIME',
          targetDate: '2026-10-14',
          targetTime: '10:00',
          location: 'Bureau de la scolarité centrale, Rabat',
          postponementCount: 0,
          subtasks: [
            { id: 'sub-6', title: 'Imprimer les justificatifs', completed: false }
          ],
          materialsNeeded: ['Pièce d’identité', 'Attestation originale', 'Enveloppe timbrée'],
          createdAt: '2026-10-12T15:00:00Z',
          updatedAt: '2026-10-12T15:00:00Z'
        }
      ],
      sessions: [
        {
          id: 'sess-1',
          taskId: 'task-1',
          title: 'Réviser la programmation dynamique',
          category: 'STUDIES',
          priority: 'P1',
          constraintLevel: 'LEVEL_3',
          date: today,
          startTime: '09:00',
          endTime: '10:30',
          status: 'CONFIRMED',
          confirmedMinutes: 60,
          isLocked: false
        },
        {
          id: 'sess-fixed-1',
          title: 'Cours magistral : Architecture des Systèmes Distribués',
          category: 'STUDIES',
          priority: 'P2',
          constraintLevel: 'LEVEL_1',
          date: today,
          startTime: '10:45',
          endTime: '12:15',
          status: 'SCHEDULED',
          isLocked: true,
          location: 'Amphi Ibn Rochd, Rabat'
        },
        {
          id: 'sess-2',
          taskId: 'task-2',
          title: 'Préparer la présentation d’avancement',
          category: 'WORK',
          priority: 'P2',
          constraintLevel: 'LEVEL_3',
          date: today,
          startTime: '16:00',
          endTime: '17:00',
          status: 'SCHEDULED',
          isLocked: false
        },
        {
          id: 'sess-3',
          title: 'Séance Entraînement : Full Body & Cardio',
          category: 'PERSONAL',
          priority: 'P3',
          constraintLevel: 'LEVEL_2',
          date: today,
          startTime: '17:15',
          endTime: '18:30',
          status: 'SCHEDULED',
          isLocked: false,
          location: 'Salle de sport Agdal / Rabat'
        }
      ],
      recurringRules: [
        {
          id: 'rec-1',
          title: 'Cours : Architecture des Systèmes Distribués',
          category: 'STUDIES',
          priority: 'P2',
          constraintLevel: 'LEVEL_1',
          frequency: 'WEEKLY',
          daysOfWeek: [2], // Mardi
          startTime: '10:45',
          endTime: '12:15',
          startDate: '2026-09-15',
          endDate: '2026-12-18',
          periodId: 'per-1',
          location: 'Amphi Ibn Rochd, Rabat'
        },
        {
          id: 'rec-2',
          title: 'TD : Algorithmique Avancée & Graphes',
          category: 'STUDIES',
          priority: 'P1',
          constraintLevel: 'LEVEL_1',
          frequency: 'WEEKLY',
          daysOfWeek: [4], // Jeudi
          startTime: '14:00',
          endTime: '16:00',
          startDate: '2026-09-15',
          endDate: '2026-12-18',
          periodId: 'per-1',
          location: 'Salle TD 12, Rabat'
        }
      ],
      schedulePeriods: [
        {
          id: 'per-1',
          name: 'Semestre d’Automne 2026',
          startDate: '2026-09-15',
          endDate: '2026-12-18',
          isActive: true,
          description: 'Période académique ordinaire (cours, TP et TD)'
        },
        {
          id: 'per-2',
          name: 'Session d’Examens Finaux',
          startDate: '2026-12-19',
          endDate: '2027-01-15',
          isActive: false,
          description: 'Période bloquée exclusivement pour révisions et épreuves'
        }
      ],
      projects: [
        {
          id: 'proj-1',
          title: 'Plateforme Web & Mobile Open Data Rabat',
          objective: 'Concevoir l’architecture et l’API REST pour la mobilité urbaine à Rabat.',
          category: 'WORK',
          deadline: '2026-11-20',
          progressPercentage: 45,
          milestones: [
            { id: 'm-1', title: 'Spécifications fonctionnelles et diagramme de classes', dueDate: '2026-10-15', completed: true },
            { id: 'm-2', title: 'Développement du module d’ingestion temps réel', dueDate: '2026-10-30', completed: false },
            { id: 'm-3', title: 'Recette et tests d’intégration', dueDate: '2026-11-15', completed: false }
          ],
          createdAt: '2026-09-20'
        }
      ],
      meetings: [
        {
          id: 'meet-1',
          title: 'Point d’alignement Projet Tuteur',
          date: today,
          startTime: '14:30',
          endTime: '15:15',
          location: 'Bureau B204, Faculté des Sciences, Rabat',
          participants: ['Dr. El Mansouri', 'Moi'],
          agenda: 'Revue de la méthodologie et validation du calendrier.',
          notes: 'Discussion constructive. Le professeur insiste sur la rigueur du modèle mathématique.',
          decisions: [
            'Privilégier l’approche locale plutôt qu’une dépendance API cloud externe.',
            'Planifier le prochain point d’étape le 27 octobre.'
          ],
          actions: [
            { id: 'act-1', taskTitle: 'Finaliser la synthèse bibliographique pour le 20 oct.' }
          ]
        }
      ],
      followUps: [
        {
          id: 'fol-1',
          contactOrOrg: 'Secrétariat Pédagogique (Mme Bennani)',
          subject: 'Attestation de scolarité pour le transport Tramway Rabat-Salé',
          lastContactDate: '2026-10-09',
          expectedResponse: 'Attestation signée par le doyen',
          followUpDeadline: '2026-10-14',
          status: 'PENDING',
          notes: 'Passer au bureau le matin entre 10h et 12h.',
          templateMessage: 'Bonjour Mme Bennani, je me permets de vous relancer concernant l’attestation de scolarité pour le renouvellement de la carte d’abonnement Tramway. Je vous remercie.'
        }
      ],
      notes: [
        {
          id: 'note-1',
          title: 'Principes de programmation dynamique',
          content: '1. Identifier les sous-problèmes.\n2. Écrire la relation de Bellman.\n3. Déterminer l’ordre de calcul (bottom-up ou mémoïsation top-down).\n4. Reconstituer la solution optimale.',
          category: 'STUDIES',
          tags: ['Algorithmique', 'Examens', 'Exemple'],
          updatedAt: '2026-10-12T18:00:00Z'
        }
      ],
      recipes: [
        {
          id: 'recip-1',
          name: 'Tajine de Poulet aux Légumes & Riz Complet (Prise de masse propre)',
          servings: 2,
          prepMinutes: 15,
          activeCookMinutes: 10,
          passiveCookMinutes: 35,
          cleanupMinutes: 10,
          caloriesPerServing: 680,
          proteinGrams: 52,
          carbsGrams: 75,
          fatsGrams: 14,
          isBulkingFriendly: true,
          ingredients: [
            { id: 'ing-1', name: 'Blancs de poulet', quantity: '350g', category: 'Boucherie', isInPantry: true },
            { id: 'ing-2', name: 'Riz basmati complet', quantity: '200g', category: 'Épicerie', isInPantry: true },
            { id: 'ing-3', name: 'Carottes & Courgettes', quantity: '3 pièces', category: 'Légumes', isInPantry: false },
            { id: 'ing-4', name: 'Huile d’olive marocaine & Épices', quantity: '2 c.à.s', category: 'Épicerie', isInPantry: true }
          ]
        }
      ],
      shoppingItems: [
        { id: 'shop-1', name: 'Carottes & Courgettes (Marché Agdal)', quantity: '1 kg', category: 'Légumes', completed: false, addedFromRecipeId: 'recip-1' },
        { id: 'shop-2', name: 'Oeufs frais', quantity: '30 pièces', category: 'Frais', completed: false },
        { id: 'shop-3', name: 'Flocons d’avoine complets', quantity: '1 kg', category: 'Épicerie', completed: true }
      ],
      workouts: [
        {
          id: 'work-1',
          title: 'Pectoraux & Triceps (Force & Hypertrophie)',
          type: 'GYM',
          prepMinutes: 10,
          durationMinutes: 55,
          travelMinutes: 15,
          showerMinutes: 15,
          exercises: [
            { id: 'ex-1', name: 'Développé couché barre', sets: 4, reps: '8-10', weight: '75kg' },
            { id: 'ex-2', name: 'Développé incliné haltères', sets: 3, reps: '10-12', weight: '26kg' },
            { id: 'ex-3', name: 'Dips aux barres parallèles', sets: 3, reps: '12', weight: 'Poids du corps' },
            { id: 'ex-4', name: 'Extensions triceps à la poulie', sets: 4, reps: '12-15', weight: '30kg' }
          ],
          notes: 'Prendre 1 minute de repos entre chaque série. Bien s’hydrater.'
        }
      ],
      energyCheckIns: [
        {
          id: 'eng-1',
          date: today,
          level: 'NORMALE',
          sleepQuality: 'BON',
          notes: 'Réveil à 06h20 avant le lever du soleil. Bonne lucidité pour les séances du matin.'
        }
      ],
      notifications: [
        {
          id: 'notif-1',
          channelId: 'prayers',
          title: 'Adhan Dhuhr dans 15 min (Rabat)',
          body: 'Prépare tes ablutions pour la prière de Dhuhr prévue à 12:20.',
          scheduledTime: '2026-10-13T12:05:00',
          status: 'SENT'
        },
        {
          id: 'notif-2',
          channelId: 'tasks',
          title: 'Session à venir : Présentation projet',
          body: 'Ta séance de 45 minutes commence à 16:00.',
          scheduledTime: '2026-10-13T15:45:00',
          status: 'PENDING'
        }
      ]
    };
    return initData;
  }

  // --- SETTINGS ---
  getSettings(): AppSettings {
    return this.data.appSettings;
  }

  updateSettings(settings: Partial<AppSettings>): AppSettings {
    this.data.appSettings = { ...this.data.appSettings, ...settings };
    this.saveToStorage();
    return this.data.appSettings;
  }

  // --- TASKS ---
  getTasks(): Task[] {
    return [...this.data.tasks];
  }

  getTaskById(id: string): Task | undefined {
    return this.data.tasks.find(t => t.id === id);
  }

  saveTask(task: Task): Task {
    const idx = this.data.tasks.findIndex(t => t.id === task.id);
    task.updatedAt = new Date().toISOString();
    if (idx >= 0) {
      this.data.tasks[idx] = task;
    } else {
      this.data.tasks.push(task);
    }
    this.saveToStorage();
    return task;
  }

  deleteTask(id: string): void {
    this.data.tasks = this.data.tasks.filter(t => t.id !== id);
    // Also remove associated scheduled sessions
    this.data.sessions = this.data.sessions.filter(s => s.taskId !== id);
    this.saveToStorage();
  }

  // --- SESSIONS ---
  getSessions(): ScheduledSession[] {
    return [...this.data.sessions];
  }

  getSessionsForDate(dateStr: string): ScheduledSession[] {
    return this.data.sessions.filter(s => s.date === dateStr);
  }

  saveSession(session: ScheduledSession): ScheduledSession {
    const idx = this.data.sessions.findIndex(s => s.id === session.id);
    if (idx >= 0) {
      this.data.sessions[idx] = session;
    } else {
      this.data.sessions.push(session);
    }
    this.saveToStorage();
    return session;
  }

  deleteSession(id: string): void {
    this.data.sessions = this.data.sessions.filter(s => s.id !== id);
    this.saveToStorage();
  }

  // --- RECURRING RULES ---
  getRecurringRules(): RecurringRule[] {
    return [...this.data.recurringRules];
  }

  saveRecurringRule(rule: RecurringRule): RecurringRule {
    const idx = this.data.recurringRules.findIndex(r => r.id === rule.id);
    if (idx >= 0) {
      this.data.recurringRules[idx] = rule;
    } else {
      this.data.recurringRules.push(rule);
    }
    this.saveToStorage();
    return rule;
  }

  deleteRecurringRule(id: string): void {
    this.data.recurringRules = this.data.recurringRules.filter(r => r.id !== id);
    this.saveToStorage();
  }

  // --- SCHEDULE PERIODS ---
  getSchedulePeriods(): SchedulePeriod[] {
    return [...this.data.schedulePeriods];
  }

  saveSchedulePeriod(period: SchedulePeriod): SchedulePeriod {
    const idx = this.data.schedulePeriods.findIndex(p => p.id === period.id);
    if (idx >= 0) {
      this.data.schedulePeriods[idx] = period;
    } else {
      this.data.schedulePeriods.push(period);
    }
    this.saveToStorage();
    return period;
  }

  // --- PROJECTS ---
  getProjects(): Project[] {
    return [...this.data.projects];
  }

  saveProject(project: Project): Project {
    const idx = this.data.projects.findIndex(p => p.id === project.id);
    if (idx >= 0) {
      this.data.projects[idx] = project;
    } else {
      this.data.projects.push(project);
    }
    this.saveToStorage();
    return project;
  }

  deleteProject(id: string): void {
    this.data.projects = this.data.projects.filter(p => p.id !== id);
    this.saveToStorage();
  }

  // --- MEETINGS ---
  getMeetings(): Meeting[] {
    return [...this.data.meetings];
  }

  saveMeeting(meeting: Meeting): Meeting {
    const idx = this.data.meetings.findIndex(m => m.id === meeting.id);
    if (idx >= 0) {
      this.data.meetings[idx] = meeting;
    } else {
      this.data.meetings.push(meeting);
    }
    this.saveToStorage();
    return meeting;
  }

  // --- FOLLOW-UPS ---
  getFollowUps(): FollowUp[] {
    return [...this.data.followUps];
  }

  saveFollowUp(followUp: FollowUp): FollowUp {
    const idx = this.data.followUps.findIndex(f => f.id === followUp.id);
    if (idx >= 0) {
      this.data.followUps[idx] = followUp;
    } else {
      this.data.followUps.push(followUp);
    }
    this.saveToStorage();
    return followUp;
  }

  // --- NOTES ---
  getNotes(): NoteItem[] {
    return [...this.data.notes];
  }

  saveNote(note: NoteItem): NoteItem {
    const idx = this.data.notes.findIndex(n => n.id === note.id);
    if (idx >= 0) {
      this.data.notes[idx] = note;
    } else {
      this.data.notes.push(note);
    }
    this.saveToStorage();
    return note;
  }

  deleteNote(id: string): void {
    this.data.notes = this.data.notes.filter(n => n.id !== id);
    this.saveToStorage();
  }

  // --- MEALS & RECIPES ---
  getRecipes(): Recipe[] {
    return [...this.data.recipes];
  }

  saveRecipe(recipe: Recipe): Recipe {
    const idx = this.data.recipes.findIndex(r => r.id === recipe.id);
    if (idx >= 0) {
      this.data.recipes[idx] = recipe;
    } else {
      this.data.recipes.push(recipe);
    }
    this.saveToStorage();
    return recipe;
  }

  getShoppingItems(): ShoppingItem[] {
    return [...this.data.shoppingItems];
  }

  saveShoppingItem(item: ShoppingItem): ShoppingItem {
    const idx = this.data.shoppingItems.findIndex(i => i.id === item.id);
    if (idx >= 0) {
      this.data.shoppingItems[idx] = item;
    } else {
      this.data.shoppingItems.push(item);
    }
    this.saveToStorage();
    return item;
  }

  deleteShoppingItem(id: string): void {
    this.data.shoppingItems = this.data.shoppingItems.filter(i => i.id !== id);
    this.saveToStorage();
  }

  // --- WORKOUTS ---
  getWorkouts(): Workout[] {
    return [...this.data.workouts];
  }

  saveWorkout(workout: Workout): Workout {
    const idx = this.data.workouts.findIndex(w => w.id === workout.id);
    if (idx >= 0) {
      this.data.workouts[idx] = workout;
    } else {
      this.data.workouts.push(workout);
    }
    this.saveToStorage();
    return workout;
  }

  // --- ENERGY CHECK-INS ---
  getEnergyCheckIns(): EnergyCheckIn[] {
    return [...this.data.energyCheckIns];
  }

  saveEnergyCheckIn(checkIn: EnergyCheckIn): EnergyCheckIn {
    const idx = this.data.energyCheckIns.findIndex(c => c.date === checkIn.date);
    if (idx >= 0) {
      this.data.energyCheckIns[idx] = checkIn;
    } else {
      this.data.energyCheckIns.push(checkIn);
    }
    this.saveToStorage();
    return checkIn;
  }

  // --- NOTIFICATIONS ---
  getNotifications(): NotificationRecord[] {
    return [...this.data.notifications];
  }

  addNotification(notif: NotificationRecord): void {
    this.data.notifications.unshift(notif);
    this.saveToStorage();
  }

  dismissNotification(id: string): void {
    const item = this.data.notifications.find(n => n.id === id);
    if (item) {
      item.status = 'DISMISSED';
      this.saveToStorage();
    }
  }

  // --- BACKUP & RESTORE ---
  exportDatabaseJSON(): string {
    return JSON.stringify(this.data, null, 2);
  }

  importDatabaseJSON(jsonStr: string): { success: boolean; error?: string } {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed.version || !parsed.tasks || !parsed.appSettings) {
        return { success: false, error: 'Structure de sauvegarde invalide.' };
      }
      this.data = parsed;
      this.saveToStorage();
      return { success: true };
    } catch (e: any) {
      return { success: false, error: e?.message || 'Erreur lors du parsing JSON.' };
    }
  }

  resetToDefault(): void {
    this.data = this.createInitialData();
    this.saveToStorage();
  }
}

export const db = new LocalDatabase();
