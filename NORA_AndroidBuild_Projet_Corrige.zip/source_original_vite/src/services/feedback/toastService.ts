export type ToastType = 'success' | 'info' | 'warning' | 'error';

export interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
  durationMs: number;
}

type ToastListener = (toasts: ToastMessage[]) => void;

class ToastService {
  private toasts: ToastMessage[] = [];
  private listeners: ToastListener[] = [];

  subscribe(listener: ToastListener): () => void {
    this.listeners.push(listener);
    listener([...this.toasts]);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l([...this.toasts]));
  }

  show(message: string, type: ToastType = 'info', durationMs: number = 3800) {
    const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
    const newToast: ToastMessage = { id, message, type, durationMs };
    
    // Keep max 3 toasts visible at once
    this.toasts = [...this.toasts.slice(-2), newToast];
    this.notify();

    setTimeout(() => {
      this.dismiss(id);
    }, durationMs);
  }

  success(message: string, durationMs?: number) {
    this.show(message, 'success', durationMs ?? 3500);
  }

  info(message: string, durationMs?: number) {
    this.show(message, 'info', durationMs ?? 3500);
  }

  warning(message: string, durationMs?: number) {
    this.show(message, 'warning', durationMs ?? 4500);
  }

  error(message: string, durationMs?: number) {
    this.show(message, 'error', durationMs ?? 5000);
  }

  dismiss(id: string) {
    this.toasts = this.toasts.filter((t) => t.id !== id);
    this.notify();
  }
}

export const toastService = new ToastService();
