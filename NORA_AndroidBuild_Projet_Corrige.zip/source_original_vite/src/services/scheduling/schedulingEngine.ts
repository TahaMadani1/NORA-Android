import {
  Task,
  ScheduledSession,
  AppSettings,
  OperatingMode,
  TaskCategory,
  PriorityLevel
} from '../../types';
import { db } from '../storage/database';
import { checkPrayerConflict, getDailyPrayerSchedule, parseHHMMToMinutes } from '../prayerTimes/rabatPrayerService';

export interface ScheduleSlot {
  startTime: string; // HH:MM
  endTime: string;   // HH:MM
  durationMinutes: number;
}

export interface DayScheduleSummary {
  date: string;
  totalPlannedMinutes: number;
  remainingAvailableMinutes: number;
  fixedMinutes: number;
  prayerMinutes: number;
  sessions: ScheduledSession[];
  conflicts: string[];
  adviceList: string[];
}

export interface NaturalLanguageParseResult {
  title: string;
  category: TaskCategory;
  priority: PriorityLevel;
  estimatedMinutes: number;
  deadline?: string;
  isRecurring?: boolean;
  recurrenceDays?: number[];
  recurrenceStartTime?: string;
  recurrenceEndTime?: string;
  confidenceScore: number;
}

/**
 * Natural language parser for quick French commands
 */
export function parseNaturalLanguageTask(input: string): NaturalLanguageParseResult {
  const text = input.trim().toLowerCase();
  
  // Default values
  let category: TaskCategory = 'STUDIES';
  let priority: PriorityLevel = 'P3';
  let estimatedMinutes = 60;
  let deadline: string | undefined = undefined;
  let isRecurring = false;
  let recurrenceDays: number[] = [];
  let recurrenceStartTime: string | undefined;
  let recurrenceEndTime: string | undefined;

  // Category detection
  if (text.includes('sport') || text.includes('muscu') || text.includes('gym') || text.includes('courir')) {
    category = 'PERSONAL';
    estimatedMinutes = 75;
  } else if (text.includes('projet') || text.includes('réunion') || text.includes('client') || text.includes('travail') || text.includes('slides')) {
    category = 'WORK';
  } else if (text.includes('dossier') || text.includes('bourse') || text.includes('admin') || text.includes('banque') || text.includes('rendez-vous')) {
    category = 'ADMIN';
  } else if (text.includes('club') || text.includes('asso') || text.includes('bde')) {
    category = 'ASSOCIATION';
  } else if (text.includes('cours') || text.includes('td') || text.includes('tp') || text.includes('amphi') || text.includes('réviser') || text.includes('examen')) {
    category = 'STUDIES';
  }

  // Priority detection
  if (text.includes('urgent') || text.includes('critique') || text.includes('important') || text.includes('examen')) {
    priority = 'P1';
  } else if (text.includes('vite') || text.includes('prioritaire')) {
    priority = 'P2';
  }

  // Duration detection (e.g. "3 heures", "2h", "45 min", "30 minutes")
  const hourMatch = text.match(/(\d+)\s*(?:heure|heures|h)/);
  const minMatch = text.match(/(\d+)\s*(?:minute|minutes|min)/);
  if (hourMatch) {
    const hours = parseInt(hourMatch[1], 10);
    const extraMin = minMatch ? parseInt(minMatch[1], 10) : 0;
    estimatedMinutes = hours * 60 + extraMin;
  } else if (minMatch) {
    estimatedMinutes = parseInt(minMatch[1], 10);
  }

  // Recurring & schedule detection (e.g. "cours lundi de 8h à 10h chaque semaine")
  if (text.includes('chaque semaine') || text.includes('tous les') || text.includes('chaque')) {
    isRecurring = true;
    if (text.includes('lundi')) recurrenceDays.push(1);
    if (text.includes('mardi')) recurrenceDays.push(2);
    if (text.includes('mercredi')) recurrenceDays.push(3);
    if (text.includes('jeudi')) recurrenceDays.push(4);
    if (text.includes('vendredi')) recurrenceDays.push(5);
    if (text.includes('samedi')) recurrenceDays.push(6);
    if (text.includes('dimanche')) recurrenceDays.push(0);

    const timeRangeMatch = text.match(/de\s*(\d{1,2})h(?:(\d{2}))?\s*(?:à|au|-)\s*(\d{1,2})h(?:(\d{2}))?/);
    if (timeRangeMatch) {
      const sh = timeRangeMatch[1].padStart(2, '0');
      const sm = (timeRangeMatch[2] || '00').padStart(2, '0');
      const eh = timeRangeMatch[3].padStart(2, '0');
      const em = (timeRangeMatch[4] || '00').padStart(2, '0');
      recurrenceStartTime = `${sh}:${sm}`;
      recurrenceEndTime = `${eh}:${em}`;
    }
  }

  // Deadline extraction (e.g. "avant vendredi", "pour demain", "avant le 30 novembre")
  if (text.includes('demain')) {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    deadline = d.toISOString().split('T')[0] + 'T18:00';
  } else if (text.includes('vendredi')) {
    deadline = '2026-10-16T18:00';
  }

  // Clean title
  let title = input
    .replace(/pendant \d+\s*(?:heures?|h|min|minutes?)/i, '')
    .replace(/avant (?:vendredi|demain|ce soir)/i, '')
    .replace(/chaque semaine/i, '')
    .trim();

  if (title.length < 3) title = input;

  return {
    title: title.charAt(0).toUpperCase() + title.slice(1),
    category,
    priority,
    estimatedMinutes,
    deadline,
    isRecurring,
    recurrenceDays,
    recurrenceStartTime,
    recurrenceEndTime,
    confidenceScore: 0.92
  };
}

/**
 * Computes sleep duration in minutes taking into account midnight rollover
 */
export function calculateSleepDurationMinutes(bedtime: string, wakeTime: string): number {
  const b = parseHHMMToMinutes(bedtime);
  const w = parseHHMMToMinutes(wakeTime);
  if (b === w) return 0;
  return b > w ? (24 * 60 - b + w) : (w - b);
}

/**
 * Computes sleep duration in hours (rounded to 1 decimal)
 */
export function calculateSleepDurationHours(bedtime: string, wakeTime: string): number {
  return Math.round((calculateSleepDurationMinutes(bedtime, wakeTime) / 60) * 10) / 10;
}

export interface SleepValidationResult {
  durationHours: number;
  durationMinutes: number;
  isValid: boolean;        // true if strictly between 6.0 and 9.0 hours
  isUnderMinimum: boolean; // < 6.0h (seuil minimal vital)
  isOverMaximum: boolean;  // > 9.0h (plafond maximal recommandé)
  statusText: string;
  advice: string;
  badgeType: 'SUCCESS' | 'WARNING' | 'DANGER';
}

/**
 * Validates sleep duration against the non-negotiable rule: 6h minimum, 9h maximum
 */
export function validateSleepDuration(bedtime: string, wakeTime: string): SleepValidationResult {
  const durationMinutes = calculateSleepDurationMinutes(bedtime, wakeTime);
  const durationHours = Math.round((durationMinutes / 60) * 10) / 10;
  const isUnderMinimum = durationHours < 6.0;
  const isOverMaximum = durationHours > 9.0;
  const isValid = !isUnderMinimum && !isOverMaximum;

  let statusText = `Sommeil optimal (${durationHours}h — Conforme 6h–9h)`;
  let advice = 'Ta plage de repos respecte scrupuleusement la règle des 6h min à 9h max : idéale pour la récupération cognitive et la régulation hormonale.';
  let badgeType: 'SUCCESS' | 'WARNING' | 'DANGER' = 'SUCCESS';

  if (isUnderMinimum) {
    statusText = `Sommeil insuffisant (${durationHours}h < 6h00 minimum)`;
    advice = 'Alerte déficit : Moins de 6h de sommeil dégrade la mémoire de travail, élève le cortisol et compromet la vigilance. NORA recommande au minimum 6h00 de sommeil.';
    badgeType = 'DANGER';
  } else if (isOverMaximum) {
    statusText = `Sommeil prolongé (${durationHours}h > 9h00 maximum)`;
    advice = 'Attention somnolence : Au-delà de 9h de sommeil régulier, le rythme circadien se désynchronise. NORA conseille de limiter à 8h30–9h00 maximum.';
    badgeType = 'WARNING';
  }

  return {
    durationHours,
    durationMinutes,
    isValid,
    isUnderMinimum,
    isOverMaximum,
    statusText,
    advice,
    badgeType
  };
}

/**
 * Detects whether a given time interval collides with the protected sleep window (Level 1 Hard Constraint)
 */
export function checkSleepConflict(
  startTime: string,
  endTime: string,
  settings: AppSettings
): { hasConflict: boolean; message?: string } {
  if (!startTime || !endTime) return { hasConflict: false };
  const bedM = parseHHMMToMinutes(settings.sleepPreference.targetBedtime);
  const wakeM = parseHHMMToMinutes(settings.sleepPreference.targetWakeTime);
  const sM = parseHHMMToMinutes(startTime);
  const eM = parseHHMMToMinutes(endTime);

  if (sM === eM) return { hasConflict: false };

  const isMinuteInSleep = (m: number): boolean => {
    const min = ((m % 1440) + 1440) % 1440;
    if (bedM > wakeM) {
      // Midnight crossing: e.g. 23:00 (1380) to 06:30 (390)
      return min >= bedM || min < wakeM;
    } else if (bedM < wakeM) {
      return min >= bedM && min < wakeM;
    }
    return false;
  };

  let inConflict = false;
  const lastMinuteOfSession = ((eM - 1) % 1440 + 1440) % 1440;
  if (isMinuteInSleep(sM) || isMinuteInSleep(lastMinuteOfSession)) {
    inConflict = true;
  } else {
    // Check if session completely spans over bedtime or waketime
    const sessionDuration = sM < eM ? (eM - sM) : (1440 - sM + eM);
    for (let offset = 15; offset < sessionDuration; offset += 15) {
      if (isMinuteInSleep((sM + offset) % 1440)) {
        inConflict = true;
        break;
      }
    }
  }

  if (inConflict) {
    return {
      hasConflict: true,
      message: `empiète sur la fenêtre de sommeil protégé (${settings.sleepPreference.targetBedtime}–${settings.sleepPreference.targetWakeTime}). Contrainte de Niveau 1 violée !`
    };
  }

  return { hasConflict: false };
}

/**
 * Computes recommended bedtime targeting a given wake time while guaranteeing 6h to 9h of sleep
 */
export function computeRecommendedBedtime(wakeTime: string, targetHours: number): string {
  const constrainedHours = Math.max(6.0, Math.min(9.0, targetHours));
  const wakeM = parseHHMMToMinutes(wakeTime);
  const sleepM = Math.round(constrainedHours * 60);
  let bedM = (wakeM - sleepM) % 1440;
  if (bedM < 0) bedM += 1440;
  const h = Math.floor(bedM / 60);
  const m = bedM % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

export const computeIdealBedtime = computeRecommendedBedtime;

/**
 * Analyzes and calculates a realistic day schedule respecting hierarchy (Level 0 Prayers, Level 1 Sleep & Hard Constraints)
 */
export function calculateDaySchedule(dateStr: string, settings: AppSettings): DayScheduleSummary {
  const sessions = db.getSessionsForDate(dateStr);
  const tasks = db.getTasks();
  const prayerSchedule = getDailyPrayerSchedule(dateStr, settings);

  let totalPlannedMinutes = 0;
  let fixedMinutes = 0;
  let prayerMinutes = 0;
  const conflicts: string[] = [];
  const adviceList: string[] = [];

  // Calculate prayer minutes
  prayerSchedule.prayers.forEach(p => {
    const sM = parseHHMMToMinutes(p.protectedStart);
    const eM = parseHHMMToMinutes(p.protectedEnd);
    prayerMinutes += Math.max(0, eM - sM);
  });

  // Level 1: Sleep Window validation (6h min, 9h max)
  const sleepValidation = validateSleepDuration(
    settings.sleepPreference.targetBedtime,
    settings.sleepPreference.targetWakeTime
  );

  if (!sleepValidation.isValid) {
    if (sleepValidation.isUnderMinimum) {
      conflicts.push(`Alerte Sommeil (Niveau 1) : Durée configurée (${sleepValidation.durationHours}h) inférieure au minimum vital de 6h00 (${settings.sleepPreference.targetBedtime} à ${settings.sleepPreference.targetWakeTime}). Risque de déficit sévère.`);
    } else if (sleepValidation.isOverMaximum) {
      adviceList.push(`Observation Sommeil : Durée configurée (${sleepValidation.durationHours}h) supérieure au plafond conseillé de 9h00.`);
    }
  }

  // Check each session for conflicts with prayers, sleep window or other locked sessions
  sessions.forEach(sess => {
    const sM = parseHHMMToMinutes(sess.startTime);
    const eM = parseHHMMToMinutes(sess.endTime);
    const duration = Math.max(0, eM - sM);
    totalPlannedMinutes += duration;

    if (sess.constraintLevel === 'LEVEL_1' || sess.isLocked) {
      fixedMinutes += duration;
    }

    // Check prayer conflict (Level 0)
    const pConflict = checkPrayerConflict(dateStr, sess.startTime, sess.endTime, settings);
    if (pConflict.hasConflict) {
      conflicts.push(`« ${sess.title} » (${sess.startTime}-${sess.endTime}) empiète sur la prière protégée de ${pConflict.conflictingPrayer} (${pConflict.protectedWindow})`);
    }

    // Check sleep window conflict (Level 1)
    const sConflict = checkSleepConflict(sess.startTime, sess.endTime, settings);
    if (sConflict.hasConflict) {
      conflicts.push(`« ${sess.title} » (${sess.startTime}-${sess.endTime}) ${sConflict.message}`);
    }
  });

  // Fajr-aware sleep synchronization advice
  if (settings.sleepPreference.fajrAwareBedtimeAdjustment) {
    const fajrPrayer = prayerSchedule.prayers.find(p => p.name === 'FAJR');
    if (fajrPrayer) {
      const idealBedtime = computeRecommendedBedtime(fajrPrayer.time, settings.sleepPreference.targetHours);
      adviceList.push(`Synchro Fajr (Rabat) : Pour te réveiller au Fajr (${fajrPrayer.time}) avec ${settings.sleepPreference.targetHours}h de sommeil (cadre 6h–9h), heure de coucher conseillée : ${idealBedtime}.`);
    }
  }

  // Check workload limit
  const discretionaryLimitMinutes = settings.discretionaryWorkloadLimitHours * 60;
  const flexibleMinutes = totalPlannedMinutes - fixedMinutes;

  if (settings.operatingMode === 'RECOVERY') {
    adviceList.push('Mode Récupération actif : charge de travail allégée de 40%, sommeil et repos protégés.');
  } else if (flexibleMinutes > discretionaryLimitMinutes) {
    adviceList.push(`Charge de travail élevée (${Math.round(flexibleMinutes / 60)}h planifiées contre ${settings.discretionaryWorkloadLimitHours}h conseillées). NORA suggère d'alléger la soirée.`);
  }

  // Unfinished or repeated delay check
  const delayedTasks = tasks.filter(t => t.postponementCount >= 2 && t.status !== 'COMPLETED');
  if (delayedTasks.length > 0) {
    adviceList.push(`${delayedTasks.length} tâche(s) reportée(s) plusieurs fois (ex: "${delayedTasks[0].title}"). Envisage de la découper en blocs de 30 min.`);
  }

  // Free available discretionary time
  // Active window between wake and bed:
  const wakeM = parseHHMMToMinutes(settings.sleepPreference.targetWakeTime);
  const bedM = parseHHMMToMinutes(settings.sleepPreference.targetBedtime);
  const activeDayMinutes = bedM > wakeM ? (bedM - wakeM) : (24 * 60 - wakeM + bedM);
  
  // Account for buffer
  const bufferRatio = settings.bufferPercentage / 100;
  const bufferMinutes = activeDayMinutes * bufferRatio;
  const remainingAvailableMinutes = Math.max(0, activeDayMinutes - totalPlannedMinutes - prayerMinutes - bufferMinutes);

  if (remainingAvailableMinutes > 45) {
    adviceList.push(`Tu disposes d'un créneau respiratoire d'environ ${Math.round(remainingAvailableMinutes)} minutes d'ici ce soir.`);
  }

  return {
    date: dateStr,
    totalPlannedMinutes,
    remainingAvailableMinutes,
    fixedMinutes,
    prayerMinutes,
    sessions: [...sessions].sort((a, b) => a.startTime.localeCompare(b.startTime)),
    conflicts,
    adviceList
  };
}

/**
 * Reconciles expired sessions:
 * If a session time passed and was not marked confirmed or completed,
 * preserves master task and updates remaining effort without fabricating progress.
 */
export function reconcileExpiredSessions(currentHHMM: string, todayStr: string): { reconciledCount: number } {
  const sessions = db.getSessionsForDate(todayStr);
  const nowM = parseHHMMToMinutes(currentHHMM);
  let reconciledCount = 0;

  sessions.forEach(sess => {
    const endM = parseHHMMToMinutes(sess.endTime);
    if (endM < nowM && sess.status === 'SCHEDULED') {
      // Mark as EXPIRED/UNCONFIRMED, never assume done
      sess.status = 'EXPIRED';
      db.saveSession(sess);

      if (sess.taskId) {
        const task = db.getTaskById(sess.taskId);
        if (task && task.status !== 'COMPLETED') {
          task.postponementCount += 1;
          task.status = 'POSTPONED';
          db.saveTask(task);
        }
      }
      reconciledCount++;
    }
  });

  return { reconciledCount };
}

/**
 * Proposes a Plan A (Balanced) and Plan B (Lightened/Recovery)
 */
export function generateSchedulePlans(dateStr: string, settings: AppSettings): {
  planA: { description: string; totalMinutes: number; sessions: ScheduledSession[] };
  planB: { description: string; totalMinutes: number; sessions: ScheduledSession[] };
} {
  const allSessions = db.getSessionsForDate(dateStr);

  const planASessions = [...allSessions];

  // Plan B filters out P3/P4 flexible items and keeps P1/P2 + Level 1 hard constraints
  const planBSessions = allSessions.filter(s => 
    s.constraintLevel === 'LEVEL_1' || 
    s.isLocked || 
    s.priority === 'P1' || 
    s.category === 'PERSONAL' // Keeps meals/gym/rest
  );

  const totalA = planASessions.reduce((acc, s) => acc + (parseHHMMToMinutes(s.endTime) - parseHHMMToMinutes(s.startTime)), 0);
  const totalB = planBSessions.reduce((acc, s) => acc + (parseHHMMToMinutes(s.endTime) - parseHHMMToMinutes(s.startTime)), 0);

  return {
    planA: {
      description: 'Plan A — Équilibré : maintien de tous les créneaux avec pauses intercalaires et protection des prières.',
      totalMinutes: totalA,
      sessions: planASessions
    },
    planB: {
      description: 'Plan B — Allégé : concentration sur les cours obligatoires et la tâche critique P1. Report du reste.',
      totalMinutes: totalB,
      sessions: planBSessions
    }
  };
}
