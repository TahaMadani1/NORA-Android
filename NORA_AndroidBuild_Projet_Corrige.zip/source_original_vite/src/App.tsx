import React, { useState } from 'react';
import { AndroidFrame } from './components/AndroidFrame';
import { Header } from './components/Header';
import { BottomTabBar, TabType } from './components/BottomTabBar';
import { QuickCreateSheet } from './components/QuickCreateSheet';
import { TodayScreen } from './features/dashboard/TodayScreen';
import { AgendaScreen } from './features/agenda/AgendaScreen';
import { TasksScreen } from './features/tasks/TasksScreen';
import { TaskDetailModal } from './features/tasks/TaskDetailModal';
import { BureauScreen } from './features/secretary/BureauScreen';
import { PrayersScreen } from './features/prayers/PrayersScreen';
import { FocusModeModal } from './features/focus/FocusModeModal';
import { LifestyleScreen } from './features/lifestyle/LifestyleScreen';
import { MealsScreen } from './features/meals/MealsScreen';
import { WorkoutsScreen } from './features/workouts/WorkoutsScreen';
import { ReportsScreen } from './features/reports/ReportsScreen';
import { NotificationsScreen } from './features/notifications/NotificationsScreen';
import { SettingsScreen } from './features/settings/SettingsScreen';
import { ReorganizeDayModal } from './features/agenda/ReorganizeDayModal';
import { PeriodsAndRoutinesModal } from './features/agenda/PeriodsAndRoutinesModal';
import { AcceptanceTestsModal } from './features/testing/AcceptanceTestsModal';
import { OnboardingModal } from './features/onboarding/OnboardingModal';
import { EmergencyRescheduleModal } from './features/dashboard/EmergencyRescheduleModal';
import { InstallAppModal } from './components/InstallAppModal';
import { db } from './services/storage/database';
import { ScheduledSession, Task } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('today');
  const [activeSubScreen, setActiveSubScreen] = useState<
    'NONE' | 'PRAYERS' | 'LIFESTYLE' | 'MEALS' | 'WORKOUTS' | 'REPORTS' | 'NOTIFICATIONS' | 'SETTINGS'
  >('NONE');

  // Modals
  const [isQuickCreateOpen, setIsQuickCreateOpen] = useState(false);
  const [isReorganizeOpen, setIsReorganizeOpen] = useState(false);
  const [isPeriodsOpen, setIsPeriodsOpen] = useState(false);
  const [isTestsOpen, setIsTestsOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [focusSession, setFocusSession] = useState<ScheduledSession | null>(null);
  const [focusTask, setFocusTask] = useState<Task | null>(null);

  // Trigger state refresh
  const [dataVersion, setDataVersion] = useState(0);
  const handleDataChanged = () => setDataVersion((v) => v + 1);

  const settings = db.getSettings();
  const unreadNotifs = db.getNotifications().filter((n) => n.status !== 'DISMISSED').length;

  const handleToggleDarkMode = () => {
    settings.isDarkMode = !settings.isDarkMode;
    db.updateSettings(settings);
    handleDataChanged();
  };

  return (
    <AndroidFrame
      isDarkMode={!!settings.isDarkMode}
      onOpenNotifications={() => setActiveSubScreen('NOTIFICATIONS')}
      onOpenSettings={() => setActiveSubScreen('SETTINGS')}
    >
      {/* Top Header */}
      <Header
        operatingMode={settings.operatingMode}
        unreadNotifsCount={unreadNotifs}
        isDarkMode={!!settings.isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
        onOpenNotifications={() => setActiveSubScreen('NOTIFICATIONS')}
        onOpenSettings={() => setActiveSubScreen('SETTINGS')}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onOpenFocusMode={() => {
          const firstTask = db.getTasks().find((t) => t.status !== 'COMPLETED');
          setFocusTask(firstTask || null);
        }}
      />

      {/* Main View Area */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {activeSubScreen === 'PRAYERS' && (
          <PrayersScreen
            settings={settings}
            onBack={() => setActiveSubScreen('NONE')}
            onDataChanged={handleDataChanged}
          />
        )}

        {activeSubScreen === 'LIFESTYLE' && (
          <LifestyleScreen
            settings={settings}
            onBack={() => setActiveSubScreen('NONE')}
            onDataChanged={handleDataChanged}
          />
        )}

        {activeSubScreen === 'MEALS' && (
          <MealsScreen
            onBack={() => setActiveSubScreen('NONE')}
            onDataChanged={handleDataChanged}
          />
        )}

        {activeSubScreen === 'WORKOUTS' && (
          <WorkoutsScreen
            onBack={() => setActiveSubScreen('NONE')}
            onDataChanged={handleDataChanged}
          />
        )}

        {activeSubScreen === 'REPORTS' && (
          <ReportsScreen onBack={() => setActiveSubScreen('NONE')} />
        )}

        {activeSubScreen === 'NOTIFICATIONS' && (
          <NotificationsScreen
            onBack={() => setActiveSubScreen('NONE')}
            onDataChanged={handleDataChanged}
          />
        )}

        {activeSubScreen === 'SETTINGS' && (
          <SettingsScreen
            settings={settings}
            onBack={() => setActiveSubScreen('NONE')}
            onDataChanged={handleDataChanged}
            onOpenTests={() => setIsTestsOpen(true)}
            onOpenOnboarding={() => setIsOnboardingOpen(true)}
            onOpenInstallModal={() => setIsInstallModalOpen(true)}
          />
        )}

        {activeSubScreen === 'NONE' && (
          <>
            {activeTab === 'today' && (
              <TodayScreen
                key={`today-${dataVersion}`}
                settings={settings}
                onOpenTaskDetail={(tId) => setSelectedTaskId(tId)}
                onStartFocus={(sess) => setFocusSession(sess)}
                onOpenReorganize={() => setIsReorganizeOpen(true)}
                onOpenPrayers={() => setActiveSubScreen('PRAYERS')}
                onOpenEmergency={() => setIsEmergencyOpen(true)}
                onDataChanged={handleDataChanged}
              />
            )}

            {activeTab === 'agenda' && (
              <AgendaScreen
                key={`agenda-${dataVersion}`}
                settings={settings}
                onOpenTaskDetail={(tId) => setSelectedTaskId(tId)}
                onOpenPeriods={() => setIsPeriodsOpen(true)}
                onOpenRoutines={() => setIsPeriodsOpen(true)}
                onOpenQuickCreate={() => setIsQuickCreateOpen(true)}
              />
            )}

            {activeTab === 'tasks' && (
              <TasksScreen
                key={`tasks-${dataVersion}`}
                onOpenTaskDetail={(tId) => setSelectedTaskId(tId)}
                onOpenQuickCreate={() => setIsQuickCreateOpen(true)}
                onDataChanged={handleDataChanged}
              />
            )}

            {activeTab === 'office' && (
              <BureauScreen
                key={`bureau-${dataVersion}`}
                settings={settings}
                onOpenLifestyle={() => setActiveSubScreen('LIFESTYLE')}
                onOpenMeals={() => setActiveSubScreen('MEALS')}
                onOpenWorkouts={() => setActiveSubScreen('WORKOUTS')}
                onOpenReports={() => setActiveSubScreen('REPORTS')}
                onDataChanged={handleDataChanged}
              />
            )}
          </>
        )}
      </div>

      {/* Bottom Tab Bar (shown when no subscreen is fullscreen) */}
      {activeSubScreen === 'NONE' && (
        <BottomTabBar
          activeTab={activeTab}
          onSelectTab={(t) => setActiveTab(t)}
          onOpenQuickCreate={() => setIsQuickCreateOpen(true)}
          isDarkMode={!!settings.isDarkMode}
        />
      )}

      {/* Quick Create Bottom Sheet */}
      <QuickCreateSheet
        isOpen={isQuickCreateOpen}
        onClose={() => setIsQuickCreateOpen(false)}
        onItemCreated={handleDataChanged}
      />

      {/* Task Detail Modal */}
      {selectedTaskId && (
        <TaskDetailModal
          taskId={selectedTaskId}
          onClose={() => setSelectedTaskId(null)}
          onDataChanged={handleDataChanged}
          onStartFocus={(t) => {
            setFocusTask(t);
            setSelectedTaskId(null);
          }}
        />
      )}

      {/* Focus Mode Overlay */}
      {(focusSession || focusTask) && (
        <FocusModeModal
          session={focusSession}
          task={focusTask}
          onClose={() => {
            setFocusSession(null);
            setFocusTask(null);
          }}
          onDataChanged={handleDataChanged}
        />
      )}

      {/* Reorganize Day Modal */}
      {isReorganizeOpen && (
        <ReorganizeDayModal
          settings={settings}
          onClose={() => setIsReorganizeOpen(false)}
          onDataChanged={handleDataChanged}
        />
      )}

      {/* Periods & Routines Modal */}
      {isPeriodsOpen && (
        <PeriodsAndRoutinesModal
          onClose={() => setIsPeriodsOpen(false)}
          onDataChanged={handleDataChanged}
        />
      )}

      {/* Acceptance Tests Modal (Section 34) */}
      {isTestsOpen && (
        <AcceptanceTestsModal onClose={() => setIsTestsOpen(false)} />
      )}

      {/* Emergency Reschedule Modal (Section 22) */}
      {isEmergencyOpen && (
        <EmergencyRescheduleModal
          onClose={() => setIsEmergencyOpen(false)}
          onDataChanged={handleDataChanged}
        />
      )}

      {/* Onboarding Wizard (Section 33) */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onDataChanged={handleDataChanged}
      />

      {/* APK & Phone Install Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </AndroidFrame>
  );
}
