import React, { useState, useEffect } from 'react';
import { Wifi, Battery, Smartphone, Maximize2, Minimize2, Bell, Check, Clock, ExternalLink } from 'lucide-react';
import { NotificationRecord } from '../types';
import { db } from '../services/storage/database';
import { ToastContainer } from './ToastContainer';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeScreenTitle?: string;
  onOpenNotifications?: () => void;
  onOpenSettings?: () => void;
  isDarkMode?: boolean;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  activeScreenTitle,
  onOpenNotifications,
  onOpenSettings,
  isDarkMode = false
}) => {
  const [currentTime, setCurrentTime] = useState('12:20');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showLockScreen, setShowLockScreen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Africa/Casablanca time
      const timeStr = now.toLocaleTimeString('fr-FR', {
        timeZone: 'Africa/Casablanca',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
      setCurrentTime(timeStr);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  const refreshNotifs = () => {
    setNotifications(db.getNotifications().filter(n => n.status !== 'DISMISSED'));
  };

  useEffect(() => {
    refreshNotifs();
  }, [showLockScreen]);

  const handleAction = (notifId: string, action: 'COMPLETED' | 'SNOOZED_15' | 'OPENED') => {
    db.dismissNotification(notifId);
    refreshNotifs();
    if (action === 'OPENED') {
      setShowLockScreen(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-start p-2 sm:p-4 md:p-6 font-sans">
      {/* Top Device Bar (Simulate Android Device controls) */}
      <div className="w-full max-w-5xl flex items-center justify-between mb-3 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-200">NORA — Émulation Android</span>
          <span className="hidden sm:inline text-slate-500">·</span>
          <span className="hidden sm:inline bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[11px]">
            Package: com.nora.personalsecretary
          </span>
          <span className="hidden md:inline text-emerald-400">● Rabat (UTC+1)</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowLockScreen(!showLockScreen)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Tester les notifications sur écran verrouillé"
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline text-[11px] font-medium">Écran verrouillé Android</span>
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Basculer format téléphone / plein écran"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="text-[11px] font-medium">{isFullscreen ? 'Cadre mobile' : 'Plein écran'}</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div
        className={`w-full transition-all duration-300 ${
          isFullscreen
            ? 'max-w-4xl h-[92vh] rounded-2xl shadow-2xl border border-slate-700 overflow-hidden'
            : 'max-w-[420px] h-[860px] rounded-[44px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] border-[10px] border-slate-800 ring-1 ring-slate-700/60 overflow-hidden relative'
        } ${isDarkMode ? 'bg-slate-950 text-slate-100 dark' : 'bg-[#F8FAFC] text-[#0F172A]'} flex flex-col`}
      >
        {/* Android Native Status Bar */}
        <div className="w-full h-8 bg-[#172B4D] text-slate-200 px-5 flex items-center justify-between text-xs select-none z-50 shrink-0">
          <div className="flex items-center gap-1.5 font-medium tracking-tight">
            <span>{currentTime}</span>
            <span className="text-[10px] text-teal-300 ml-1">Rabat</span>
          </div>

          {/* Notch / Punch hole camera simulation */}
          {!isFullscreen && (
            <div className="w-4 h-4 rounded-full bg-black border border-slate-800 shrink-0" />
          )}

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-300 font-mono">5G</span>
            <Wifi className="w-3.5 h-3.5 text-slate-200" />
            <div className="flex items-center gap-1">
              <span className="text-[10px] font-mono">94%</span>
              <Battery className="w-4 h-4 text-emerald-400 rotate-90" />
            </div>
          </div>
        </div>

        {/* Lock Screen Simulator Overlay */}
        {showLockScreen && (
          <div className="absolute inset-0 bg-slate-950/95 text-white z-50 flex flex-col p-6 animate-fadeIn">
            <div className="flex justify-between items-center text-xs text-slate-400 mb-6">
              <span>Maroc Telecom · 5G</span>
              <button
                onClick={() => setShowLockScreen(false)}
                className="text-xs text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-full font-medium"
              >
                Déverrouiller
              </button>
            </div>

            <div className="text-center my-6">
              <div className="text-5xl font-light tracking-tight">{currentTime}</div>
              <div className="text-sm text-slate-300 mt-1 capitalize">
                Mardi 13 octobre · Rabat
              </div>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 mt-4">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                <span>Notifications NORA sur écran verrouillé</span>
                <span className="text-[11px] font-normal text-emerald-400">Canaux officiels</span>
              </div>

              {notifications.length === 0 ? (
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-center text-xs text-slate-400">
                  Aucune notification en attente.
                </div>
              ) : (
                notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800/80 shadow-lg text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <div className="w-4 h-4 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center text-[9px] font-bold">
                          N
                        </div>
                        <span className="font-semibold text-slate-300">NORA</span>
                        <span className="text-[10px] text-slate-500">· il y a 2m</span>
                      </div>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 uppercase">
                        {notif.channelId}
                      </span>
                    </div>

                    <div className="font-medium text-slate-100 text-sm">{notif.title}</div>
                    <div className="text-slate-300 text-xs leading-relaxed">{notif.body}</div>

                    {/* Android Native Action Buttons */}
                    <div className="pt-2 flex items-center gap-2 border-t border-slate-800/60">
                      <button
                        onClick={() => handleAction(notif.id, 'COMPLETED')}
                        className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 font-semibold text-[11px] transition-colors"
                      >
                        <Check className="w-3 h-3" />
                        TERMINÉ
                      </button>
                      <button
                        onClick={() => handleAction(notif.id, 'SNOOZED_15')}
                        className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-[11px] transition-colors"
                      >
                        <Clock className="w-3 h-3" />
                        +15 MIN
                      </button>
                      <button
                        onClick={() => handleAction(notif.id, 'OPENED')}
                        className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-medium text-[11px] transition-colors"
                      >
                        OUVRIR
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="text-center text-[11px] text-slate-500 pt-3">
              Glissez vers le haut ou appuyez sur Déverrouiller pour accéder à NORA
            </div>
          </div>
        )}

        {/* Content Area */}
        <div className={`flex-1 overflow-hidden flex flex-col relative ${isDarkMode ? 'bg-slate-950' : 'bg-[#F8FAFC]'}`}>
          {children}
          <ToastContainer />
        </div>

        {/* Android Bottom Gesture Bar */}
        {!isFullscreen && (
          <div className={`w-full h-4 ${isDarkMode ? 'bg-slate-950' : 'bg-white'} flex items-center justify-center shrink-0`}>
            <div className={`w-28 h-1 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-300'} rounded-full`} />
          </div>
        )}
      </div>
    </div>
  );
};
