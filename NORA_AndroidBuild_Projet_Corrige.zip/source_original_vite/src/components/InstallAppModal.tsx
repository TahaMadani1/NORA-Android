import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Download, 
  QrCode, 
  Copy, 
  Check, 
  Terminal, 
  ShieldCheck, 
  ExternalLink, 
  X, 
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import { toastService } from '../services/feedback/toastService';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk'>('pwa');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentUrl(window.location.href);

      const handleBeforeInstall = (e: any) => {
        e.preventDefault();
        setDeferredPrompt(e);
      };

      window.addEventListener('beforeinstallprompt', handleBeforeInstall);
      return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      };
    }
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        toastService.success('Installation lancée avec succès sur votre téléphone !');
      }
      setDeferredPrompt(null);
    } else {
      toastService.info(
        'Sur votre téléphone Android, ouvrez le menu Chrome (⋮) puis cliquez sur « Installer l\'application »'
      );
    }
  };

  const handleCopyUrl = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(currentUrl || window.location.href);
      setIsCopied(true);
      toastService.success('Lien copié dans le presse-papiers !');
      setTimeout(() => setIsCopied(false), 2500);
    }
  };

  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
    currentUrl || 'https://nora-app.internal'
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md max-h-[92vh] flex flex-col overflow-hidden text-slate-800">
        
        {/* Header */}
        <div className="bg-[#172B4D] text-white px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white">Installer sur mon Téléphone</h2>
              <p className="text-[11px] text-teal-200">Application Android autonome · Zéro latence</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex border-b border-slate-100 bg-slate-50 p-1.5 gap-1.5">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'pwa'
                ? 'bg-white text-teal-800 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            <span>1. Installation Directe (Recommandé)</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'apk'
                ? 'bg-white text-teal-800 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Download className="w-3.5 h-3.5 text-teal-600" />
            <span>2. Fichier APK Brut (.apk)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {activeTab === 'pwa' ? (
            <div className="space-y-4">
              {/* Highlight badge */}
              <div className="p-3 bg-teal-50 border border-teal-200 rounded-2xl flex items-start gap-2.5">
                <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                <div className="text-[11px] text-teal-900 leading-relaxed">
                  <strong>Installation native instantanée sur Android :</strong> Pas besoin d'attendre une compilation complexe. NORA s'installe sur votre écran d'accueil avec son icône, s'ouvre en plein écran sans barre d'adresse, et fonctionne 100% hors-ligne.
                </div>
              </div>

              {/* Install Button if prompted */}
              {deferredPrompt && (
                <button
                  onClick={handleInstallClick}
                  className="w-full py-3 px-4 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-2xl shadow-md flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
                >
                  <Download className="w-4 h-4" />
                  <span>Installer maintenant sur ce téléphone</span>
                </button>
              )}

              {/* QR Code and Mobile Link */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-center space-y-3">
                <span className="font-bold text-slate-800 text-xs block">
                  Scannez avec l'appareil photo de votre téléphone
                </span>
                <div className="flex justify-center">
                  <div className="p-2 bg-white rounded-xl shadow-xs border border-slate-200 inline-block">
                    <img 
                      src={qrCodeUrl} 
                      alt="QR Code pour installer sur téléphone" 
                      className="w-36 h-36 mx-auto rounded-lg"
                      onError={(e) => {
                        // Fallback if network blocked
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-1.5 justify-center">
                  <button
                    onClick={handleCopyUrl}
                    className="py-1.5 px-3 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold rounded-lg flex items-center gap-1.5 text-[11px] shadow-xs"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? 'Lien copié !' : 'Copier le lien direct'}</span>
                  </button>
                </div>
              </div>

              {/* Steps for Android Chrome */}
              <div className="space-y-2">
                <span className="font-bold text-slate-800 block">
                  Comment installer depuis Google Chrome sur Android :
                </span>
                <ol className="space-y-2 list-decimal list-inside text-slate-600 text-[11px] leading-relaxed">
                  <li className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    Ouvrez le lien ci-dessus sur <strong>Google Chrome</strong> de votre smartphone.
                  </li>
                  <li className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    Appuyez sur les <strong>trois petits points (⋮)</strong> en haut à droite du navigateur.
                  </li>
                  <li className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    Appuyez sur <strong>« Installer l'application »</strong> (ou <em>« Ajouter à l'écran d'accueil »</em>).
                  </li>
                  <li className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    Confirmez : l'icône NORA apparaît sur votre écran d'accueil comme toute application du Play Store !
                  </li>
                </ol>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* APK section */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-2.5">
                <Terminal className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div className="text-[11px] text-amber-900 leading-relaxed">
                  <strong>Configuration EAS Build (Expo Android) prête :</strong> Les fichiers <code>app.json</code> et <code>eas.json</code> sont déjà configurés avec l'identifiant <code>com.nora.personalsecretary</code> et le profil <strong>preview APK</strong>.
                </div>
              </div>

              <div className="space-y-2">
                <span className="font-bold text-slate-800 block">
                  Commande de compilation directe du fichier .APK :
                </span>
                <div className="p-3 bg-slate-900 rounded-xl font-mono text-[11px] text-teal-300 border border-slate-800 flex items-center justify-between">
                  <code>npx eas build -p android --profile preview</code>
                  <button
                    onClick={() => {
                      if (navigator.clipboard) {
                        navigator.clipboard.writeText('npx eas build -p android --profile preview');
                        toastService.success('Commande copiée !');
                      }
                    }}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                    title="Copier la commande"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-[10px] text-slate-500">
                  Cette commande génère automatiquement un lien de téléchargement direct du fichier <code>.apk</code> à transférer sur votre smartphone.
                </p>
              </div>

              <div className="space-y-2">
                <span className="font-bold text-slate-800 block">
                  Installation du fichier .APK sur votre smartphone Android :
                </span>
                <div className="space-y-1.5 text-[11px] text-slate-600">
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <strong>1. Télécharger :</strong> Ouvrez le fichier .apk téléchargé sur votre téléphone Android.
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <strong>2. Autoriser :</strong> Si Android affiche un avertissement, allez dans <em>Paramètres &gt; Sécurité</em> et activez <em>« Autoriser cette source »</em> ou <em>« Sources inconnues »</em>.
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                    <strong>3. Terminer :</strong> Cliquez sur <em>Installer</em>. NORA s'installe avec les permissions d'alarmes exactes et de notifications locales.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[10px] text-slate-500">
            NORA v1.0.0 · Local-First · Rabat/Salé
          </span>
          <button
            onClick={onClose}
            className="py-1.5 px-4 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition-colors"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
