import React, { useEffect, useState } from 'react';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';
import { toastService, ToastMessage } from '../services/feedback/toastService';

export const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    const unsubscribe = toastService.subscribe((list) => {
      setToasts(list);
    });
    return () => unsubscribe();
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div className="absolute bottom-16 left-0 right-0 z-[100] px-4 pointer-events-none flex flex-col items-center gap-2">
      {toasts.map((toast) => {
        let bgStyle = 'bg-slate-900 text-white border-slate-700';
        let IconComponent = Info;
        let iconColor = 'text-blue-400';

        if (toast.type === 'success') {
          bgStyle = 'bg-[#064E3B] text-emerald-50 border-emerald-600/50 shadow-emerald-950/40';
          IconComponent = CheckCircle2;
          iconColor = 'text-emerald-300';
        } else if (toast.type === 'warning') {
          bgStyle = 'bg-[#78350F] text-amber-50 border-amber-600/50 shadow-amber-950/40';
          IconComponent = AlertTriangle;
          iconColor = 'text-amber-300';
        } else if (toast.type === 'error') {
          bgStyle = 'bg-[#7F1D1D] text-rose-50 border-rose-600/50 shadow-rose-950/40';
          IconComponent = AlertCircle;
          iconColor = 'text-rose-300';
        } else {
          bgStyle = 'bg-[#0F172A] text-slate-100 border-slate-700/60 shadow-slate-950/50';
          IconComponent = Info;
          iconColor = 'text-sky-300';
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl border shadow-xl text-xs backdrop-blur-md max-w-sm w-full animate-bounce-short transition-all ${bgStyle}`}
          >
            <IconComponent className={`w-4 h-4 shrink-0 ${iconColor}`} />
            <span className="flex-1 font-medium leading-tight text-[11px]">{toast.message}</span>
            <button
              onClick={() => toastService.dismiss(toast.id)}
              className="p-1 rounded-lg hover:bg-white/10 text-white/70 hover:text-white transition-colors shrink-0"
              aria-label="Fermer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
