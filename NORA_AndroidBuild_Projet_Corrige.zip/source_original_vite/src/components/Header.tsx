import React from 'react';
import { Bell, Settings, Moon, Sun, Sparkles, Activity, Smartphone } from 'lucide-react';
import { OperatingMode } from '../types';

interface HeaderProps {
  title?: string;
  operatingMode: OperatingMode;
  unreadNotifsCount: number;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
  onOpenFocusMode?: () => void;
  onOpenInstallModal?: () => void;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  operatingMode,
  unreadNotifsCount,
  onOpenNotifications,
  onOpenSettings,
  onOpenFocusMode,
  onOpenInstallModal,
  isDarkMode,
  onToggleDarkMode
}) => {
  const getModeLabel = (mode: OperatingMode) => {
    switch (mode) {
      case 'NORMAL':
        return 'Normal';
      case 'HEAVY_WEEK':
        return 'Semaine chargée';
      case 'RECOVERY':
        return 'Récupération';
      case 'VACATION':
        return 'Vacances';
    }
  };

  return (
    <header className="w-full bg-[#172B4D] text-white px-4 py-3 flex items-center justify-between shadow-sm z-30 shrink-0">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center font-bold text-teal-300 text-sm tracking-wider shadow-inner">
          N
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-base tracking-tight text-white">NORA</span>
            <span className="text-[10px] text-teal-300 font-medium bg-teal-950/60 px-1.5 py-0.5 rounded border border-teal-800">
              {getModeLabel(operatingMode)}
            </span>
          </div>
          <p className="text-[10px] text-slate-300 leading-none mt-0.5">
            Ton temps · Tes priorités · Ton équilibre
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1">
        {onOpenInstallModal && (
          <button
            onClick={onOpenInstallModal}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-teal-300 hover:text-white transition-colors"
            title="Installer sur mon téléphone / Télécharger APK"
            aria-label="Installer l'application"
          >
            <Smartphone className="w-4 h-4" />
          </button>
        )}

        {onOpenFocusMode && (
          <button
            onClick={onOpenFocusMode}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-teal-300 hover:text-white transition-colors"
            title="Lancer une session Focus (50 min)"
            aria-label="Mode Focus"
          >
            <Activity className="w-4 h-4" />
          </button>
        )}

        <button
          onClick={onOpenNotifications}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center relative text-slate-300 hover:text-white transition-colors"
          title="Notifications & Diagnostic"
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadNotifsCount > 0 && (
            <span className="absolute top-2.5 right-2.5 w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>

        {onToggleDarkMode && (
          <button
            onClick={onToggleDarkMode}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title={isDarkMode ? 'Passer au mode clair' : 'Passer au mode sombre'}
            aria-label="Basculer thème"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-slate-300" />}
          </button>
        )}

        <button
          onClick={onOpenSettings}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          title="Paramètres & Sauvegardes"
          aria-label="Paramètres"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
