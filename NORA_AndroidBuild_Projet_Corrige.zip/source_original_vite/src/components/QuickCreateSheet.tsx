import React, { useState } from 'react';
import { X, Sparkles, Clock, Calendar, Flag, BookOpen, MapPin, Tag, Check } from 'lucide-react';
import { PriorityLevel, TaskCategory, ConstraintLevel } from '../types';
import { CATEGORY_THEMES, PRIORITY_THEMES } from '../theme/colors';
import { parseNaturalLanguageTask } from '../services/scheduling/schedulingEngine';
import { db } from '../services/storage/database';

interface QuickCreateSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onItemCreated: () => void;
}

type CreateMode = 'TASK' | 'EVENT' | 'ROUTINE' | 'PROJECT';

export const QuickCreateSheet: React.FC<QuickCreateSheetProps> = ({
  isOpen,
  onClose,
  onItemCreated
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<CreateMode>('TASK');
  const [nlInput, setNlInput] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<TaskCategory>('STUDIES');
  const [priority, setPriority] = useState<PriorityLevel>('P3');
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [date, setDate] = useState('2026-10-13');
  const [startTime, setStartTime] = useState('14:00');
  const [endTime, setEndTime] = useState('15:00');
  const [location, setLocation] = useState('');
  const [isFixed, setIsFixed] = useState(false);
  const [selectedDays, setSelectedDays] = useState<number[]>([1]); // Lundi

  const handleNlParse = () => {
    if (!nlInput.trim()) return;
    const res = parseNaturalLanguageTask(nlInput);
    setTitle(res.title);
    setCategory(res.category);
    setPriority(res.priority);
    setDurationMinutes(res.estimatedMinutes);
    if (res.deadline) {
      setDate(res.deadline.split('T')[0]);
    }
    if (res.isRecurring) {
      setMode('ROUTINE');
      if (res.recurrenceDays && res.recurrenceDays.length > 0) {
        setSelectedDays(res.recurrenceDays);
      }
      if (res.recurrenceStartTime) setStartTime(res.recurrenceStartTime);
      if (res.recurrenceEndTime) setEndTime(res.recurrenceEndTime);
    }
  };

  const handleSave = () => {
    if (!title.trim()) return;

    if (mode === 'TASK') {
      db.saveTask({
        id: 'task-' + Date.now(),
        title: title.trim(),
        description: description.trim() || undefined,
        category,
        priority,
        constraintLevel: isFixed ? 'LEVEL_1' : 'LEVEL_3',
        status: 'UNCOMPLETED',
        totalEstimatedMinutes: durationMinutes,
        remainingMinutes: durationMinutes,
        energyLevel: 3,
        isFixed,
        schedulingPreference: 'BEFORE_DEADLINE',
        deadline: date ? `${date}T18:00` : undefined,
        location: location.trim() || undefined,
        postponementCount: 0,
        subtasks: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      // Also create an initial session for today or selected date
      db.saveSession({
        id: 'sess-' + Date.now(),
        taskId: 'task-' + Date.now(),
        title: title.trim(),
        category,
        priority,
        constraintLevel: isFixed ? 'LEVEL_1' : 'LEVEL_3',
        date,
        startTime,
        endTime,
        status: 'SCHEDULED',
        isLocked: isFixed,
        location: location.trim() || undefined
      });
    } else if (mode === 'EVENT') {
      db.saveSession({
        id: 'sess-' + Date.now(),
        title: title.trim(),
        category,
        priority,
        constraintLevel: 'LEVEL_1', // Fixed commitments
        date,
        startTime,
        endTime,
        status: 'SCHEDULED',
        isLocked: true,
        location: location.trim() || undefined
      });
    } else if (mode === 'ROUTINE') {
      db.saveRecurringRule({
        id: 'rec-' + Date.now(),
        title: title.trim(),
        category,
        priority,
        constraintLevel: isFixed ? 'LEVEL_1' : 'LEVEL_2',
        frequency: 'WEEKLY',
        daysOfWeek: selectedDays,
        startTime,
        endTime,
        startDate: date,
        location: location.trim() || undefined
      });
    } else if (mode === 'PROJECT') {
      db.saveProject({
        id: 'proj-' + Date.now(),
        title: title.trim(),
        objective: description.trim() || title.trim(),
        category,
        deadline: date,
        progressPercentage: 0,
        milestones: [],
        createdAt: new Date().toISOString().split('T')[0]
      });
    }

    onItemCreated();
    onClose();
  };

  const dayNames = [
    { num: 1, label: 'Lun' },
    { num: 2, label: 'Mar' },
    { num: 3, label: 'Mer' },
    { num: 4, label: 'Jeu' },
    { num: 5, label: 'Ven' },
    { num: 6, label: 'Sam' },
    { num: 0, label: 'Dim' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col justify-end">
      <div className="w-full max-h-[85vh] bg-white rounded-t-3xl flex flex-col overflow-hidden animate-slideUp shadow-2xl">
        {/* Grab Handle */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto my-2.5 shrink-0" />

        {/* Header */}
        <div className="px-5 pb-3 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-[#172B4D] text-base">Ajout rapide</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center gap-1.5 px-5 py-2.5 bg-slate-50 border-b border-slate-100 overflow-x-auto">
          {[
            { id: 'TASK', label: 'Tâche' },
            { id: 'EVENT', label: 'Cours / Événement' },
            { id: 'ROUTINE', label: 'Routine hebdo' },
            { id: 'PROJECT', label: 'Projet' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setMode(item.id as CreateMode)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                mode === item.id
                  ? 'bg-[#172B4D] text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Body Form */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Natural Language Assistant Bar */}
          <div className="bg-teal-50 border border-teal-200 rounded-xl p-3 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-teal-900">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>Commande en langage naturel (français)</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={nlInput}
                onChange={(e) => setNlInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleNlParse()}
                placeholder="Ex : Réviser le TD pendant 2h avant vendredi..."
                className="flex-1 bg-white border border-teal-300 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <button
                type="button"
                onClick={handleNlParse}
                className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-medium shrink-0"
              >
                Extraire
              </button>
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Titre <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex : Préparation de l'examen de génie logiciel"
              className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#172B4D]"
            />
          </div>

          {/* Category & Priority Row */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Catégorie</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as TaskCategory)}
                className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#172B4D]"
              >
                {Object.entries(CATEGORY_THEMES).map(([catKey, val]) => (
                  <option key={catKey} value={catKey}>
                    {val.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Priorité</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#172B4D]"
              >
                {Object.entries(PRIORITY_THEMES).map(([pKey, val]) => (
                  <option key={pKey} value={pKey}>
                    {val.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Time & Duration based on mode */}
          {mode === 'TASK' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Durée estimée (minutes)
                </label>
                <input
                  type="number"
                  step="15"
                  min="15"
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(parseInt(e.target.value, 10) || 60)}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Date cible</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
                />
              </div>
            </div>
          )}

          {(mode === 'EVENT' || mode === 'ROUTINE') && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Heure début</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Heure fin</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
                  />
                </div>
              </div>

              {mode === 'ROUTINE' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Jours de la semaine
                  </label>
                  <div className="flex items-center gap-1.5">
                    {dayNames.map((d) => {
                      const isSel = selectedDays.includes(d.num);
                      return (
                        <button
                          key={d.num}
                          type="button"
                          onClick={() => {
                            if (isSel) {
                              setSelectedDays(selectedDays.filter((x) => x !== d.num));
                            } else {
                              setSelectedDays([...selectedDays, d.num]);
                            }
                          }}
                          className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                            isSel
                              ? 'bg-[#172B4D] text-white'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          {d.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Location */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Lieu / Salle (optionnel)
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Ex : Amphi Ibn Rochd, Rabat / Bibliothèque"
              className="w-full border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800"
            />
          </div>

          {/* Fixed / Protected Toggle */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="fixedToggle"
              checked={isFixed}
              onChange={(e) => setIsFixed(e.target.checked)}
              className="w-4 h-4 text-[#172B4D] rounded"
            />
            <label htmlFor="fixedToggle" className="text-xs text-slate-700 font-medium">
              Créneau verrouillé (Ne jamais déplacer automatiquement)
            </label>
          </div>
        </div>

        {/* Footer CTAs */}
        <div className="p-4 border-t border-slate-100 flex items-center gap-3 bg-white">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-3 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!title.trim()}
            className="flex-1 py-3 rounded-xl bg-[#172B4D] text-white text-xs font-semibold hover:bg-slate-800 disabled:opacity-50 transition-colors shadow-md shadow-slate-900/10"
          >
            Enregistrer
          </button>
        </div>
      </div>
    </div>
  );
};
