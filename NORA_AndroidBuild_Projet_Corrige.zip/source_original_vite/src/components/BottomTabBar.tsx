import React from 'react';
import { Calendar, CalendarDays, CheckSquare, Briefcase, Plus } from 'lucide-react';

export type TabType = 'today' | 'agenda' | 'tasks' | 'office';

interface BottomTabBarProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenQuickCreate: () => void;
  isDarkMode?: boolean;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({
  activeTab,
  onSelectTab,
  onOpenQuickCreate,
  isDarkMode = false
}) => {
  const activeColor = isDarkMode ? 'text-teal-400' : 'text-[#172B4D]';
  const inactiveColor = isDarkMode ? 'text-slate-500 hover:text-slate-300' : 'text-slate-400 hover:text-slate-600';

  return (
    <nav className={`w-full h-16 ${
      isDarkMode ? 'bg-slate-900 border-t border-slate-800' : 'bg-white border-t border-slate-200'
    } px-3 flex items-center justify-around z-40 shrink-0 shadow-[0_-4px_12px_rgba(0,0,0,0.03)]`}>
      {/* Tab 1: Aujourd'hui */}
      <button
        onClick={() => onSelectTab('today')}
        className={`flex-1 min-h-[44px] flex flex-col items-center justify-center transition-colors ${
          activeTab === 'today' ? activeColor : inactiveColor
        }`}
        aria-label="Aujourd'hui"
      >
        <Calendar className={`w-5 h-5 ${activeTab === 'today' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className={`text-[11px] mt-1 ${activeTab === 'today' ? 'font-bold' : 'font-medium'}`}>
          Aujourd'hui
        </span>
      </button>

      {/* Tab 2: Agenda */}
      <button
        onClick={() => onSelectTab('agenda')}
        className={`flex-1 min-h-[44px] flex flex-col items-center justify-center transition-colors ${
          activeTab === 'agenda' ? activeColor : inactiveColor
        }`}
        aria-label="Agenda"
      >
        <CalendarDays className={`w-5 h-5 ${activeTab === 'agenda' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className={`text-[11px] mt-1 ${activeTab === 'agenda' ? 'font-bold' : 'font-medium'}`}>
          Agenda
        </span>
      </button>

      {/* Center Action: + Quick Create */}
      <div className="flex-1 flex items-center justify-center -mt-5">
        <button
          onClick={onOpenQuickCreate}
          className="w-12 h-12 rounded-full bg-[#172B4D] text-white flex items-center justify-center shadow-lg shadow-slate-900/25 hover:bg-slate-800 active:scale-95 transition-all border-2 border-white ring-2 ring-teal-500/20"
          title="Ajouter une tâche, un cours ou un projet"
          aria-label="Création rapide"
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
        </button>
      </div>

      {/* Tab 3: Tâches */}
      <button
        onClick={() => onSelectTab('tasks')}
        className={`flex-1 min-h-[44px] flex flex-col items-center justify-center transition-colors ${
          activeTab === 'tasks' ? activeColor : inactiveColor
        }`}
        aria-label="Tâches"
      >
        <CheckSquare className={`w-5 h-5 ${activeTab === 'tasks' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className={`text-[11px] mt-1 ${activeTab === 'tasks' ? 'font-bold' : 'font-medium'}`}>
          Tâches
        </span>
      </button>

      {/* Tab 4: Bureau */}
      <button
        onClick={() => onSelectTab('office')}
        className={`flex-1 min-h-[44px] flex flex-col items-center justify-center transition-colors ${
          activeTab === 'office' ? activeColor : inactiveColor
        }`}
        aria-label="Bureau"
      >
        <Briefcase className={`w-5 h-5 ${activeTab === 'office' ? 'stroke-[2.5]' : 'stroke-2'}`} />
        <span className={`text-[11px] mt-1 ${activeTab === 'office' ? 'font-bold' : 'font-medium'}`}>
          Bureau
        </span>
      </button>
    </nav>
  );
};
