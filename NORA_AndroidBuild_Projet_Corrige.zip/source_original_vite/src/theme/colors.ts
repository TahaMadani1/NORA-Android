import { PriorityLevel, TaskCategory, TaskStatus } from '../types';

export const COLORS = {
  primaryNavy: '#172B4D',
  background: '#F8FAFC',
  text: '#0F172A',
  secondaryText: '#64748B',
  surface: '#FFFFFF',
  surfaceBorder: '#E2E8F0',
  accentEmerald: '#0D9488', // Prières protégées
};

export const CATEGORY_THEMES: Record<TaskCategory, { label: string; color: string; bgLight: string; border: string }> = {
  STUDIES: {
    label: 'Études & Cours',
    color: '#3B82F6',
    bgLight: '#EFF6FF',
    border: '#BFDBFE'
  },
  WORK: {
    label: 'Projets pro',
    color: '#8B5CF6',
    bgLight: '#F5F3FF',
    border: '#DDD6FE'
  },
  ASSOCIATION: {
    label: 'Clubs & Assos',
    color: '#F59E0B',
    bgLight: '#FEF3C7',
    border: '#FDE68A'
  },
  PERSONAL: {
    label: 'Vie personnelle',
    color: '#10B981',
    bgLight: '#ECFDF5',
    border: '#A7F3D0'
  },
  ADMIN: {
    label: 'Rendez-vous & Admin',
    color: '#EC4899',
    bgLight: '#FDF2F8',
    border: '#FBCFE8'
  },
  RECOVERY: {
    label: 'Repos & Récupération',
    color: '#64748B',
    bgLight: '#F1F5F9',
    border: '#CBD5E1'
  },
  PRAYER: {
    label: 'Prière protégée',
    color: '#0D9488',
    bgLight: '#F0FDFA',
    border: '#99F6E4'
  }
};

export const PRIORITY_THEMES: Record<PriorityLevel, { label: string; color: string; badgeBg: string; text: string }> = {
  P1: {
    label: 'P1 Critique',
    color: '#EF4444',
    badgeBg: '#FEE2E2',
    text: '#991B1B'
  },
  P2: {
    label: 'P2 Haute',
    color: '#F97316',
    badgeBg: '#FFEDD5',
    text: '#9A3412'
  },
  P3: {
    label: 'P3 Normale',
    color: '#0EA5E9',
    badgeBg: '#E0F2FE',
    text: '#075985'
  },
  P4: {
    label: 'P4 Basse',
    color: '#94A3B8',
    badgeBg: '#F1F5F9',
    text: '#475569'
  }
};

export const STATUS_LABELS: Record<TaskStatus, { label: string; icon: string; style: string }> = {
  UNCOMPLETED: { label: 'À faire', icon: 'Circle', style: 'text-slate-600' },
  IN_PROGRESS: { label: 'En cours', icon: 'Clock', style: 'text-blue-600' },
  PARTIALLY_COMPLETED: { label: 'Partiellement fait', icon: 'CheckCircle2', style: 'text-amber-600' },
  COMPLETED: { label: 'Terminé', icon: 'CheckCircle', style: 'text-emerald-600' },
  POSTPONED: { label: 'Reporté', icon: 'ArrowRightCircle', style: 'text-orange-600' },
  MISSED: { label: 'Non confirmé', icon: 'AlertCircle', style: 'text-rose-600' },
  BLOCKED: { label: 'Bloqué', icon: 'Ban', style: 'text-red-700' },
  CANCELLED: { label: 'Annulé', icon: 'XCircle', style: 'text-slate-400' }
};
