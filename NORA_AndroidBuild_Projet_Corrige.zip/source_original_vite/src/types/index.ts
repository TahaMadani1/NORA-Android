export type PriorityLevel = 'P1' | 'P2' | 'P3' | 'P4';

export type TaskCategory = 
  | 'STUDIES'      // Études / Cours (#3B82F6)
  | 'WORK'         // Projets pro / Travail (#8B5CF6)
  | 'ASSOCIATION'  // Clubs / Associations (#F59E0B)
  | 'PERSONAL'     // Vie personnelle (#10B981)
  | 'ADMIN'        // Rendez-vous / Admin (#EC4899)
  | 'RECOVERY'     // Repos / Récupération (#64748B)
  | 'PRAYER';      // Prières islamiques (#0D9488)

export type ConstraintLevel = 
  | 'LEVEL_0' // Prières obligatoires (protégées)
  | 'LEVEL_1' // Contraintes dures (examens, cours fixes, sommeil protégé)
  | 'LEVEL_2' // Besoins essentiels (repas, cuisine, hygiène, transport)
  | 'LEVEL_3';// Activités flexibles & personnelles

export type TaskStatus = 
  | 'UNCOMPLETED'
  | 'IN_PROGRESS'
  | 'PARTIALLY_COMPLETED'
  | 'COMPLETED'
  | 'POSTPONED'
  | 'MISSED'
  | 'BLOCKED'
  | 'CANCELLED';

export type SchedulingPreference = 
  | 'BEFORE_DEADLINE' // À terminer avant
  | 'ON_DATE'         // À réaliser le
  | 'EXACT_TIME'      // À réaliser exactement à
  | 'FLEXIBLE'        // Horaire flexible
  | 'LOCKED';         // Verrouiller ce créneau

export type OperatingMode = 
  | 'NORMAL'         // Routine équilibrée
  | 'HEAVY_WEEK'     // Semaine chargée (protège échéances, allège optionnel)
  | 'RECOVERY'       // Récupération (charge réduite si fatigué/malade)
  | 'VACATION';      // Vacances / Voyage (suspend routines sélectionnées)

export type PrayerName = 'FAJR' | 'DHUHR' | 'ASR' | 'MAGHRIB' | 'ISHA' | 'JUMUAH';

export interface PrayerProtectionSettings {
  preparationMinutes: number; // Préparation / ablutions (défaut: 15m)
  travelMinutes: number;      // Trajet (défaut: 5m)
  waitingMinutes: number;     // Attente iqama (défaut: 10m)
  prayerMinutes: number;      // Durée prière (défaut: 18m)
  returnMinutes: number;      // Retour (défaut: 5m)
  reminderMinutesBefore: number; // Rappel en amont (défaut: 15m)
}

export interface JumuahSettings {
  enabled: boolean;
  preparationMinutes: number; // Préparation & grand bain (défaut: 30m)
  travelMinutes: number;      // Trajet mosquée (défaut: 20m)
  khutbahAndPrayerMinutes: number; // Khutbah + Prière (défaut: 45m)
  returnMinutes: number;      // Retour (défaut: 20m)
  mosqueName?: string;
  preferredMosqueTime?: string; // Heure estimée rassemblement
}

export interface DailyPrayerTimes {
  date: string; // YYYY-MM-DD
  city: string; // "Rabat"
  timezone: string; // "Africa/Casablanca"
  fajr: string;    // "HH:MM"
  sunrise: string; // "HH:MM" (chourouk - informatif)
  dhuhr: string;   // "HH:MM"
  asr: string;     // "HH:MM"
  maghrib: string; // "HH:MM"
  isha: string;    // "HH:MM"
  source: 'HABOUS_VERIFIED' | 'LOCAL_CALCULATED' | 'MANUAL_OVERRIDE';
  verifiedDate?: string;
}

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface DocumentAttachment {
  id: string;
  name: string;
  size?: string;
  type: 'PDF' | 'IMAGE' | 'URL' | 'FILE';
  uri: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  category: TaskCategory;
  priority: PriorityLevel;
  constraintLevel: ConstraintLevel;
  status: TaskStatus;
  projectId?: string;
  deadline?: string; // ISO date YYYY-MM-DD or YYYY-MM-DDTHH:mm
  totalEstimatedMinutes: number;
  remainingMinutes: number;
  energyLevel: 1 | 2 | 3 | 4 | 5; // 1 = faible, 5 = très intense
  isFixed: boolean;
  schedulingPreference: SchedulingPreference;
  targetDate?: string; // YYYY-MM-DD
  targetTime?: string; // HH:MM
  location?: string;
  preparationMinutes?: number;
  travelMinutes?: number;
  postponementCount: number;
  materialsNeeded?: string[];
  subtasks: SubTask[];
  notes?: string;
  attachments?: DocumentAttachment[];
  dependencies?: string[]; // IDs of tasks that must be finished first
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

export interface ScheduledSession {
  id: string;
  taskId?: string; // optional if direct event
  title: string;
  category: TaskCategory;
  priority: PriorityLevel;
  constraintLevel: ConstraintLevel;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  status: 'SCHEDULED' | 'CONFIRMED' | 'EXPIRED' | 'CANCELLED';
  confirmedMinutes?: number;
  isLocked: boolean;
  isPrayerBlock?: boolean;
  prayerName?: PrayerName;
  location?: string;
  notes?: string;
}

export interface RecurringRule {
  id: string;
  title: string;
  category: TaskCategory;
  priority: PriorityLevel;
  constraintLevel: ConstraintLevel;
  frequency: 'DAILY' | 'WEEKDAYS' | 'WEEKLY' | 'CUSTOM_DAYS';
  daysOfWeek: number[]; // 0 = Dimanche, 1 = Lundi, etc.
  startTime: string; // HH:MM
  endTime: string;   // HH:MM
  startDate: string; // YYYY-MM-DD
  endDate?: string;  // YYYY-MM-DD
  periodId?: string; // Période d'emploi du temps
  location?: string;
  preparationMinutes?: number;
}

export interface SchedulePeriod {
  id: string;
  name: string; // e.g. "Semestre 1", "Période d'Examens"
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
  isActive: boolean;
  description?: string;
}

export interface ProjectMilestone {
  id: string;
  title: string;
  dueDate: string;
  completed: boolean;
}

export interface Project {
  id: string;
  title: string;
  objective: string;
  category: TaskCategory;
  deadline?: string;
  progressPercentage: number;
  milestones: ProjectMilestone[];
  notes?: string;
  createdAt: string;
}

export interface MeetingAction {
  id: string;
  taskTitle: string;
  assignedTo?: string;
  dueDate?: string;
  convertedToTaskId?: string;
}

export interface Meeting {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  startTime: string;
  endTime: string;
  location?: string;
  participants: string[];
  agenda: string;
  notes: string;
  decisions: string[];
  actions: MeetingAction[];
}

export interface FollowUp {
  id: string;
  contactOrOrg: string;
  subject: string;
  lastContactDate: string; // YYYY-MM-DD
  expectedResponse?: string;
  followUpDeadline: string; // YYYY-MM-DD
  status: 'PENDING' | 'CONTACTED' | 'RESOLVED' | 'ABANDONED';
  notes?: string;
  templateMessage?: string;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  category: TaskCategory;
  tags: string[];
  updatedAt: string;
  attachments?: DocumentAttachment[];
}

export interface Ingredient {
  id: string;
  name: string;
  quantity: string;
  category: string;
  isInPantry: boolean;
}

export interface Recipe {
  id: string;
  name: string;
  servings: number;
  prepMinutes: number;
  activeCookMinutes: number;
  passiveCookMinutes: number;
  cleanupMinutes: number;
  ingredients: Ingredient[];
  instructions?: string;
  caloriesPerServing?: number;
  proteinGrams?: number;
  carbsGrams?: number;
  fatsGrams?: number;
  isBulkingFriendly?: boolean;
}

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: string;
  category: string;
  completed: boolean;
  addedFromRecipeId?: string;
}

export interface WorkoutExercise {
  id: string;
  name: string;
  sets: number;
  reps: string;
  weight?: string;
}

export interface Workout {
  id: string;
  title: string; // e.g. "Séance Pectoraux & Triceps", "Course à pied Rabat Chellah"
  type: 'GYM' | 'HOME' | 'CARDIO' | 'STRETCHING';
  prepMinutes: number;
  durationMinutes: number;
  travelMinutes: number;
  showerMinutes: number;
  exercises: WorkoutExercise[];
  notes?: string;
}

export interface SleepPreference {
  targetBedtime: string; // HH:MM
  targetWakeTime: string; // HH:MM
  targetHours: number;
  minHours: number; // 6.0 (seuil minimal vital)
  maxHours: number; // 9.0 (plafond maximal recommandé)
  fajrAwareBedtimeAdjustment: boolean;
  allowNap: boolean;
  napDurationMinutes: number;
  napPreferredTime: string; // HH:MM
}

export interface EnergyCheckIn {
  id: string;
  date: string;
  level: 'FAIBLE' | 'NORMALE' | 'ELEVEE';
  sleepQuality: 'MAUVAIS' | 'MOYEN' | 'BON' | 'EXCELLENT';
  notes?: string;
}

export interface NotificationRecord {
  id: string;
  channelId: 'prayers' | 'appointments' | 'tasks' | 'deadlines' | 'reports';
  title: string;
  body: string;
  scheduledTime: string;
  status: 'PENDING' | 'SENT' | 'DISMISSED';
  entityId?: string;
  actionTaken?: 'COMPLETED' | 'SNOOZED_15' | 'OPENED';
}

export interface AppSettings {
  operatingMode: OperatingMode;
  city: string;
  timezone: string;
  discretionaryWorkloadLimitHours: number; // default 4h
  bufferPercentage: number; // default 20%
  focusBlockMinutes: number; // default 50m
  breakMinutes: number; // default 10m
  fajrProtection: PrayerProtectionSettings;
  dhuhrProtection: PrayerProtectionSettings;
  asrProtection: PrayerProtectionSettings;
  maghribProtection: PrayerProtectionSettings;
  ishaProtection: PrayerProtectionSettings;
  jumuahSettings: JumuahSettings;
  sleepPreference: SleepPreference;
  notificationsEnabled: boolean;
  lockScreenPrivacy: 'SHOW_ALL' | 'HIDE_SENSITIVE' | 'MINIMAL';
  isDarkMode?: boolean;
  isRamadanMode?: boolean;
}
