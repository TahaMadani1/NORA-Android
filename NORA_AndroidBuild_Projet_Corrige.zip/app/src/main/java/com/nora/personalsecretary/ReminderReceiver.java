package com.nora.personalsecretary;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;

public final class ReminderReceiver extends BroadcastReceiver {
    static void createChannels(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel tasks = new NotificationChannel("tasks", "Tâches et activités", NotificationManager.IMPORTANCE_HIGH);
        tasks.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(tasks);
        NotificationChannel prayers = new NotificationChannel("prayers", "Prières et préparation", NotificationManager.IMPORTANCE_HIGH);
        prayers.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        manager.createNotificationChannel(prayers);
    }
    @Override public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        createChannels(context);
        String id=intent.getStringExtra("id"), title=intent.getStringExtra("title"), message=intent.getStringExtra("body");
        if(title==null||message==null) return;
        int code=(id==null?title:id).hashCode();
        String channel="prayers".equals(intent.getStringExtra("channel"))?"prayers":"tasks";
        Intent launch=new Intent(context, MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent click=PendingIntent.getActivity(context,code,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder=(Build.VERSION.SDK_INT>=26?new Notification.Builder(context,channel):new Notification.Builder(context));
        builder.setContentTitle(title).setContentText(message).setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setAutoCancel(true).setContentIntent(click).setVisibility(Notification.VISIBILITY_PUBLIC)
            .setPriority(Notification.PRIORITY_HIGH).setCategory(Notification.CATEGORY_REMINDER);
        NotificationManager manager=(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager!=null) manager.notify(code,builder.build());
    }
}
