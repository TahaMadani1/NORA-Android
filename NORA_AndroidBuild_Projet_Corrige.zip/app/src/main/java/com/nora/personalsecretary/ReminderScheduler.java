package com.nora.personalsecretary;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ReminderScheduler {
    private static final String PREF="nora_native_notifications", KEY="scheduled";
    private ReminderScheduler() {}
    public static void sync(Context context,String json) {
        SharedPreferences prefs=context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String before=prefs.getString(KEY,"[]");
        cancel(context,before);
        try { JSONArray list=new JSONArray(json);if(list.length()>100)throw new IllegalArgumentException("Too many reminders");
             prefs.edit().putString(KEY,json).apply(); schedule(context,json);
        } catch(Exception ex) { prefs.edit().putString(KEY,"[]").apply(); }
    }
    static void restore(Context context){String json=context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"[]");schedule(context,json);}
    private static void cancel(Context c,String json){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am==null)return;
        try{JSONArray a=new JSONArray(json);for(int i=0;i<a.length();i++){
           String id=a.getJSONObject(i).optString("id","");PendingIntent pi=intent(c,id,"","","tasks");am.cancel(pi);pi.cancel();
        }}catch(Exception ignored){}
    }
    private static PendingIntent intent(Context c,String id,String title,String body,String channel){
       Intent i=new Intent(c,ReminderReceiver.class).putExtra("id",id).putExtra("title",title).putExtra("body",body).putExtra("channel",channel);
       return PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void schedule(Context c,String json){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        long now=System.currentTimeMillis();
        try{JSONArray a=new JSONArray(json);for(int x=0;x<Math.min(a.length(),100);x++){
           JSONObject item=a.getJSONObject(x);long at=item.optLong("at",0);
           if(at<=now+5000||at>now+8L*86400000)continue;
           String id=item.optString("id","");if(id.length()==0)continue;
           PendingIntent pi=intent(c,id,item.optString("title","NORA"),item.optString("body","Rappel"),item.optString("channel","tasks"));
           if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
           else am.set(AlarmManager.RTC_WAKEUP,at,pi);
        }}catch(Exception ignored){}
    }
}
