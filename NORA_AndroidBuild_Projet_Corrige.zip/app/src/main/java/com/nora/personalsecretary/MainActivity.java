package com.nora.personalsecretary;

import android.app.Activity;
import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.content.pm.PackageManager;

public final class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> picker;
 private static final int PICK_FILE=401;
 private static final int SAVE_FILE=402;
 private String pendingExport=null;
 @Override public void onCreate(Bundle state){super.onCreate(state);
   getWindow().setStatusBarColor(Color.rgb(16,26,43));
   ReminderReceiver.createChannels(this);
   if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
   web=new WebView(this);
   web.getSettings().setJavaScriptEnabled(true);
   web.getSettings().setDomStorageEnabled(true);
   web.getSettings().setAllowFileAccess(true);
   web.getSettings().setAllowFileAccessFromFileURLs(false);
   web.getSettings().setAllowUniversalAccessFromFileURLs(false);
   web.setWebViewClient(new WebViewClient(){
    @Override public boolean shouldOverrideUrlLoading(WebView view,String url){
      if(url.startsWith("file:///android_asset/"))return false;
      if(url.startsWith("https://")){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}return true;}
      return true;
    }
   });
   web.setWebChromeClient(new WebChromeClient(){
     @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params){
       if(picker!=null)picker.onReceiveValue(null);picker=cb;
       try{Intent pick=params.createIntent();startActivityForResult(pick,PICK_FILE);return true;}
       catch(Exception ex){picker=null;cb.onReceiveValue(null);return false;}
     }
   });
   web.addJavascriptInterface(new Object(){
     @JavascriptInterface public void syncNotifications(String json){ReminderScheduler.sync(MainActivity.this,json);}
     @JavascriptInterface public void exportFile(String filename,String mime,String content){
       runOnUiThread(()->{
         pendingExport=content;
         Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT);
         create.addCategory(Intent.CATEGORY_OPENABLE);
         create.setType(mime==null||mime.isEmpty()?"application/octet-stream":mime);
         create.putExtra(Intent.EXTRA_TITLE,filename);
         try{startActivityForResult(create,SAVE_FILE);}catch(Exception e){pendingExport=null;}
       });
     }

   },"NoraAndroid");
   try (java.io.InputStream in = getAssets().open("index.html")) {
     byte[] bytes=in.readAllBytes();
     String html=new String(bytes,java.nio.charset.StandardCharsets.UTF_8);
     web.loadDataWithBaseURL("https://appassets.androidplatform.net/",html,"text/html","UTF-8",null);
   } catch(java.io.IOException ex){web.loadData("<h3>Impossible de charger NORA</h3>","text/html","UTF-8");}
   setContentView(web);
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==PICK_FILE&&picker!=null){picker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));picker=null;}
    if(requestCode==SAVE_FILE){
       if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingExport!=null){
         try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){
           if(out!=null)out.write(pendingExport.getBytes(java.nio.charset.StandardCharsets.UTF_8));
         }catch(Exception ignored){}
       }
       pendingExport=null;
    }
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
